package com.sidgs.luxury.homes.property.hosting.service.impl;

import com.liferay.document.library.kernel.model.DLFolder;
import com.liferay.document.library.kernel.model.DLFolderConstants;
import com.liferay.document.library.kernel.service.DLAppLocalServiceUtil;
import com.liferay.document.library.kernel.service.DLFolderLocalServiceUtil;
import com.liferay.dynamic.data.mapping.model.DDMStructure;
import com.liferay.dynamic.data.mapping.service.DDMStructureLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.sidgs.luxury.homes.property.hosting.headless.dto.v1_0.PropertyStatus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class LuxuryHomesPropertyHostingUtil {
	private final static Log log = LogFactoryUtil.getLog(LuxuryHomesPropertyHostingUtil.class.getName());
	public static long getTimeStampFolderId(long groupId, long userId, String propertyTitle, ServiceContext serviceContext) {
		long folderId = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
		DLFolder dlFolder = DLFolderLocalServiceUtil.fetchFolder(groupId, DLFolderConstants.DEFAULT_PARENT_FOLDER_ID, "Property Images");
		if(dlFolder!=null) {
			try {
				Folder timeStampFolder = DLAppLocalServiceUtil.addFolder(null, userId, groupId, dlFolder.getFolderId(), String.valueOf(System.currentTimeMillis()), propertyTitle, serviceContext);
				folderId = timeStampFolder.getFolderId();
			} catch (PortalException e) {
				log.error("Error while creating the folder");
			}
		}
		return folderId;
	}

	public static DDMStructure getStructureId(long groupId, String structureName) {
		DDMStructure struct = null;
		List<DDMStructure> structures = DDMStructureLocalServiceUtil.getStructures(groupId, PortalUtil.getPortal().getClassNameId(JournalArticle.class));
		for(DDMStructure structure: structures) {
			if(structure.getName(Locale.US).equalsIgnoreCase(structureName)) {
				struct = structure;
				break;
			}
		}
		return struct;
	}
	
	public static PropertyStatus validatePropertyDetails(JSONObject propertyObj, String filesArray, MultipartBody multipartBody) {
		PropertyStatus propertyStatus = new PropertyStatus();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		propertyStatus.setStatus("error");
		if (isEmptyValue(propertyObj, "Title")) {
			propertyStatus.setMessage("Title cannot be null / empty");
			return propertyStatus;
		}
		if (isEmptyValue(propertyObj, "Description")) {
			propertyStatus.setMessage("Description cannot be null / empty");
			return propertyStatus;
		}
		JSONObject coordinatesObj = propertyObj.getJSONObject("Coordinates");
		if (coordinatesObj == null || isEmptyValue(coordinatesObj, "Latitude") || isEmptyValue(coordinatesObj, "Longitude")) {
			propertyStatus.setMessage("Coordinates (Latitude/Longitude) cannot be null / empty");
			return propertyStatus;
		}
		JSONObject addressObj = propertyObj.getJSONObject("Address");
		if (addressObj == null || isEmptyValue(addressObj, "Country") || isEmptyValue(addressObj, "PlotNo") ||
				isEmptyValue(addressObj, "Street") || isEmptyValue(addressObj, "Locality") ||
				isEmptyValue(addressObj, "City") || isEmptyValue(addressObj, "State") || isEmptyValue(addressObj, "Zipcode")) {
			propertyStatus.setMessage("Address values (Country, PlotNo, Street, Locality, City, State, Zipcode) cannot be null / empty");
			return propertyStatus;
		}
		if (!propertyObj.has("Guests") || !propertyObj.has("Bedrooms") || !propertyObj.has("Beds") || !propertyObj.has("Bathrooms") ||
				!(propertyObj.get("Guests") instanceof Integer) || !(propertyObj.get("Bedrooms") instanceof Integer) ||
				!(propertyObj.get("Beds") instanceof Integer) || !(propertyObj.get("Bathrooms") instanceof Integer) ||
				(int) propertyObj.get("Guests") <= 0 || (int) propertyObj.get("Bedrooms") <= 0 ||
				(int) propertyObj.get("Beds") <= 0 || (int) propertyObj.get("Bathrooms") <= 0) {
			propertyStatus.setMessage("No. of (Guests/Bedrooms/Beds/Bathrooms) must be positive integers");
			return propertyStatus;
		}
		if (!(propertyObj.get("ChargePerNight") instanceof Number)) {
			propertyStatus.setMessage("Base Price per night must be a number");
			return propertyStatus;
		}
		if (isEmptyValue(propertyObj, "AvailableFrom")) {
			propertyStatus.setMessage("Available Date cannot be null / empty");
			return propertyStatus;
		}
		try {
			dateFormat.parse(propertyObj.getString("AvailableFrom"));
		} catch (ParseException e) {
			propertyStatus.setMessage("Date format of Available Date should be yyyy-MM-dd");
			return propertyStatus;
		}
		if (!propertyObj.has("propertyTypeId") || !propertyObj.has("amentyIds") ||
				!(propertyObj.get("propertyTypeId") instanceof Integer) || !(propertyObj.get("amentyIds") instanceof JSONArray)) {
			propertyStatus.setMessage("PropertyType/Amenities are missing / doesn't have valid types");
			return propertyStatus;
		}
		try {
			JSONArray filesObjs = JSONFactoryUtil.createJSONArray(filesArray);
			if(filesObjs.length()<=4) {
				propertyStatus.setMessage("Upload atleast five files");
				return propertyStatus;
			}
			for (int i = 0; i < filesObjs.length(); i++) {
				JSONObject fileObject = filesObjs.getJSONObject(i);
				if (isEmptyValue(fileObject, "key") || isEmptyValue(fileObject, "fileName")) {
					propertyStatus.setMessage("Issue with Filename Array");
					return propertyStatus;
				}
			}
		}catch(JSONException je) {
			propertyStatus.setMessage("File Names Array is  invalid");
			return propertyStatus;
		}
		propertyStatus.setStatus("success");
		return propertyStatus;
	}
	
	private static boolean isEmptyValue(JSONObject obj, String key) {
		return obj.isNull(key) || obj.getString(key).isEmpty();
	}
}
