package com.sidgs.luxury.homes.identity.headless.client.serdes.v1_0;

import com.sidgs.luxury.homes.identity.headless.client.dto.v1_0.Register;
import com.sidgs.luxury.homes.identity.headless.client.json.BaseJSONParser;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Generated;

/**
 * @author MuraliMohanSIDGlobal
 * @generated
 */
@Generated("")
public class RegisterSerDes {

	public static Register toDTO(String json) {
		RegisterJSONParser registerJSONParser = new RegisterJSONParser();

		return registerJSONParser.parseToDTO(json);
	}

	public static Register[] toDTOs(String json) {
		RegisterJSONParser registerJSONParser = new RegisterJSONParser();

		return registerJSONParser.parseToDTOs(json);
	}

	public static String toJSON(Register register) {
		if (register == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (register.getDateOfBirth() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"dateOfBirth\": ");

			sb.append("\"");

			sb.append(_escape(register.getDateOfBirth()));

			sb.append("\"");
		}

		if (register.getEmailAddress() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"emailAddress\": ");

			sb.append("\"");

			sb.append(_escape(register.getEmailAddress()));

			sb.append("\"");
		}

		if (register.getFirstName() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"firstName\": ");

			sb.append("\"");

			sb.append(_escape(register.getFirstName()));

			sb.append("\"");
		}

		if (register.getLastName() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"lastName\": ");

			sb.append("\"");

			sb.append(_escape(register.getLastName()));

			sb.append("\"");
		}

		if (register.getPhoneNumber() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"phoneNumber\": ");

			sb.append("\"");

			sb.append(_escape(register.getPhoneNumber()));

			sb.append("\"");
		}

		if (register.getTAndC() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"tAndC\": ");

			sb.append(register.getTAndC());
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		RegisterJSONParser registerJSONParser = new RegisterJSONParser();

		return registerJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(Register register) {
		if (register == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (register.getDateOfBirth() == null) {
			map.put("dateOfBirth", null);
		}
		else {
			map.put("dateOfBirth", String.valueOf(register.getDateOfBirth()));
		}

		if (register.getEmailAddress() == null) {
			map.put("emailAddress", null);
		}
		else {
			map.put("emailAddress", String.valueOf(register.getEmailAddress()));
		}

		if (register.getFirstName() == null) {
			map.put("firstName", null);
		}
		else {
			map.put("firstName", String.valueOf(register.getFirstName()));
		}

		if (register.getLastName() == null) {
			map.put("lastName", null);
		}
		else {
			map.put("lastName", String.valueOf(register.getLastName()));
		}

		if (register.getPhoneNumber() == null) {
			map.put("phoneNumber", null);
		}
		else {
			map.put("phoneNumber", String.valueOf(register.getPhoneNumber()));
		}

		if (register.getTAndC() == null) {
			map.put("tAndC", null);
		}
		else {
			map.put("tAndC", String.valueOf(register.getTAndC()));
		}

		return map;
	}

	public static class RegisterJSONParser extends BaseJSONParser<Register> {

		@Override
		protected Register createDTO() {
			return new Register();
		}

		@Override
		protected Register[] createDTOArray(int size) {
			return new Register[size];
		}

		@Override
		protected void setField(
			Register register, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "dateOfBirth")) {
				if (jsonParserFieldValue != null) {
					register.setDateOfBirth((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "emailAddress")) {
				if (jsonParserFieldValue != null) {
					register.setEmailAddress((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "firstName")) {
				if (jsonParserFieldValue != null) {
					register.setFirstName((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "lastName")) {
				if (jsonParserFieldValue != null) {
					register.setLastName((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "phoneNumber")) {
				if (jsonParserFieldValue != null) {
					register.setPhoneNumber((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "tAndC")) {
				if (jsonParserFieldValue != null) {
					register.setTAndC((Boolean)jsonParserFieldValue);
				}
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\": ");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}