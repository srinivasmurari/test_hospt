package com.sidgs.luxury.homes.identity.headless.resource.v1_0.test;

import com.liferay.arquillian.extension.junit.bridge.junit.Arquillian;

import org.junit.Ignore;
import org.junit.runner.RunWith;

/**
 * @author MuraliMohanSIDGlobal
 */
@Ignore
@RunWith(Arquillian.class)
public class ForgotPasswordResourceTest
	extends BaseForgotPasswordResourceTestCase {
}