package com.sidgs.luxury.homes.property.hosting.headless.client.serdes.v1_0;

import com.sidgs.luxury.homes.property.hosting.headless.client.dto.v1_0.HostProperty;
import com.sidgs.luxury.homes.property.hosting.headless.client.json.BaseJSONParser;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Generated;

/**
 * @author MuraliMohan
 * @generated
 */
@Generated("")
public class HostPropertySerDes {

	public static HostProperty toDTO(String json) {
		HostPropertyJSONParser hostPropertyJSONParser =
			new HostPropertyJSONParser();

		return hostPropertyJSONParser.parseToDTO(json);
	}

	public static HostProperty[] toDTOs(String json) {
		HostPropertyJSONParser hostPropertyJSONParser =
			new HostPropertyJSONParser();

		return hostPropertyJSONParser.parseToDTOs(json);
	}

	public static String toJSON(HostProperty hostProperty) {
		if (hostProperty == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (hostProperty.getAddress() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"address\": ");

			sb.append("\"");

			sb.append(_escape(hostProperty.getAddress()));

			sb.append("\"");
		}

		if (hostProperty.getAvailableFrom() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"availableFrom\": ");

			sb.append("\"");

			sb.append(_escape(hostProperty.getAvailableFrom()));

			sb.append("\"");
		}

		if (hostProperty.getBathrooms() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"bathrooms\": ");

			sb.append(hostProperty.getBathrooms());
		}

		if (hostProperty.getBedrooms() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"bedrooms\": ");

			sb.append(hostProperty.getBedrooms());
		}

		if (hostProperty.getBeds() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"beds\": ");

			sb.append(hostProperty.getBeds());
		}

		if (hostProperty.getCoordinates() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"coordinates\": ");

			sb.append("\"");

			sb.append(_escape(hostProperty.getCoordinates()));

			sb.append("\"");
		}

		if (hostProperty.getDescription() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"description\": ");

			sb.append("\"");

			sb.append(_escape(hostProperty.getDescription()));

			sb.append("\"");
		}

		if (hostProperty.getGuests() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"guests\": ");

			sb.append(hostProperty.getGuests());
		}

		if (hostProperty.getImages() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"images\": ");

			sb.append("\"");

			sb.append(_escape(hostProperty.getImages()));

			sb.append("\"");
		}

		if (hostProperty.getTitle() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"title\": ");

			sb.append("\"");

			sb.append(_escape(hostProperty.getTitle()));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		HostPropertyJSONParser hostPropertyJSONParser =
			new HostPropertyJSONParser();

		return hostPropertyJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(HostProperty hostProperty) {
		if (hostProperty == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (hostProperty.getAddress() == null) {
			map.put("address", null);
		}
		else {
			map.put("address", String.valueOf(hostProperty.getAddress()));
		}

		if (hostProperty.getAvailableFrom() == null) {
			map.put("availableFrom", null);
		}
		else {
			map.put(
				"availableFrom",
				String.valueOf(hostProperty.getAvailableFrom()));
		}

		if (hostProperty.getBathrooms() == null) {
			map.put("bathrooms", null);
		}
		else {
			map.put("bathrooms", String.valueOf(hostProperty.getBathrooms()));
		}

		if (hostProperty.getBedrooms() == null) {
			map.put("bedrooms", null);
		}
		else {
			map.put("bedrooms", String.valueOf(hostProperty.getBedrooms()));
		}

		if (hostProperty.getBeds() == null) {
			map.put("beds", null);
		}
		else {
			map.put("beds", String.valueOf(hostProperty.getBeds()));
		}

		if (hostProperty.getCoordinates() == null) {
			map.put("coordinates", null);
		}
		else {
			map.put(
				"coordinates", String.valueOf(hostProperty.getCoordinates()));
		}

		if (hostProperty.getDescription() == null) {
			map.put("description", null);
		}
		else {
			map.put(
				"description", String.valueOf(hostProperty.getDescription()));
		}

		if (hostProperty.getGuests() == null) {
			map.put("guests", null);
		}
		else {
			map.put("guests", String.valueOf(hostProperty.getGuests()));
		}

		if (hostProperty.getImages() == null) {
			map.put("images", null);
		}
		else {
			map.put("images", String.valueOf(hostProperty.getImages()));
		}

		if (hostProperty.getTitle() == null) {
			map.put("title", null);
		}
		else {
			map.put("title", String.valueOf(hostProperty.getTitle()));
		}

		return map;
	}

	public static class HostPropertyJSONParser
		extends BaseJSONParser<HostProperty> {

		@Override
		protected HostProperty createDTO() {
			return new HostProperty();
		}

		@Override
		protected HostProperty[] createDTOArray(int size) {
			return new HostProperty[size];
		}

		@Override
		protected void setField(
			HostProperty hostProperty, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "address")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setAddress((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "availableFrom")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setAvailableFrom((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "bathrooms")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setBathrooms(
						Long.valueOf((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "bedrooms")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setBedrooms(
						Long.valueOf((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "beds")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setBeds(
						Long.valueOf((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "coordinates")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setCoordinates((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "description")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setDescription((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "guests")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setGuests(
						Long.valueOf((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "images")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setImages((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "title")) {
				if (jsonParserFieldValue != null) {
					hostProperty.setTitle((String)jsonParserFieldValue);
				}
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\": ");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}