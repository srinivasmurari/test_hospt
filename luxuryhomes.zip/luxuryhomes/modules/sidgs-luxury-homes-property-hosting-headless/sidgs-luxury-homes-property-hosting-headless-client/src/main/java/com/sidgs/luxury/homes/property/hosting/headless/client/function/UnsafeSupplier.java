package com.sidgs.luxury.homes.property.hosting.headless.client.function;

import javax.annotation.Generated;

/**
 * @author MuraliMohan
 * @generated
 */
@FunctionalInterface
@Generated("")
public interface UnsafeSupplier<T, E extends Throwable> {

	public T get() throws E;

}