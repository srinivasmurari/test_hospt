package com.sidgs.luxury.homes.property.hosting.headless.client.dto.v1_0;

import com.sidgs.luxury.homes.property.hosting.headless.client.function.UnsafeSupplier;
import com.sidgs.luxury.homes.property.hosting.headless.client.serdes.v1_0.PropertyStatusSerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author MuraliMohan
 * @generated
 */
@Generated("")
public class PropertyStatus implements Cloneable, Serializable {

	public static PropertyStatus toDTO(String json) {
		return PropertyStatusSerDes.toDTO(json);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setMessage(
		UnsafeSupplier<String, Exception> messageUnsafeSupplier) {

		try {
			message = messageUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String message;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		try {
			status = statusUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String status;

	@Override
	public PropertyStatus clone() throws CloneNotSupportedException {
		return (PropertyStatus)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof PropertyStatus)) {
			return false;
		}

		PropertyStatus propertyStatus = (PropertyStatus)object;

		return Objects.equals(toString(), propertyStatus.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return PropertyStatusSerDes.toJSON(this);
	}

}