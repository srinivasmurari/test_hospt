package com.sidgs.luxury.homes.property.hosting.headless.client.dto.v1_0;

import com.sidgs.luxury.homes.property.hosting.headless.client.function.UnsafeSupplier;
import com.sidgs.luxury.homes.property.hosting.headless.client.serdes.v1_0.FeaturesSerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author MuraliMohan
 * @generated
 */
@Generated("")
public class Features implements Cloneable, Serializable {

	public static Features toDTO(String json) {
		return FeaturesSerDes.toDTO(json);
	}

	public Feature[] getFeatures() {
		return features;
	}

	public void setFeatures(Feature[] features) {
		this.features = features;
	}

	public void setFeatures(
		UnsafeSupplier<Feature[], Exception> featuresUnsafeSupplier) {

		try {
			features = featuresUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Feature[] features;

	@Override
	public Features clone() throws CloneNotSupportedException {
		return (Features)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Features)) {
			return false;
		}

		Features features = (Features)object;

		return Objects.equals(toString(), features.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return FeaturesSerDes.toJSON(this);
	}

}