package com.sidgs.luxury.homes.property.hosting.headless.client.dto.v1_0;

import com.sidgs.luxury.homes.property.hosting.headless.client.function.UnsafeSupplier;
import com.sidgs.luxury.homes.property.hosting.headless.client.serdes.v1_0.HostPropertySerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author MuraliMohan
 * @generated
 */
@Generated("")
public class HostProperty implements Cloneable, Serializable {

	public static HostProperty toDTO(String json) {
		return HostPropertySerDes.toDTO(json);
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setAddress(
		UnsafeSupplier<String, Exception> addressUnsafeSupplier) {

		try {
			address = addressUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String address;

	public String getAvailableFrom() {
		return availableFrom;
	}

	public void setAvailableFrom(String availableFrom) {
		this.availableFrom = availableFrom;
	}

	public void setAvailableFrom(
		UnsafeSupplier<String, Exception> availableFromUnsafeSupplier) {

		try {
			availableFrom = availableFromUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String availableFrom;

	public Long getBathrooms() {
		return bathrooms;
	}

	public void setBathrooms(Long bathrooms) {
		this.bathrooms = bathrooms;
	}

	public void setBathrooms(
		UnsafeSupplier<Long, Exception> bathroomsUnsafeSupplier) {

		try {
			bathrooms = bathroomsUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Long bathrooms;

	public Long getBedrooms() {
		return bedrooms;
	}

	public void setBedrooms(Long bedrooms) {
		this.bedrooms = bedrooms;
	}

	public void setBedrooms(
		UnsafeSupplier<Long, Exception> bedroomsUnsafeSupplier) {

		try {
			bedrooms = bedroomsUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Long bedrooms;

	public Long getBeds() {
		return beds;
	}

	public void setBeds(Long beds) {
		this.beds = beds;
	}

	public void setBeds(UnsafeSupplier<Long, Exception> bedsUnsafeSupplier) {
		try {
			beds = bedsUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Long beds;

	public String getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(String coordinates) {
		this.coordinates = coordinates;
	}

	public void setCoordinates(
		UnsafeSupplier<String, Exception> coordinatesUnsafeSupplier) {

		try {
			coordinates = coordinatesUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String coordinates;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setDescription(
		UnsafeSupplier<String, Exception> descriptionUnsafeSupplier) {

		try {
			description = descriptionUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String description;

	public Long getGuests() {
		return guests;
	}

	public void setGuests(Long guests) {
		this.guests = guests;
	}

	public void setGuests(
		UnsafeSupplier<Long, Exception> guestsUnsafeSupplier) {

		try {
			guests = guestsUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Long guests;

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public void setImages(
		UnsafeSupplier<String, Exception> imagesUnsafeSupplier) {

		try {
			images = imagesUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String images;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setTitle(
		UnsafeSupplier<String, Exception> titleUnsafeSupplier) {

		try {
			title = titleUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String title;

	@Override
	public HostProperty clone() throws CloneNotSupportedException {
		return (HostProperty)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof HostProperty)) {
			return false;
		}

		HostProperty hostProperty = (HostProperty)object;

		return Objects.equals(toString(), hostProperty.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return HostPropertySerDes.toJSON(this);
	}

}