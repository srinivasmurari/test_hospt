package com.sidgs.luxury.homes.property.hosting.headless.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.annotation.Generated;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author MuraliMohan
 * @generated
 */
@Generated("")
@GraphQLName(
	description = "https://www.schema.org/HostProperty", value = "HostProperty"
)
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "HostProperty")
public class HostProperty implements Serializable {

	public static HostProperty toDTO(String json) {
		return ObjectMapperUtil.readValue(HostProperty.class, json);
	}

	public static HostProperty unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(HostProperty.class, json);
	}

	@Schema
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@JsonIgnore
	public void setAddress(
		UnsafeSupplier<String, Exception> addressUnsafeSupplier) {

		try {
			address = addressUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String address;

	@Schema
	public String getAvailableFrom() {
		return availableFrom;
	}

	public void setAvailableFrom(String availableFrom) {
		this.availableFrom = availableFrom;
	}

	@JsonIgnore
	public void setAvailableFrom(
		UnsafeSupplier<String, Exception> availableFromUnsafeSupplier) {

		try {
			availableFrom = availableFromUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String availableFrom;

	@Schema
	public Long getBathrooms() {
		return bathrooms;
	}

	public void setBathrooms(Long bathrooms) {
		this.bathrooms = bathrooms;
	}

	@JsonIgnore
	public void setBathrooms(
		UnsafeSupplier<Long, Exception> bathroomsUnsafeSupplier) {

		try {
			bathrooms = bathroomsUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Long bathrooms;

	@Schema
	public Long getBedrooms() {
		return bedrooms;
	}

	public void setBedrooms(Long bedrooms) {
		this.bedrooms = bedrooms;
	}

	@JsonIgnore
	public void setBedrooms(
		UnsafeSupplier<Long, Exception> bedroomsUnsafeSupplier) {

		try {
			bedrooms = bedroomsUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Long bedrooms;

	@Schema
	public Long getBeds() {
		return beds;
	}

	public void setBeds(Long beds) {
		this.beds = beds;
	}

	@JsonIgnore
	public void setBeds(UnsafeSupplier<Long, Exception> bedsUnsafeSupplier) {
		try {
			beds = bedsUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Long beds;

	@Schema
	public String getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(String coordinates) {
		this.coordinates = coordinates;
	}

	@JsonIgnore
	public void setCoordinates(
		UnsafeSupplier<String, Exception> coordinatesUnsafeSupplier) {

		try {
			coordinates = coordinatesUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String coordinates;

	@Schema
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@JsonIgnore
	public void setDescription(
		UnsafeSupplier<String, Exception> descriptionUnsafeSupplier) {

		try {
			description = descriptionUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String description;

	@Schema
	public Long getGuests() {
		return guests;
	}

	public void setGuests(Long guests) {
		this.guests = guests;
	}

	@JsonIgnore
	public void setGuests(
		UnsafeSupplier<Long, Exception> guestsUnsafeSupplier) {

		try {
			guests = guestsUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Long guests;

	@Schema
	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	@JsonIgnore
	public void setImages(
		UnsafeSupplier<String, Exception> imagesUnsafeSupplier) {

		try {
			images = imagesUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String images;

	@Schema
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@JsonIgnore
	public void setTitle(
		UnsafeSupplier<String, Exception> titleUnsafeSupplier) {

		try {
			title = titleUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String title;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof HostProperty)) {
			return false;
		}

		HostProperty hostProperty = (HostProperty)object;

		return Objects.equals(toString(), hostProperty.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		if (address != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"address\": ");

			sb.append("\"");

			sb.append(_escape(address));

			sb.append("\"");
		}

		if (availableFrom != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"availableFrom\": ");

			sb.append("\"");

			sb.append(_escape(availableFrom));

			sb.append("\"");
		}

		if (bathrooms != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"bathrooms\": ");

			sb.append(bathrooms);
		}

		if (bedrooms != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"bedrooms\": ");

			sb.append(bedrooms);
		}

		if (beds != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"beds\": ");

			sb.append(beds);
		}

		if (coordinates != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"coordinates\": ");

			sb.append("\"");

			sb.append(_escape(coordinates));

			sb.append("\"");
		}

		if (description != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"description\": ");

			sb.append("\"");

			sb.append(_escape(description));

			sb.append("\"");
		}

		if (guests != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"guests\": ");

			sb.append(guests);
		}

		if (images != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"images\": ");

			sb.append("\"");

			sb.append(_escape(images));

			sb.append("\"");
		}

		if (title != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"title\": ");

			sb.append("\"");

			sb.append(_escape(title));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "com.sidgs.luxury.homes.property.hosting.headless.dto.v1_0.HostProperty",
		name = "x-class-name"
	)
	public String xClassName;

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

	private Map<String, Serializable> _extendedProperties;

}