package com.sidgs.luxury.homes.property.hosting.headless.internal.jaxrs.application;

import javax.annotation.Generated;

import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;

/**
 * @author MuraliMohan
 * @generated
 */
@Component(
	property = {
		"liferay.jackson=false", "osgi.jaxrs.application.base=/pZ",
		"osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
		"osgi.jaxrs.name=SidgsLuxuryHomesPropertyHostingHeadless"
	},
	service = Application.class
)
@Generated("")
public class SidgsLuxuryHomesPropertyHostingHeadlessApplication
	extends Application {
}