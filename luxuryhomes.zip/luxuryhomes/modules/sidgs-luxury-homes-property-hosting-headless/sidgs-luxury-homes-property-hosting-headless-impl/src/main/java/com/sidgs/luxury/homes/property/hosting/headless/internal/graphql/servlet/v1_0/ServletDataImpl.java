package com.sidgs.luxury.homes.property.hosting.headless.internal.graphql.servlet.v1_0;

import com.liferay.portal.kernel.util.ObjectValuePair;
import com.liferay.portal.vulcan.graphql.servlet.ServletData;

import com.sidgs.luxury.homes.property.hosting.headless.internal.graphql.mutation.v1_0.Mutation;
import com.sidgs.luxury.homes.property.hosting.headless.internal.graphql.query.v1_0.Query;
import com.sidgs.luxury.homes.property.hosting.headless.internal.resource.v1_0.FeatureResourceImpl;
import com.sidgs.luxury.homes.property.hosting.headless.internal.resource.v1_0.HostPropertyResourceImpl;
import com.sidgs.luxury.homes.property.hosting.headless.resource.v1_0.FeatureResource;
import com.sidgs.luxury.homes.property.hosting.headless.resource.v1_0.HostPropertyResource;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Generated;

import org.osgi.framework.BundleContext;
import org.osgi.service.component.ComponentServiceObjects;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceScope;

/**
 * @author MuraliMohan
 * @generated
 */
@Component(service = ServletData.class)
@Generated("")
public class ServletDataImpl implements ServletData {

	@Activate
	public void activate(BundleContext bundleContext) {
		Mutation.setHostPropertyResourceComponentServiceObjects(
			_hostPropertyResourceComponentServiceObjects);

		Query.setFeatureResourceComponentServiceObjects(
			_featureResourceComponentServiceObjects);
	}

	public String getApplicationName() {
		return "SidgsLuxuryHomesPropertyHostingHeadless";
	}

	@Override
	public Mutation getMutation() {
		return new Mutation();
	}

	@Override
	public String getPath() {
		return "/pZ-graphql/v1_0";
	}

	@Override
	public Query getQuery() {
		return new Query();
	}

	public ObjectValuePair<Class<?>, String> getResourceMethodObjectValuePair(
		String methodName, boolean mutation) {

		if (mutation) {
			return _resourceMethodObjectValuePairs.get(
				"mutation#" + methodName);
		}

		return _resourceMethodObjectValuePairs.get("query#" + methodName);
	}

	private static final Map<String, ObjectValuePair<Class<?>, String>>
		_resourceMethodObjectValuePairs =
			new HashMap<String, ObjectValuePair<Class<?>, String>>() {
				{
					put(
						"mutation#createProperty",
						new ObjectValuePair<>(
							HostPropertyResourceImpl.class, "postProperty"));

					put(
						"query#propertyTypes",
						new ObjectValuePair<>(
							FeatureResourceImpl.class, "getPropertyTypes"));
					put(
						"query#amenities",
						new ObjectValuePair<>(
							FeatureResourceImpl.class, "getAmenities"));
				}
			};

	@Reference(scope = ReferenceScope.PROTOTYPE_REQUIRED)
	private ComponentServiceObjects<HostPropertyResource>
		_hostPropertyResourceComponentServiceObjects;

	@Reference(scope = ReferenceScope.PROTOTYPE_REQUIRED)
	private ComponentServiceObjects<FeatureResource>
		_featureResourceComponentServiceObjects;

}