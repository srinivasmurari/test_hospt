package com.sidgs.luxury.homes.property.hosting.headless.internal.resource.v1_0;

import com.sidgs.luxury.homes.property.hosting.headless.resource.v1_0.FeatureResource;
import com.sidgs.luxury.homes.property.hosting.service.LuxuryHomesPropertyHostingService;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author MuraliMohan
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/feature.properties",
	scope = ServiceScope.PROTOTYPE, service = FeatureResource.class
)
public class FeatureResourceImpl extends BaseFeatureResourceImpl {
	
	@Override
	public String getPropertyTypes() throws Exception {
		return luxuryHomesPropertyHostingService.getPropertyTypes();
	}
	
	@Override
	public String getAmenities() throws Exception {
		return luxuryHomesPropertyHostingService.getAmenities();
	}
	
	@Reference
	LuxuryHomesPropertyHostingService luxuryHomesPropertyHostingService;
	
}