package com.sidgs.luxury.homes.property.hosting.headless.resource.v1_0.test;

import com.liferay.arquillian.extension.junit.bridge.junit.Arquillian;

import org.junit.Ignore;
import org.junit.runner.RunWith;

/**
 * @author MuraliMohan
 */
@Ignore
@RunWith(Arquillian.class)
public class FeatureResourceTest extends BaseFeatureResourceTestCase {
}