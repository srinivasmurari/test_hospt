create index IX_983CB995 on SID_HostProperty (active_);
create index IX_EB8187AD on SID_HostProperty (articleId[$COLUMN_LENGTH:75$]);
create index IX_6A3EB928 on SID_HostProperty (createdByUserId, active_);
create index IX_5790D07 on SID_HostProperty (sharedProperty, active_);

create index IX_AADB4F49 on SID_PropertyFloor (bathrooms);
create index IX_36F570D7 on SID_PropertyFloor (bedrooms);
create index IX_400BC212 on SID_PropertyFloor (beds);
create index IX_F66B4098 on SID_PropertyFloor (hostPropertyId);
create index IX_69D112EE on SID_PropertyFloor (totalGuests, bedrooms);

create index IX_1C2D1D25 on SID_PropertyLocation (country[$COLUMN_LENGTH:75$]);
create index IX_ED5A744D on SID_PropertyLocation (hostPropertyId);
create index IX_2F92E0AE on SID_PropertyLocation (locality[$COLUMN_LENGTH:300$], country[$COLUMN_LENGTH:75$]);
create index IX_175AC90C on SID_PropertyLocation (locality[$COLUMN_LENGTH:300$], state_[$COLUMN_LENGTH:75$], country[$COLUMN_LENGTH:75$]);
create index IX_BFC89E83 on SID_PropertyLocation (state_[$COLUMN_LENGTH:75$], country[$COLUMN_LENGTH:75$]);
create index IX_ACDF603D on SID_PropertyLocation (zipCode[$COLUMN_LENGTH:75$]);

create index IX_AFC370A2 on SID_PropertyPricing (basePrice);
create index IX_7A8A1C31 on SID_PropertyPricing (floorId);
create index IX_D1553B52 on SID_PropertyPricing (hostPropertyId);