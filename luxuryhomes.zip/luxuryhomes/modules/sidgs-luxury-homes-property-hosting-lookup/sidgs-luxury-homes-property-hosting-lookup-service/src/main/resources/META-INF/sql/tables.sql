create table SID_HostProperty (
	hostPropertyId LONG not null primary key,
	createdByUserId LONG,
	createDate DATE null,
	lastModifiedByUserId LONG,
	modifiedDate DATE null,
	articleId VARCHAR(75) null,
	totalGuests INTEGER,
	bedrooms INTEGER,
	sharedProperty BOOLEAN,
	availableFrom DATE null,
	active_ BOOLEAN,
	status INTEGER,
	statusByUserId LONG,
	statusUpdatedDate DATE null
);

create table SID_PropertyFloor (
	floorId LONG not null primary key,
	hostPropertyId LONG,
	totalGuests INTEGER,
	bedrooms INTEGER,
	beds INTEGER,
	bathrooms INTEGER
);

create table SID_PropertyLocation (
	locationId LONG not null primary key,
	hostPropertyId LONG,
	plotNo VARCHAR(300) null,
	street VARCHAR(300) null,
	landmark VARCHAR(300) null,
	locality VARCHAR(300) null,
	city VARCHAR(75) null,
	state_ VARCHAR(75) null,
	country VARCHAR(75) null,
	zipCode VARCHAR(75) null,
	coordinates VARCHAR(300) null
);

create table SID_PropertyPricing (
	pricingId LONG not null primary key,
	hostPropertyId LONG,
	floorId LONG,
	currency_ VARCHAR(75) null,
	basePrice DOUBLE
);