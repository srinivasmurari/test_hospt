/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing HostProperty in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class HostPropertyCacheModel
	implements CacheModel<HostProperty>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof HostPropertyCacheModel)) {
			return false;
		}

		HostPropertyCacheModel hostPropertyCacheModel =
			(HostPropertyCacheModel)object;

		if (hostPropertyId == hostPropertyCacheModel.hostPropertyId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, hostPropertyId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{hostPropertyId=");
		sb.append(hostPropertyId);
		sb.append(", createdByUserId=");
		sb.append(createdByUserId);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", lastModifiedByUserId=");
		sb.append(lastModifiedByUserId);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", articleId=");
		sb.append(articleId);
		sb.append(", totalGuests=");
		sb.append(totalGuests);
		sb.append(", bedrooms=");
		sb.append(bedrooms);
		sb.append(", sharedProperty=");
		sb.append(sharedProperty);
		sb.append(", availableFrom=");
		sb.append(availableFrom);
		sb.append(", active=");
		sb.append(active);
		sb.append(", status=");
		sb.append(status);
		sb.append(", statusByUserId=");
		sb.append(statusByUserId);
		sb.append(", statusUpdatedDate=");
		sb.append(statusUpdatedDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public HostProperty toEntityModel() {
		HostPropertyImpl hostPropertyImpl = new HostPropertyImpl();

		hostPropertyImpl.setHostPropertyId(hostPropertyId);
		hostPropertyImpl.setCreatedByUserId(createdByUserId);

		if (createDate == Long.MIN_VALUE) {
			hostPropertyImpl.setCreateDate(null);
		}
		else {
			hostPropertyImpl.setCreateDate(new Date(createDate));
		}

		hostPropertyImpl.setLastModifiedByUserId(lastModifiedByUserId);

		if (modifiedDate == Long.MIN_VALUE) {
			hostPropertyImpl.setModifiedDate(null);
		}
		else {
			hostPropertyImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (articleId == null) {
			hostPropertyImpl.setArticleId("");
		}
		else {
			hostPropertyImpl.setArticleId(articleId);
		}

		hostPropertyImpl.setTotalGuests(totalGuests);
		hostPropertyImpl.setBedrooms(bedrooms);
		hostPropertyImpl.setSharedProperty(sharedProperty);

		if (availableFrom == Long.MIN_VALUE) {
			hostPropertyImpl.setAvailableFrom(null);
		}
		else {
			hostPropertyImpl.setAvailableFrom(new Date(availableFrom));
		}

		hostPropertyImpl.setActive(active);
		hostPropertyImpl.setStatus(status);
		hostPropertyImpl.setStatusByUserId(statusByUserId);

		if (statusUpdatedDate == Long.MIN_VALUE) {
			hostPropertyImpl.setStatusUpdatedDate(null);
		}
		else {
			hostPropertyImpl.setStatusUpdatedDate(new Date(statusUpdatedDate));
		}

		hostPropertyImpl.resetOriginalValues();

		return hostPropertyImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		hostPropertyId = objectInput.readLong();

		createdByUserId = objectInput.readLong();
		createDate = objectInput.readLong();

		lastModifiedByUserId = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		articleId = objectInput.readUTF();

		totalGuests = objectInput.readInt();

		bedrooms = objectInput.readInt();

		sharedProperty = objectInput.readBoolean();
		availableFrom = objectInput.readLong();

		active = objectInput.readBoolean();

		status = objectInput.readInt();

		statusByUserId = objectInput.readLong();
		statusUpdatedDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(hostPropertyId);

		objectOutput.writeLong(createdByUserId);
		objectOutput.writeLong(createDate);

		objectOutput.writeLong(lastModifiedByUserId);
		objectOutput.writeLong(modifiedDate);

		if (articleId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(articleId);
		}

		objectOutput.writeInt(totalGuests);

		objectOutput.writeInt(bedrooms);

		objectOutput.writeBoolean(sharedProperty);
		objectOutput.writeLong(availableFrom);

		objectOutput.writeBoolean(active);

		objectOutput.writeInt(status);

		objectOutput.writeLong(statusByUserId);
		objectOutput.writeLong(statusUpdatedDate);
	}

	public long hostPropertyId;
	public long createdByUserId;
	public long createDate;
	public long lastModifiedByUserId;
	public long modifiedDate;
	public String articleId;
	public int totalGuests;
	public int bedrooms;
	public boolean sharedProperty;
	public long availableFrom;
	public boolean active;
	public int status;
	public long statusByUserId;
	public long statusUpdatedDate;

}