/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.impl;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.petra.sql.dsl.DSLQueryFactoryUtil;
import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyPricingException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricingTable;
import com.sidgs.luxury.homes.property.hosting.lookup.service.base.PropertyPricingLocalServiceBaseImpl;

import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing",
	service = AopService.class
)
public class PropertyPricingLocalServiceImpl extends PropertyPricingLocalServiceBaseImpl {
	private static final Log log = LogFactoryUtil.getLog(PropertyPricingLocalServiceImpl.class);
	public PropertyPricing addPropertyLocation(long hostPropertyId, long floorId, String currency, double basePrice) {
		PropertyPricing propertyPricing = propertyPricingPersistence.create(CounterLocalServiceUtil.increment(PropertyPricing.class.getName()));
		propertyPricing.setHostPropertyId(hostPropertyId);
		propertyPricing.setFloorId(floorId);
		propertyPricing.setCurrency(currency);
		propertyPricing.setBasePrice(basePrice);
		propertyPricing = propertyPricingPersistence.update(propertyPricing);
		log.info("Property Pricing added into PropertyPricing table with propertyId ::"+propertyPricing.getHostPropertyId());
		return propertyPricing;
	}
	
	public List<PropertyPricing> getPropertyPricingByHostPropertyId(long hostPropertyId) {
		return propertyPricingPersistence.findByHostPropertyId(hostPropertyId);
	}
	
	public PropertyPricing getPropertyPricingByFloorId(long floorId) throws NoSuchPropertyPricingException {
		return propertyPricingPersistence.findByFloorId(floorId);
	}
	
	public List<PropertyPricing> getPropertyPricingByFloorId(double startValue, double endValue) {
		DSLQuery dslQuery = DSLQueryFactoryUtil
			    .select().from(PropertyPricingTable.INSTANCE)
			    .where(PropertyPricingTable.INSTANCE.basePrice.gte(startValue).and(PropertyPricingTable.INSTANCE.basePrice.lte(endValue)));
		return propertyPricingPersistence.dslQuery(dslQuery);
	}
}