/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyFloorException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloorTable;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorModelImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.PropertyFloorPersistence;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.PropertyFloorUtil;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.constants.SIDPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the property floor service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = PropertyFloorPersistence.class)
public class PropertyFloorPersistenceImpl
	extends BasePersistenceImpl<PropertyFloor>
	implements PropertyFloorPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>PropertyFloorUtil</code> to access the property floor persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		PropertyFloorImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByHostPropertyId;
	private FinderPath _finderPathWithoutPaginationFindByHostPropertyId;
	private FinderPath _finderPathCountByHostPropertyId;

	/**
	 * Returns all the property floors where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property floors
	 */
	@Override
	public List<PropertyFloor> findByHostPropertyId(long hostPropertyId) {
		return findByHostPropertyId(
			hostPropertyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end) {

		return findByHostPropertyId(hostPropertyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return findByHostPropertyId(
			hostPropertyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByHostPropertyId;
				finderArgs = new Object[] {hostPropertyId};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByHostPropertyId;
			finderArgs = new Object[] {
				hostPropertyId, start, end, orderByComparator
			};
		}

		List<PropertyFloor> list = null;

		if (useFinderCache) {
			list = (List<PropertyFloor>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyFloor propertyFloor : list) {
					if (hostPropertyId != propertyFloor.getHostPropertyId()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(hostPropertyId);

				list = (List<PropertyFloor>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByHostPropertyId_First(
			long hostPropertyId,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByHostPropertyId_First(
			hostPropertyId, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("hostPropertyId=");
		sb.append(hostPropertyId);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the first property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByHostPropertyId_First(
		long hostPropertyId,
		OrderByComparator<PropertyFloor> orderByComparator) {

		List<PropertyFloor> list = findByHostPropertyId(
			hostPropertyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByHostPropertyId_Last(
			long hostPropertyId,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByHostPropertyId_Last(
			hostPropertyId, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("hostPropertyId=");
		sb.append(hostPropertyId);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the last property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByHostPropertyId_Last(
		long hostPropertyId,
		OrderByComparator<PropertyFloor> orderByComparator) {

		int count = countByHostPropertyId(hostPropertyId);

		if (count == 0) {
			return null;
		}

		List<PropertyFloor> list = findByHostPropertyId(
			hostPropertyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor[] findByHostPropertyId_PrevAndNext(
			long floorId, long hostPropertyId,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = findByPrimaryKey(floorId);

		Session session = null;

		try {
			session = openSession();

			PropertyFloor[] array = new PropertyFloorImpl[3];

			array[0] = getByHostPropertyId_PrevAndNext(
				session, propertyFloor, hostPropertyId, orderByComparator,
				true);

			array[1] = propertyFloor;

			array[2] = getByHostPropertyId_PrevAndNext(
				session, propertyFloor, hostPropertyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyFloor getByHostPropertyId_PrevAndNext(
		Session session, PropertyFloor propertyFloor, long hostPropertyId,
		OrderByComparator<PropertyFloor> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

		sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(hostPropertyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyFloor)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyFloor> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property floors where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 */
	@Override
	public void removeByHostPropertyId(long hostPropertyId) {
		for (PropertyFloor propertyFloor :
				findByHostPropertyId(
					hostPropertyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(propertyFloor);
		}
	}

	/**
	 * Returns the number of property floors where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property floors
	 */
	@Override
	public int countByHostPropertyId(long hostPropertyId) {
		FinderPath finderPath = _finderPathCountByHostPropertyId;

		Object[] finderArgs = new Object[] {hostPropertyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(hostPropertyId);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2 =
		"propertyFloor.hostPropertyId = ?";

	private FinderPath _finderPathWithPaginationFindByTotalGuests;
	private FinderPath _finderPathWithoutPaginationFindByTotalGuests;
	private FinderPath _finderPathCountByTotalGuests;

	/**
	 * Returns all the property floors where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @return the matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests(int totalGuests) {
		return findByTotalGuests(
			totalGuests, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end) {

		return findByTotalGuests(totalGuests, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return findByTotalGuests(
			totalGuests, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByTotalGuests;
				finderArgs = new Object[] {totalGuests};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByTotalGuests;
			finderArgs = new Object[] {
				totalGuests, start, end, orderByComparator
			};
		}

		List<PropertyFloor> list = null;

		if (useFinderCache) {
			list = (List<PropertyFloor>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyFloor propertyFloor : list) {
					if (totalGuests != propertyFloor.getTotalGuests()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_TOTALGUESTS_TOTALGUESTS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(totalGuests);

				list = (List<PropertyFloor>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByTotalGuests_First(
			int totalGuests, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByTotalGuests_First(
			totalGuests, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("totalGuests=");
		sb.append(totalGuests);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByTotalGuests_First(
		int totalGuests, OrderByComparator<PropertyFloor> orderByComparator) {

		List<PropertyFloor> list = findByTotalGuests(
			totalGuests, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByTotalGuests_Last(
			int totalGuests, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByTotalGuests_Last(
			totalGuests, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("totalGuests=");
		sb.append(totalGuests);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByTotalGuests_Last(
		int totalGuests, OrderByComparator<PropertyFloor> orderByComparator) {

		int count = countByTotalGuests(totalGuests);

		if (count == 0) {
			return null;
		}

		List<PropertyFloor> list = findByTotalGuests(
			totalGuests, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor[] findByTotalGuests_PrevAndNext(
			long floorId, int totalGuests,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = findByPrimaryKey(floorId);

		Session session = null;

		try {
			session = openSession();

			PropertyFloor[] array = new PropertyFloorImpl[3];

			array[0] = getByTotalGuests_PrevAndNext(
				session, propertyFloor, totalGuests, orderByComparator, true);

			array[1] = propertyFloor;

			array[2] = getByTotalGuests_PrevAndNext(
				session, propertyFloor, totalGuests, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyFloor getByTotalGuests_PrevAndNext(
		Session session, PropertyFloor propertyFloor, int totalGuests,
		OrderByComparator<PropertyFloor> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

		sb.append(_FINDER_COLUMN_TOTALGUESTS_TOTALGUESTS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(totalGuests);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyFloor)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyFloor> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property floors where totalGuests = &#63; from the database.
	 *
	 * @param totalGuests the total guests
	 */
	@Override
	public void removeByTotalGuests(int totalGuests) {
		for (PropertyFloor propertyFloor :
				findByTotalGuests(
					totalGuests, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyFloor);
		}
	}

	/**
	 * Returns the number of property floors where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @return the number of matching property floors
	 */
	@Override
	public int countByTotalGuests(int totalGuests) {
		FinderPath finderPath = _finderPathCountByTotalGuests;

		Object[] finderArgs = new Object[] {totalGuests};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_TOTALGUESTS_TOTALGUESTS_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(totalGuests);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TOTALGUESTS_TOTALGUESTS_2 =
		"propertyFloor.totalGuests = ?";

	private FinderPath _finderPathWithPaginationFindByBedrooms;
	private FinderPath _finderPathWithoutPaginationFindByBedrooms;
	private FinderPath _finderPathCountByBedrooms;

	/**
	 * Returns all the property floors where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @return the matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBedrooms(int bedrooms) {
		return findByBedrooms(
			bedrooms, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end) {

		return findByBedrooms(bedrooms, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return findByBedrooms(bedrooms, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByBedrooms;
				finderArgs = new Object[] {bedrooms};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByBedrooms;
			finderArgs = new Object[] {bedrooms, start, end, orderByComparator};
		}

		List<PropertyFloor> list = null;

		if (useFinderCache) {
			list = (List<PropertyFloor>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyFloor propertyFloor : list) {
					if (bedrooms != propertyFloor.getBedrooms()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_BEDROOMS_BEDROOMS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(bedrooms);

				list = (List<PropertyFloor>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByBedrooms_First(
			int bedrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByBedrooms_First(
			bedrooms, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("bedrooms=");
		sb.append(bedrooms);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the first property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByBedrooms_First(
		int bedrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		List<PropertyFloor> list = findByBedrooms(
			bedrooms, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByBedrooms_Last(
			int bedrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByBedrooms_Last(
			bedrooms, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("bedrooms=");
		sb.append(bedrooms);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the last property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByBedrooms_Last(
		int bedrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		int count = countByBedrooms(bedrooms);

		if (count == 0) {
			return null;
		}

		List<PropertyFloor> list = findByBedrooms(
			bedrooms, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor[] findByBedrooms_PrevAndNext(
			long floorId, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = findByPrimaryKey(floorId);

		Session session = null;

		try {
			session = openSession();

			PropertyFloor[] array = new PropertyFloorImpl[3];

			array[0] = getByBedrooms_PrevAndNext(
				session, propertyFloor, bedrooms, orderByComparator, true);

			array[1] = propertyFloor;

			array[2] = getByBedrooms_PrevAndNext(
				session, propertyFloor, bedrooms, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyFloor getByBedrooms_PrevAndNext(
		Session session, PropertyFloor propertyFloor, int bedrooms,
		OrderByComparator<PropertyFloor> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

		sb.append(_FINDER_COLUMN_BEDROOMS_BEDROOMS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(bedrooms);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyFloor)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyFloor> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property floors where bedrooms = &#63; from the database.
	 *
	 * @param bedrooms the bedrooms
	 */
	@Override
	public void removeByBedrooms(int bedrooms) {
		for (PropertyFloor propertyFloor :
				findByBedrooms(
					bedrooms, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyFloor);
		}
	}

	/**
	 * Returns the number of property floors where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @return the number of matching property floors
	 */
	@Override
	public int countByBedrooms(int bedrooms) {
		FinderPath finderPath = _finderPathCountByBedrooms;

		Object[] finderArgs = new Object[] {bedrooms};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_BEDROOMS_BEDROOMS_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(bedrooms);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BEDROOMS_BEDROOMS_2 =
		"propertyFloor.bedrooms = ?";

	private FinderPath _finderPathWithPaginationFindByTotalGuests_Bedrooms;
	private FinderPath _finderPathWithoutPaginationFindByTotalGuests_Bedrooms;
	private FinderPath _finderPathCountByTotalGuests_Bedrooms;

	/**
	 * Returns all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @return the matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms) {

		return findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end) {

		return findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath =
					_finderPathWithoutPaginationFindByTotalGuests_Bedrooms;
				finderArgs = new Object[] {totalGuests, bedrooms};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByTotalGuests_Bedrooms;
			finderArgs = new Object[] {
				totalGuests, bedrooms, start, end, orderByComparator
			};
		}

		List<PropertyFloor> list = null;

		if (useFinderCache) {
			list = (List<PropertyFloor>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyFloor propertyFloor : list) {
					if ((totalGuests != propertyFloor.getTotalGuests()) ||
						(bedrooms != propertyFloor.getBedrooms())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(4);
			}

			sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_TOTALGUESTS_BEDROOMS_TOTALGUESTS_2);

			sb.append(_FINDER_COLUMN_TOTALGUESTS_BEDROOMS_BEDROOMS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(totalGuests);

				queryPos.add(bedrooms);

				list = (List<PropertyFloor>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByTotalGuests_Bedrooms_First(
			int totalGuests, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByTotalGuests_Bedrooms_First(
			totalGuests, bedrooms, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("totalGuests=");
		sb.append(totalGuests);

		sb.append(", bedrooms=");
		sb.append(bedrooms);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByTotalGuests_Bedrooms_First(
		int totalGuests, int bedrooms,
		OrderByComparator<PropertyFloor> orderByComparator) {

		List<PropertyFloor> list = findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByTotalGuests_Bedrooms_Last(
			int totalGuests, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByTotalGuests_Bedrooms_Last(
			totalGuests, bedrooms, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("totalGuests=");
		sb.append(totalGuests);

		sb.append(", bedrooms=");
		sb.append(bedrooms);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByTotalGuests_Bedrooms_Last(
		int totalGuests, int bedrooms,
		OrderByComparator<PropertyFloor> orderByComparator) {

		int count = countByTotalGuests_Bedrooms(totalGuests, bedrooms);

		if (count == 0) {
			return null;
		}

		List<PropertyFloor> list = findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor[] findByTotalGuests_Bedrooms_PrevAndNext(
			long floorId, int totalGuests, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = findByPrimaryKey(floorId);

		Session session = null;

		try {
			session = openSession();

			PropertyFloor[] array = new PropertyFloorImpl[3];

			array[0] = getByTotalGuests_Bedrooms_PrevAndNext(
				session, propertyFloor, totalGuests, bedrooms,
				orderByComparator, true);

			array[1] = propertyFloor;

			array[2] = getByTotalGuests_Bedrooms_PrevAndNext(
				session, propertyFloor, totalGuests, bedrooms,
				orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyFloor getByTotalGuests_Bedrooms_PrevAndNext(
		Session session, PropertyFloor propertyFloor, int totalGuests,
		int bedrooms, OrderByComparator<PropertyFloor> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(4);
		}

		sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

		sb.append(_FINDER_COLUMN_TOTALGUESTS_BEDROOMS_TOTALGUESTS_2);

		sb.append(_FINDER_COLUMN_TOTALGUESTS_BEDROOMS_BEDROOMS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(totalGuests);

		queryPos.add(bedrooms);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyFloor)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyFloor> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property floors where totalGuests = &#63; and bedrooms = &#63; from the database.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 */
	@Override
	public void removeByTotalGuests_Bedrooms(int totalGuests, int bedrooms) {
		for (PropertyFloor propertyFloor :
				findByTotalGuests_Bedrooms(
					totalGuests, bedrooms, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(propertyFloor);
		}
	}

	/**
	 * Returns the number of property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @return the number of matching property floors
	 */
	@Override
	public int countByTotalGuests_Bedrooms(int totalGuests, int bedrooms) {
		FinderPath finderPath = _finderPathCountByTotalGuests_Bedrooms;

		Object[] finderArgs = new Object[] {totalGuests, bedrooms};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_COUNT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_TOTALGUESTS_BEDROOMS_TOTALGUESTS_2);

			sb.append(_FINDER_COLUMN_TOTALGUESTS_BEDROOMS_BEDROOMS_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(totalGuests);

				queryPos.add(bedrooms);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_TOTALGUESTS_BEDROOMS_TOTALGUESTS_2 =
			"propertyFloor.totalGuests = ? AND ";

	private static final String _FINDER_COLUMN_TOTALGUESTS_BEDROOMS_BEDROOMS_2 =
		"propertyFloor.bedrooms = ?";

	private FinderPath _finderPathWithPaginationFindByBeds;
	private FinderPath _finderPathWithoutPaginationFindByBeds;
	private FinderPath _finderPathCountByBeds;

	/**
	 * Returns all the property floors where beds = &#63;.
	 *
	 * @param beds the beds
	 * @return the matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBeds(int beds) {
		return findByBeds(beds, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBeds(int beds, int start, int end) {
		return findByBeds(beds, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBeds(
		int beds, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return findByBeds(beds, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBeds(
		int beds, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByBeds;
				finderArgs = new Object[] {beds};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByBeds;
			finderArgs = new Object[] {beds, start, end, orderByComparator};
		}

		List<PropertyFloor> list = null;

		if (useFinderCache) {
			list = (List<PropertyFloor>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyFloor propertyFloor : list) {
					if (beds != propertyFloor.getBeds()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_BEDS_BEDS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(beds);

				list = (List<PropertyFloor>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByBeds_First(
			int beds, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByBeds_First(
			beds, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("beds=");
		sb.append(beds);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the first property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByBeds_First(
		int beds, OrderByComparator<PropertyFloor> orderByComparator) {

		List<PropertyFloor> list = findByBeds(beds, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByBeds_Last(
			int beds, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByBeds_Last(beds, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("beds=");
		sb.append(beds);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the last property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByBeds_Last(
		int beds, OrderByComparator<PropertyFloor> orderByComparator) {

		int count = countByBeds(beds);

		if (count == 0) {
			return null;
		}

		List<PropertyFloor> list = findByBeds(
			beds, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where beds = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor[] findByBeds_PrevAndNext(
			long floorId, int beds,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = findByPrimaryKey(floorId);

		Session session = null;

		try {
			session = openSession();

			PropertyFloor[] array = new PropertyFloorImpl[3];

			array[0] = getByBeds_PrevAndNext(
				session, propertyFloor, beds, orderByComparator, true);

			array[1] = propertyFloor;

			array[2] = getByBeds_PrevAndNext(
				session, propertyFloor, beds, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyFloor getByBeds_PrevAndNext(
		Session session, PropertyFloor propertyFloor, int beds,
		OrderByComparator<PropertyFloor> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

		sb.append(_FINDER_COLUMN_BEDS_BEDS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(beds);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyFloor)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyFloor> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property floors where beds = &#63; from the database.
	 *
	 * @param beds the beds
	 */
	@Override
	public void removeByBeds(int beds) {
		for (PropertyFloor propertyFloor :
				findByBeds(beds, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyFloor);
		}
	}

	/**
	 * Returns the number of property floors where beds = &#63;.
	 *
	 * @param beds the beds
	 * @return the number of matching property floors
	 */
	@Override
	public int countByBeds(int beds) {
		FinderPath finderPath = _finderPathCountByBeds;

		Object[] finderArgs = new Object[] {beds};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_BEDS_BEDS_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(beds);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BEDS_BEDS_2 =
		"propertyFloor.beds = ?";

	private FinderPath _finderPathWithPaginationFindByBathrooms;
	private FinderPath _finderPathWithoutPaginationFindByBathrooms;
	private FinderPath _finderPathCountByBathrooms;

	/**
	 * Returns all the property floors where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @return the matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBathrooms(int bathrooms) {
		return findByBathrooms(
			bathrooms, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end) {

		return findByBathrooms(bathrooms, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return findByBathrooms(bathrooms, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	@Override
	public List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByBathrooms;
				finderArgs = new Object[] {bathrooms};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByBathrooms;
			finderArgs = new Object[] {
				bathrooms, start, end, orderByComparator
			};
		}

		List<PropertyFloor> list = null;

		if (useFinderCache) {
			list = (List<PropertyFloor>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyFloor propertyFloor : list) {
					if (bathrooms != propertyFloor.getBathrooms()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_BATHROOMS_BATHROOMS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(bathrooms);

				list = (List<PropertyFloor>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByBathrooms_First(
			int bathrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByBathrooms_First(
			bathrooms, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("bathrooms=");
		sb.append(bathrooms);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the first property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByBathrooms_First(
		int bathrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		List<PropertyFloor> list = findByBathrooms(
			bathrooms, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor findByBathrooms_Last(
			int bathrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByBathrooms_Last(
			bathrooms, orderByComparator);

		if (propertyFloor != null) {
			return propertyFloor;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("bathrooms=");
		sb.append(bathrooms);

		sb.append("}");

		throw new NoSuchPropertyFloorException(sb.toString());
	}

	/**
	 * Returns the last property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	@Override
	public PropertyFloor fetchByBathrooms_Last(
		int bathrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		int count = countByBathrooms(bathrooms);

		if (count == 0) {
			return null;
		}

		List<PropertyFloor> list = findByBathrooms(
			bathrooms, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor[] findByBathrooms_PrevAndNext(
			long floorId, int bathrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = findByPrimaryKey(floorId);

		Session session = null;

		try {
			session = openSession();

			PropertyFloor[] array = new PropertyFloorImpl[3];

			array[0] = getByBathrooms_PrevAndNext(
				session, propertyFloor, bathrooms, orderByComparator, true);

			array[1] = propertyFloor;

			array[2] = getByBathrooms_PrevAndNext(
				session, propertyFloor, bathrooms, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyFloor getByBathrooms_PrevAndNext(
		Session session, PropertyFloor propertyFloor, int bathrooms,
		OrderByComparator<PropertyFloor> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYFLOOR_WHERE);

		sb.append(_FINDER_COLUMN_BATHROOMS_BATHROOMS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyFloorModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(bathrooms);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyFloor)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyFloor> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property floors where bathrooms = &#63; from the database.
	 *
	 * @param bathrooms the bathrooms
	 */
	@Override
	public void removeByBathrooms(int bathrooms) {
		for (PropertyFloor propertyFloor :
				findByBathrooms(
					bathrooms, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyFloor);
		}
	}

	/**
	 * Returns the number of property floors where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @return the number of matching property floors
	 */
	@Override
	public int countByBathrooms(int bathrooms) {
		FinderPath finderPath = _finderPathCountByBathrooms;

		Object[] finderArgs = new Object[] {bathrooms};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYFLOOR_WHERE);

			sb.append(_FINDER_COLUMN_BATHROOMS_BATHROOMS_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(bathrooms);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BATHROOMS_BATHROOMS_2 =
		"propertyFloor.bathrooms = ?";

	public PropertyFloorPersistenceImpl() {
		setModelClass(PropertyFloor.class);

		setModelImplClass(PropertyFloorImpl.class);
		setModelPKClass(long.class);

		setTable(PropertyFloorTable.INSTANCE);
	}

	/**
	 * Caches the property floor in the entity cache if it is enabled.
	 *
	 * @param propertyFloor the property floor
	 */
	@Override
	public void cacheResult(PropertyFloor propertyFloor) {
		entityCache.putResult(
			PropertyFloorImpl.class, propertyFloor.getPrimaryKey(),
			propertyFloor);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the property floors in the entity cache if it is enabled.
	 *
	 * @param propertyFloors the property floors
	 */
	@Override
	public void cacheResult(List<PropertyFloor> propertyFloors) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (propertyFloors.size() > _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (PropertyFloor propertyFloor : propertyFloors) {
			if (entityCache.getResult(
					PropertyFloorImpl.class, propertyFloor.getPrimaryKey()) ==
						null) {

				cacheResult(propertyFloor);
			}
		}
	}

	/**
	 * Clears the cache for all property floors.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(PropertyFloorImpl.class);

		finderCache.clearCache(PropertyFloorImpl.class);
	}

	/**
	 * Clears the cache for the property floor.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(PropertyFloor propertyFloor) {
		entityCache.removeResult(PropertyFloorImpl.class, propertyFloor);
	}

	@Override
	public void clearCache(List<PropertyFloor> propertyFloors) {
		for (PropertyFloor propertyFloor : propertyFloors) {
			entityCache.removeResult(PropertyFloorImpl.class, propertyFloor);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(PropertyFloorImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(PropertyFloorImpl.class, primaryKey);
		}
	}

	/**
	 * Creates a new property floor with the primary key. Does not add the property floor to the database.
	 *
	 * @param floorId the primary key for the new property floor
	 * @return the new property floor
	 */
	@Override
	public PropertyFloor create(long floorId) {
		PropertyFloor propertyFloor = new PropertyFloorImpl();

		propertyFloor.setNew(true);
		propertyFloor.setPrimaryKey(floorId);

		return propertyFloor;
	}

	/**
	 * Removes the property floor with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor that was removed
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor remove(long floorId)
		throws NoSuchPropertyFloorException {

		return remove((Serializable)floorId);
	}

	/**
	 * Removes the property floor with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the property floor
	 * @return the property floor that was removed
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor remove(Serializable primaryKey)
		throws NoSuchPropertyFloorException {

		Session session = null;

		try {
			session = openSession();

			PropertyFloor propertyFloor = (PropertyFloor)session.get(
				PropertyFloorImpl.class, primaryKey);

			if (propertyFloor == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchPropertyFloorException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(propertyFloor);
		}
		catch (NoSuchPropertyFloorException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected PropertyFloor removeImpl(PropertyFloor propertyFloor) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(propertyFloor)) {
				propertyFloor = (PropertyFloor)session.get(
					PropertyFloorImpl.class, propertyFloor.getPrimaryKeyObj());
			}

			if (propertyFloor != null) {
				session.delete(propertyFloor);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (propertyFloor != null) {
			clearCache(propertyFloor);
		}

		return propertyFloor;
	}

	@Override
	public PropertyFloor updateImpl(PropertyFloor propertyFloor) {
		boolean isNew = propertyFloor.isNew();

		if (!(propertyFloor instanceof PropertyFloorModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(propertyFloor.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					propertyFloor);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in propertyFloor proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom PropertyFloor implementation " +
					propertyFloor.getClass());
		}

		PropertyFloorModelImpl propertyFloorModelImpl =
			(PropertyFloorModelImpl)propertyFloor;

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(propertyFloor);
			}
			else {
				propertyFloor = (PropertyFloor)session.merge(propertyFloor);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			PropertyFloorImpl.class, propertyFloorModelImpl, false, true);

		if (isNew) {
			propertyFloor.setNew(false);
		}

		propertyFloor.resetOriginalValues();

		return propertyFloor;
	}

	/**
	 * Returns the property floor with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the property floor
	 * @return the property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor findByPrimaryKey(Serializable primaryKey)
		throws NoSuchPropertyFloorException {

		PropertyFloor propertyFloor = fetchByPrimaryKey(primaryKey);

		if (propertyFloor == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchPropertyFloorException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return propertyFloor;
	}

	/**
	 * Returns the property floor with the primary key or throws a <code>NoSuchPropertyFloorException</code> if it could not be found.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor findByPrimaryKey(long floorId)
		throws NoSuchPropertyFloorException {

		return findByPrimaryKey((Serializable)floorId);
	}

	/**
	 * Returns the property floor with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor, or <code>null</code> if a property floor with the primary key could not be found
	 */
	@Override
	public PropertyFloor fetchByPrimaryKey(long floorId) {
		return fetchByPrimaryKey((Serializable)floorId);
	}

	/**
	 * Returns all the property floors.
	 *
	 * @return the property floors
	 */
	@Override
	public List<PropertyFloor> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of property floors
	 */
	@Override
	public List<PropertyFloor> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property floors
	 */
	@Override
	public List<PropertyFloor> findAll(
		int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property floors
	 */
	@Override
	public List<PropertyFloor> findAll(
		int start, int end, OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<PropertyFloor> list = null;

		if (useFinderCache) {
			list = (List<PropertyFloor>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_PROPERTYFLOOR);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_PROPERTYFLOOR;

				sql = sql.concat(PropertyFloorModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<PropertyFloor>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the property floors from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (PropertyFloor propertyFloor : findAll()) {
			remove(propertyFloor);
		}
	}

	/**
	 * Returns the number of property floors.
	 *
	 * @return the number of property floors
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_PROPERTYFLOOR);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "floorId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_PROPERTYFLOOR;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return PropertyFloorModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the property floor persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathWithPaginationFindByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByHostPropertyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"hostPropertyId"}, true);

		_finderPathWithoutPaginationFindByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByHostPropertyId",
			new String[] {Long.class.getName()},
			new String[] {"hostPropertyId"}, true);

		_finderPathCountByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByHostPropertyId",
			new String[] {Long.class.getName()},
			new String[] {"hostPropertyId"}, false);

		_finderPathWithPaginationFindByTotalGuests = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByTotalGuests",
			new String[] {
				Integer.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"totalGuests"}, true);

		_finderPathWithoutPaginationFindByTotalGuests = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByTotalGuests",
			new String[] {Integer.class.getName()},
			new String[] {"totalGuests"}, true);

		_finderPathCountByTotalGuests = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByTotalGuests",
			new String[] {Integer.class.getName()},
			new String[] {"totalGuests"}, false);

		_finderPathWithPaginationFindByBedrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByBedrooms",
			new String[] {
				Integer.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"bedrooms"}, true);

		_finderPathWithoutPaginationFindByBedrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByBedrooms",
			new String[] {Integer.class.getName()}, new String[] {"bedrooms"},
			true);

		_finderPathCountByBedrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByBedrooms",
			new String[] {Integer.class.getName()}, new String[] {"bedrooms"},
			false);

		_finderPathWithPaginationFindByTotalGuests_Bedrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByTotalGuests_Bedrooms",
			new String[] {
				Integer.class.getName(), Integer.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			},
			new String[] {"totalGuests", "bedrooms"}, true);

		_finderPathWithoutPaginationFindByTotalGuests_Bedrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByTotalGuests_Bedrooms",
			new String[] {Integer.class.getName(), Integer.class.getName()},
			new String[] {"totalGuests", "bedrooms"}, true);

		_finderPathCountByTotalGuests_Bedrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByTotalGuests_Bedrooms",
			new String[] {Integer.class.getName(), Integer.class.getName()},
			new String[] {"totalGuests", "bedrooms"}, false);

		_finderPathWithPaginationFindByBeds = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByBeds",
			new String[] {
				Integer.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"beds"}, true);

		_finderPathWithoutPaginationFindByBeds = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByBeds",
			new String[] {Integer.class.getName()}, new String[] {"beds"},
			true);

		_finderPathCountByBeds = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByBeds",
			new String[] {Integer.class.getName()}, new String[] {"beds"},
			false);

		_finderPathWithPaginationFindByBathrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByBathrooms",
			new String[] {
				Integer.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"bathrooms"}, true);

		_finderPathWithoutPaginationFindByBathrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByBathrooms",
			new String[] {Integer.class.getName()}, new String[] {"bathrooms"},
			true);

		_finderPathCountByBathrooms = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByBathrooms",
			new String[] {Integer.class.getName()}, new String[] {"bathrooms"},
			false);

		PropertyFloorUtil.setPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		PropertyFloorUtil.setPersistence(null);

		entityCache.removeCache(PropertyFloorImpl.class.getName());
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_PROPERTYFLOOR =
		"SELECT propertyFloor FROM PropertyFloor propertyFloor";

	private static final String _SQL_SELECT_PROPERTYFLOOR_WHERE =
		"SELECT propertyFloor FROM PropertyFloor propertyFloor WHERE ";

	private static final String _SQL_COUNT_PROPERTYFLOOR =
		"SELECT COUNT(propertyFloor) FROM PropertyFloor propertyFloor";

	private static final String _SQL_COUNT_PROPERTYFLOOR_WHERE =
		"SELECT COUNT(propertyFloor) FROM PropertyFloor propertyFloor WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "propertyFloor.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No PropertyFloor exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No PropertyFloor exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		PropertyFloorPersistenceImpl.class);

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

}