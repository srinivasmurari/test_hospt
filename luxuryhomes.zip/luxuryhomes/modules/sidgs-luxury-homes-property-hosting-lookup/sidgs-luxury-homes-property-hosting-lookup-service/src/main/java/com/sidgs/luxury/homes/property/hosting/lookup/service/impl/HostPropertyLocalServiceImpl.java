/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.impl;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.petra.sql.dsl.DSLQueryFactoryUtil;
import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchHostPropertyException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty;
import com.sidgs.luxury.homes.property.hosting.lookup.model.HostPropertyTable;
import com.sidgs.luxury.homes.property.hosting.lookup.service.base.HostPropertyLocalServiceBaseImpl;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty",
	service = AopService.class
)
public class HostPropertyLocalServiceImpl extends HostPropertyLocalServiceBaseImpl {
	
private static final Log log = LogFactoryUtil.getLog(HostPropertyLocalServiceImpl.class);
	
	public HostProperty addHostProperty(long userId, String articleId, int totalGuests, int bedrooms, Date availableFrom) {
		HostProperty hostProperty = hostPropertyPersistence.create(CounterLocalServiceUtil.increment(HostProperty.class.getName()));
		Date date = new Date();
		hostProperty.setCreatedByUserId(userId);
		hostProperty.setCreateDate(date);
		hostProperty.setLastModifiedByUserId(userId);
		hostProperty.setModifiedDate(date);
		hostProperty.setArticleId(articleId);
		hostProperty.setTotalGuests(totalGuests);
		hostProperty.setBedrooms(bedrooms);
		hostProperty.setSharedProperty(Boolean.FALSE);
		hostProperty.setAvailableFrom(availableFrom);
		hostProperty.setActive(Boolean.TRUE);
		hostProperty.setStatus(WorkflowConstants.ACTION_PUBLISH);
		hostProperty.setStatusByUserId(userId);
		hostProperty.setStatusUpdatedDate(date);
		hostProperty = hostPropertyPersistence.update(hostProperty);
		log.info("Property added into HostProperty table with propertyId ::"+hostProperty.getHostPropertyId());
		return hostProperty;
	}
	
	public HostProperty getPropertyByArticleId(String articleId) throws NoSuchHostPropertyException {
		return hostPropertyPersistence.findByArticleId(articleId);
	}
	
	public List<HostProperty> getPropertyByUserIdAndFlag(long userId, boolean active) {
		return hostPropertyPersistence.findByUserId_Active(userId, active);
	}
	
	public List<HostProperty> getPropertyByFlag(boolean active) {
		return hostPropertyPersistence.findByActive(active);
	}
	
	public List<HostProperty> getPropertyFromAvailableDate(Date startDate) {
		DSLQuery dslQuery = DSLQueryFactoryUtil
			    .select().from(HostPropertyTable.INSTANCE)
			    .where(HostPropertyTable.INSTANCE.availableFrom.gte(startDate));
		return hostPropertyPersistence.dslQuery(dslQuery);
	}
	
}