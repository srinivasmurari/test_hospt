/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.impl;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyLocationException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation;
import com.sidgs.luxury.homes.property.hosting.lookup.service.base.PropertyLocationLocalServiceBaseImpl;

import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation",
	service = AopService.class
)
public class PropertyLocationLocalServiceImpl extends PropertyLocationLocalServiceBaseImpl {
	private static final Log log = LogFactoryUtil.getLog(PropertyLocationLocalServiceImpl.class);
	public PropertyLocation addPropertyLocation(long hostPropertyId, JSONObject addressJSON, String coordinates) {
		PropertyLocation propertyLocation = propertyLocationPersistence.create(CounterLocalServiceUtil.increment(PropertyLocation.class.getName()));
		propertyLocation.setHostPropertyId(hostPropertyId);
		propertyLocation.setPlotNo(addressJSON.getString("PlotNo"));
		propertyLocation.setStreet(addressJSON.getString("Street"));
		propertyLocation.setLandmark(addressJSON.getString("Landmark"));
		propertyLocation.setLocality(addressJSON.getString("Locality"));
		propertyLocation.setCity(addressJSON.getString("City"));
		propertyLocation.setState(addressJSON.getString("State"));
		propertyLocation.setCountry(addressJSON.getString("Country"));
		propertyLocation.setZipCode(addressJSON.getString("Zipcode"));
		propertyLocation.setCoordinates(coordinates);
		
		propertyLocation = propertyLocationPersistence.update(propertyLocation);
		log.info("Property Location added into PropertyLocation table with propertyId ::"+propertyLocation.getHostPropertyId());
		return propertyLocation;
	}
	
	public PropertyLocation getPropertyLocationByPropertyId(long hostPropertyId) throws NoSuchPropertyLocationException {
		return propertyLocationPersistence.findByHostPropertyId(hostPropertyId);
	}
	
	public List<PropertyLocation> getPropertyLocationByPropertyId(String locality) {
		return propertyLocationPersistence.findByLocality(locality);
	}
	
	public List<PropertyLocation> getPropertyLocationByState(String state) {
		return propertyLocationPersistence.findByState(state);
	}
	
	public List<PropertyLocation> getPropertyLocationByZipcode(String zipCode) {
		return propertyLocationPersistence.findByZipCode(zipCode);
	}
	
	public List<PropertyLocation> getPropertyLocationByCountry(String country) {
		return propertyLocationPersistence.findByCountry(country);
	}
	
	public List<PropertyLocation> getPropertyLocationByLocalityAndState(String locality, String state) {
		return propertyLocationPersistence.findByLocality_State(locality, state);
	}
	
	public List<PropertyLocation> getPropertyLocationByLocalityAndCountry(String locality, String country) {
		return propertyLocationPersistence.findByLocality_Country(locality, country);
	}
	
	public List<PropertyLocation> getPropertyLocationByStateAndCountry(String state, String country) {
		return propertyLocationPersistence.findByState_Country(state, country);
	}
	
	public List<PropertyLocation> getPropertyLocationByLocalityAndStateAndCountry(String locality, String state, String country) {
		return propertyLocationPersistence.findByLocality_State_Country(locality, state, country);
	}
}