/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link PropertyFloor}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyFloor
 * @generated
 */
public class PropertyFloorWrapper
	extends BaseModelWrapper<PropertyFloor>
	implements ModelWrapper<PropertyFloor>, PropertyFloor {

	public PropertyFloorWrapper(PropertyFloor propertyFloor) {
		super(propertyFloor);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("floorId", getFloorId());
		attributes.put("hostPropertyId", getHostPropertyId());
		attributes.put("totalGuests", getTotalGuests());
		attributes.put("bedrooms", getBedrooms());
		attributes.put("beds", getBeds());
		attributes.put("bathrooms", getBathrooms());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long floorId = (Long)attributes.get("floorId");

		if (floorId != null) {
			setFloorId(floorId);
		}

		Long hostPropertyId = (Long)attributes.get("hostPropertyId");

		if (hostPropertyId != null) {
			setHostPropertyId(hostPropertyId);
		}

		Integer totalGuests = (Integer)attributes.get("totalGuests");

		if (totalGuests != null) {
			setTotalGuests(totalGuests);
		}

		Integer bedrooms = (Integer)attributes.get("bedrooms");

		if (bedrooms != null) {
			setBedrooms(bedrooms);
		}

		Integer beds = (Integer)attributes.get("beds");

		if (beds != null) {
			setBeds(beds);
		}

		Integer bathrooms = (Integer)attributes.get("bathrooms");

		if (bathrooms != null) {
			setBathrooms(bathrooms);
		}
	}

	@Override
	public PropertyFloor cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the bathrooms of this property floor.
	 *
	 * @return the bathrooms of this property floor
	 */
	@Override
	public int getBathrooms() {
		return model.getBathrooms();
	}

	/**
	 * Returns the bedrooms of this property floor.
	 *
	 * @return the bedrooms of this property floor
	 */
	@Override
	public int getBedrooms() {
		return model.getBedrooms();
	}

	/**
	 * Returns the beds of this property floor.
	 *
	 * @return the beds of this property floor
	 */
	@Override
	public int getBeds() {
		return model.getBeds();
	}

	/**
	 * Returns the floor ID of this property floor.
	 *
	 * @return the floor ID of this property floor
	 */
	@Override
	public long getFloorId() {
		return model.getFloorId();
	}

	/**
	 * Returns the host property ID of this property floor.
	 *
	 * @return the host property ID of this property floor
	 */
	@Override
	public long getHostPropertyId() {
		return model.getHostPropertyId();
	}

	/**
	 * Returns the primary key of this property floor.
	 *
	 * @return the primary key of this property floor
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the total guests of this property floor.
	 *
	 * @return the total guests of this property floor
	 */
	@Override
	public int getTotalGuests() {
		return model.getTotalGuests();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the bathrooms of this property floor.
	 *
	 * @param bathrooms the bathrooms of this property floor
	 */
	@Override
	public void setBathrooms(int bathrooms) {
		model.setBathrooms(bathrooms);
	}

	/**
	 * Sets the bedrooms of this property floor.
	 *
	 * @param bedrooms the bedrooms of this property floor
	 */
	@Override
	public void setBedrooms(int bedrooms) {
		model.setBedrooms(bedrooms);
	}

	/**
	 * Sets the beds of this property floor.
	 *
	 * @param beds the beds of this property floor
	 */
	@Override
	public void setBeds(int beds) {
		model.setBeds(beds);
	}

	/**
	 * Sets the floor ID of this property floor.
	 *
	 * @param floorId the floor ID of this property floor
	 */
	@Override
	public void setFloorId(long floorId) {
		model.setFloorId(floorId);
	}

	/**
	 * Sets the host property ID of this property floor.
	 *
	 * @param hostPropertyId the host property ID of this property floor
	 */
	@Override
	public void setHostPropertyId(long hostPropertyId) {
		model.setHostPropertyId(hostPropertyId);
	}

	/**
	 * Sets the primary key of this property floor.
	 *
	 * @param primaryKey the primary key of this property floor
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the total guests of this property floor.
	 *
	 * @param totalGuests the total guests of this property floor
	 */
	@Override
	public void setTotalGuests(int totalGuests) {
		model.setTotalGuests(totalGuests);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected PropertyFloorWrapper wrap(PropertyFloor propertyFloor) {
		return new PropertyFloorWrapper(propertyFloor);
	}

}