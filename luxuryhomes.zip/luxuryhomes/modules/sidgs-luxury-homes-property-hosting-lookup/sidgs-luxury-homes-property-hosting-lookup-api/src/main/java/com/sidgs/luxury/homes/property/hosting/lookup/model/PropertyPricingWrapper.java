/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link PropertyPricing}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyPricing
 * @generated
 */
public class PropertyPricingWrapper
	extends BaseModelWrapper<PropertyPricing>
	implements ModelWrapper<PropertyPricing>, PropertyPricing {

	public PropertyPricingWrapper(PropertyPricing propertyPricing) {
		super(propertyPricing);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("pricingId", getPricingId());
		attributes.put("hostPropertyId", getHostPropertyId());
		attributes.put("floorId", getFloorId());
		attributes.put("currency", getCurrency());
		attributes.put("basePrice", getBasePrice());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long pricingId = (Long)attributes.get("pricingId");

		if (pricingId != null) {
			setPricingId(pricingId);
		}

		Long hostPropertyId = (Long)attributes.get("hostPropertyId");

		if (hostPropertyId != null) {
			setHostPropertyId(hostPropertyId);
		}

		Long floorId = (Long)attributes.get("floorId");

		if (floorId != null) {
			setFloorId(floorId);
		}

		String currency = (String)attributes.get("currency");

		if (currency != null) {
			setCurrency(currency);
		}

		Double basePrice = (Double)attributes.get("basePrice");

		if (basePrice != null) {
			setBasePrice(basePrice);
		}
	}

	@Override
	public PropertyPricing cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the base price of this property pricing.
	 *
	 * @return the base price of this property pricing
	 */
	@Override
	public double getBasePrice() {
		return model.getBasePrice();
	}

	/**
	 * Returns the currency of this property pricing.
	 *
	 * @return the currency of this property pricing
	 */
	@Override
	public String getCurrency() {
		return model.getCurrency();
	}

	/**
	 * Returns the floor ID of this property pricing.
	 *
	 * @return the floor ID of this property pricing
	 */
	@Override
	public long getFloorId() {
		return model.getFloorId();
	}

	/**
	 * Returns the host property ID of this property pricing.
	 *
	 * @return the host property ID of this property pricing
	 */
	@Override
	public long getHostPropertyId() {
		return model.getHostPropertyId();
	}

	/**
	 * Returns the pricing ID of this property pricing.
	 *
	 * @return the pricing ID of this property pricing
	 */
	@Override
	public long getPricingId() {
		return model.getPricingId();
	}

	/**
	 * Returns the primary key of this property pricing.
	 *
	 * @return the primary key of this property pricing
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the base price of this property pricing.
	 *
	 * @param basePrice the base price of this property pricing
	 */
	@Override
	public void setBasePrice(double basePrice) {
		model.setBasePrice(basePrice);
	}

	/**
	 * Sets the currency of this property pricing.
	 *
	 * @param currency the currency of this property pricing
	 */
	@Override
	public void setCurrency(String currency) {
		model.setCurrency(currency);
	}

	/**
	 * Sets the floor ID of this property pricing.
	 *
	 * @param floorId the floor ID of this property pricing
	 */
	@Override
	public void setFloorId(long floorId) {
		model.setFloorId(floorId);
	}

	/**
	 * Sets the host property ID of this property pricing.
	 *
	 * @param hostPropertyId the host property ID of this property pricing
	 */
	@Override
	public void setHostPropertyId(long hostPropertyId) {
		model.setHostPropertyId(hostPropertyId);
	}

	/**
	 * Sets the pricing ID of this property pricing.
	 *
	 * @param pricingId the pricing ID of this property pricing
	 */
	@Override
	public void setPricingId(long pricingId) {
		model.setPricingId(pricingId);
	}

	/**
	 * Sets the primary key of this property pricing.
	 *
	 * @param primaryKey the primary key of this property pricing
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected PropertyPricingWrapper wrap(PropertyPricing propertyPricing) {
		return new PropertyPricingWrapper(propertyPricing);
	}

}