/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyFloorException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the property floor service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyFloorUtil
 * @generated
 */
@ProviderType
public interface PropertyFloorPersistence
	extends BasePersistence<PropertyFloor> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link PropertyFloorUtil} to access the property floor persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the property floors where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property floors
	 */
	public java.util.List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId);

	/**
	 * Returns a range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end);

	/**
	 * Returns an ordered range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByHostPropertyId_First(
			long hostPropertyId,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the first property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByHostPropertyId_First(
		long hostPropertyId,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the last property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByHostPropertyId_Last(
			long hostPropertyId,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the last property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByHostPropertyId_Last(
		long hostPropertyId,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor[] findByHostPropertyId_PrevAndNext(
			long floorId, long hostPropertyId,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Removes all the property floors where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 */
	public void removeByHostPropertyId(long hostPropertyId);

	/**
	 * Returns the number of property floors where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property floors
	 */
	public int countByHostPropertyId(long hostPropertyId);

	/**
	 * Returns all the property floors where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @return the matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests(int totalGuests);

	/**
	 * Returns a range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end);

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByTotalGuests_First(
			int totalGuests,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByTotalGuests_First(
		int totalGuests,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByTotalGuests_Last(
			int totalGuests,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByTotalGuests_Last(
		int totalGuests,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor[] findByTotalGuests_PrevAndNext(
			long floorId, int totalGuests,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Removes all the property floors where totalGuests = &#63; from the database.
	 *
	 * @param totalGuests the total guests
	 */
	public void removeByTotalGuests(int totalGuests);

	/**
	 * Returns the number of property floors where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @return the number of matching property floors
	 */
	public int countByTotalGuests(int totalGuests);

	/**
	 * Returns all the property floors where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @return the matching property floors
	 */
	public java.util.List<PropertyFloor> findByBedrooms(int bedrooms);

	/**
	 * Returns a range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end);

	/**
	 * Returns an ordered range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByBedrooms_First(
			int bedrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the first property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByBedrooms_First(
		int bedrooms,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the last property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByBedrooms_Last(
			int bedrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the last property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByBedrooms_Last(
		int bedrooms,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor[] findByBedrooms_PrevAndNext(
			long floorId, int bedrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Removes all the property floors where bedrooms = &#63; from the database.
	 *
	 * @param bedrooms the bedrooms
	 */
	public void removeByBedrooms(int bedrooms);

	/**
	 * Returns the number of property floors where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @return the number of matching property floors
	 */
	public int countByBedrooms(int bedrooms);

	/**
	 * Returns all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @return the matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms);

	/**
	 * Returns a range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end);

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByTotalGuests_Bedrooms_First(
			int totalGuests, int bedrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByTotalGuests_Bedrooms_First(
		int totalGuests, int bedrooms,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByTotalGuests_Bedrooms_Last(
			int totalGuests, int bedrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByTotalGuests_Bedrooms_Last(
		int totalGuests, int bedrooms,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor[] findByTotalGuests_Bedrooms_PrevAndNext(
			long floorId, int totalGuests, int bedrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Removes all the property floors where totalGuests = &#63; and bedrooms = &#63; from the database.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 */
	public void removeByTotalGuests_Bedrooms(int totalGuests, int bedrooms);

	/**
	 * Returns the number of property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @return the number of matching property floors
	 */
	public int countByTotalGuests_Bedrooms(int totalGuests, int bedrooms);

	/**
	 * Returns all the property floors where beds = &#63;.
	 *
	 * @param beds the beds
	 * @return the matching property floors
	 */
	public java.util.List<PropertyFloor> findByBeds(int beds);

	/**
	 * Returns a range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBeds(
		int beds, int start, int end);

	/**
	 * Returns an ordered range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBeds(
		int beds, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBeds(
		int beds, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByBeds_First(
			int beds,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the first property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByBeds_First(
		int beds,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the last property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByBeds_Last(
			int beds,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the last property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByBeds_Last(
		int beds,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where beds = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor[] findByBeds_PrevAndNext(
			long floorId, int beds,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Removes all the property floors where beds = &#63; from the database.
	 *
	 * @param beds the beds
	 */
	public void removeByBeds(int beds);

	/**
	 * Returns the number of property floors where beds = &#63;.
	 *
	 * @param beds the beds
	 * @return the number of matching property floors
	 */
	public int countByBeds(int beds);

	/**
	 * Returns all the property floors where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @return the matching property floors
	 */
	public java.util.List<PropertyFloor> findByBathrooms(int bathrooms);

	/**
	 * Returns a range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end);

	/**
	 * Returns an ordered range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public java.util.List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByBathrooms_First(
			int bathrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the first property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByBathrooms_First(
		int bathrooms,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the last property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public PropertyFloor findByBathrooms_Last(
			int bathrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the last property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public PropertyFloor fetchByBathrooms_Last(
		int bathrooms,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor[] findByBathrooms_PrevAndNext(
			long floorId, int bathrooms,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
				orderByComparator)
		throws NoSuchPropertyFloorException;

	/**
	 * Removes all the property floors where bathrooms = &#63; from the database.
	 *
	 * @param bathrooms the bathrooms
	 */
	public void removeByBathrooms(int bathrooms);

	/**
	 * Returns the number of property floors where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @return the number of matching property floors
	 */
	public int countByBathrooms(int bathrooms);

	/**
	 * Caches the property floor in the entity cache if it is enabled.
	 *
	 * @param propertyFloor the property floor
	 */
	public void cacheResult(PropertyFloor propertyFloor);

	/**
	 * Caches the property floors in the entity cache if it is enabled.
	 *
	 * @param propertyFloors the property floors
	 */
	public void cacheResult(java.util.List<PropertyFloor> propertyFloors);

	/**
	 * Creates a new property floor with the primary key. Does not add the property floor to the database.
	 *
	 * @param floorId the primary key for the new property floor
	 * @return the new property floor
	 */
	public PropertyFloor create(long floorId);

	/**
	 * Removes the property floor with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor that was removed
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor remove(long floorId)
		throws NoSuchPropertyFloorException;

	public PropertyFloor updateImpl(PropertyFloor propertyFloor);

	/**
	 * Returns the property floor with the primary key or throws a <code>NoSuchPropertyFloorException</code> if it could not be found.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public PropertyFloor findByPrimaryKey(long floorId)
		throws NoSuchPropertyFloorException;

	/**
	 * Returns the property floor with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor, or <code>null</code> if a property floor with the primary key could not be found
	 */
	public PropertyFloor fetchByPrimaryKey(long floorId);

	/**
	 * Returns all the property floors.
	 *
	 * @return the property floors
	 */
	public java.util.List<PropertyFloor> findAll();

	/**
	 * Returns a range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of property floors
	 */
	public java.util.List<PropertyFloor> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property floors
	 */
	public java.util.List<PropertyFloor> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property floors
	 */
	public java.util.List<PropertyFloor> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyFloor>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the property floors from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of property floors.
	 *
	 * @return the number of property floors
	 */
	public int countAll();

}