/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.portal.kernel.annotation.ImplementationClassName;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.util.Accessor;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The extended model interface for the PropertyPricing service. Represents a row in the &quot;SID_PropertyPricing&quot; database table, with each column mapped to a property of this class.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyPricingModel
 * @generated
 */
@ImplementationClassName(
	"com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyPricingImpl"
)
@ProviderType
public interface PropertyPricing extends PersistedModel, PropertyPricingModel {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this interface directly. Add methods to <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyPricingImpl</code> and rerun ServiceBuilder to automatically copy the method declarations to this interface.
	 */
	public static final Accessor<PropertyPricing, Long> PRICING_ID_ACCESSOR =
		new Accessor<PropertyPricing, Long>() {

			@Override
			public Long get(PropertyPricing propertyPricing) {
				return propertyPricing.getPricingId();
			}

			@Override
			public Class<Long> getAttributeClass() {
				return Long.class;
			}

			@Override
			public Class<PropertyPricing> getTypeClass() {
				return PropertyPricing.class;
			}

		};

}