/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service;

import com.liferay.portal.kernel.service.ServiceWrapper;
import com.liferay.portal.kernel.service.persistence.BasePersistence;

/**
 * Provides a wrapper for {@link PropertyFloorLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyFloorLocalService
 * @generated
 */
public class PropertyFloorLocalServiceWrapper
	implements PropertyFloorLocalService,
			   ServiceWrapper<PropertyFloorLocalService> {

	public PropertyFloorLocalServiceWrapper() {
		this(null);
	}

	public PropertyFloorLocalServiceWrapper(
		PropertyFloorLocalService propertyFloorLocalService) {

		_propertyFloorLocalService = propertyFloorLocalService;
	}

	/**
	 * Adds the property floor to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyFloor the property floor
	 * @return the property floor that was added
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
		addPropertyFloor(
			com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
				propertyFloor) {

		return _propertyFloorLocalService.addPropertyFloor(propertyFloor);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
		addPropertyFloorPlan(
			long hostPropertyId, int totalGuests, int bedrooms, int beds,
			int bathrooms) {

		return _propertyFloorLocalService.addPropertyFloorPlan(
			hostPropertyId, totalGuests, bedrooms, beds, bathrooms);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyFloorLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Creates a new property floor with the primary key. Does not add the property floor to the database.
	 *
	 * @param floorId the primary key for the new property floor
	 * @return the new property floor
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
		createPropertyFloor(long floorId) {

		return _propertyFloorLocalService.createPropertyFloor(floorId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyFloorLocalService.deletePersistedModel(persistedModel);
	}

	/**
	 * Deletes the property floor with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor that was removed
	 * @throws PortalException if a property floor with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
			deletePropertyFloor(long floorId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyFloorLocalService.deletePropertyFloor(floorId);
	}

	/**
	 * Deletes the property floor from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyFloor the property floor
	 * @return the property floor that was removed
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
		deletePropertyFloor(
			com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
				propertyFloor) {

		return _propertyFloorLocalService.deletePropertyFloor(propertyFloor);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _propertyFloorLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _propertyFloorLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _propertyFloorLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _propertyFloorLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _propertyFloorLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _propertyFloorLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _propertyFloorLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _propertyFloorLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
		fetchPropertyFloor(long floorId) {

		return _propertyFloorLocalService.fetchPropertyFloor(floorId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _propertyFloorLocalService.getActionableDynamicQuery();
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor>
			getFloorPlanByBathrooms(int bathrooms) {

		return _propertyFloorLocalService.getFloorPlanByBathrooms(bathrooms);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor>
			getFloorPlanByBedrooms(int bedrooms) {

		return _propertyFloorLocalService.getFloorPlanByBedrooms(bedrooms);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor>
			getFloorPlanByBeds(int beds) {

		return _propertyFloorLocalService.getFloorPlanByBeds(beds);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor>
			getFloorPlanByPropertyId(long hostPropertyId) {

		return _propertyFloorLocalService.getFloorPlanByPropertyId(
			hostPropertyId);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor>
			getFloorPlanByTotalGuests(int totalGuests) {

		return _propertyFloorLocalService.getFloorPlanByTotalGuests(
			totalGuests);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor>
			getFloorPlanByTotalGuestsAndBedrooms(
				int totalGuests, int bedrooms) {

		return _propertyFloorLocalService.getFloorPlanByTotalGuestsAndBedrooms(
			totalGuests, bedrooms);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _propertyFloorLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _propertyFloorLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyFloorLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Returns the property floor with the primary key.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor
	 * @throws PortalException if a property floor with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
			getPropertyFloor(long floorId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyFloorLocalService.getPropertyFloor(floorId);
	}

	/**
	 * Returns a range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of property floors
	 */
	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor>
			getPropertyFloors(int start, int end) {

		return _propertyFloorLocalService.getPropertyFloors(start, end);
	}

	/**
	 * Returns the number of property floors.
	 *
	 * @return the number of property floors
	 */
	@Override
	public int getPropertyFloorsCount() {
		return _propertyFloorLocalService.getPropertyFloorsCount();
	}

	/**
	 * Updates the property floor in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyFloor the property floor
	 * @return the property floor that was updated
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
		updatePropertyFloor(
			com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor
				propertyFloor) {

		return _propertyFloorLocalService.updatePropertyFloor(propertyFloor);
	}

	@Override
	public BasePersistence<?> getBasePersistence() {
		return _propertyFloorLocalService.getBasePersistence();
	}

	@Override
	public PropertyFloorLocalService getWrappedService() {
		return _propertyFloorLocalService;
	}

	@Override
	public void setWrappedService(
		PropertyFloorLocalService propertyFloorLocalService) {

		_propertyFloorLocalService = propertyFloorLocalService;
	}

	private PropertyFloorLocalService _propertyFloorLocalService;

}