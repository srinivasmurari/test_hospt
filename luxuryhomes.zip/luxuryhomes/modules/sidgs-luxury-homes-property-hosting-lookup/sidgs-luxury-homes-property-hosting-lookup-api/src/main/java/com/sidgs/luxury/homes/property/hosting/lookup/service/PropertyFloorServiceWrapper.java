/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link PropertyFloorService}.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyFloorService
 * @generated
 */
public class PropertyFloorServiceWrapper
	implements PropertyFloorService, ServiceWrapper<PropertyFloorService> {

	public PropertyFloorServiceWrapper() {
		this(null);
	}

	public PropertyFloorServiceWrapper(
		PropertyFloorService propertyFloorService) {

		_propertyFloorService = propertyFloorService;
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _propertyFloorService.getOSGiServiceIdentifier();
	}

	@Override
	public PropertyFloorService getWrappedService() {
		return _propertyFloorService;
	}

	@Override
	public void setWrappedService(PropertyFloorService propertyFloorService) {
		_propertyFloorService = propertyFloorService;
	}

	private PropertyFloorService _propertyFloorService;

}