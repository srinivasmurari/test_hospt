/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;SID_HostProperty&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see HostProperty
 * @generated
 */
public class HostPropertyTable extends BaseTable<HostPropertyTable> {

	public static final HostPropertyTable INSTANCE = new HostPropertyTable();

	public final Column<HostPropertyTable, Long> hostPropertyId = createColumn(
		"hostPropertyId", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<HostPropertyTable, Long> createdByUserId = createColumn(
		"createdByUserId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Date> createDate = createColumn(
		"createDate", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Long> lastModifiedByUserId =
		createColumn(
			"lastModifiedByUserId", Long.class, Types.BIGINT,
			Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Date> modifiedDate = createColumn(
		"modifiedDate", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, String> articleId = createColumn(
		"articleId", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Integer> totalGuests = createColumn(
		"totalGuests", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Integer> bedrooms = createColumn(
		"bedrooms", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Boolean> sharedProperty =
		createColumn(
			"sharedProperty", Boolean.class, Types.BOOLEAN,
			Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Date> availableFrom = createColumn(
		"availableFrom", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Boolean> active = createColumn(
		"active_", Boolean.class, Types.BOOLEAN, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Integer> status = createColumn(
		"status", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Long> statusByUserId = createColumn(
		"statusByUserId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<HostPropertyTable, Date> statusUpdatedDate =
		createColumn(
			"statusUpdatedDate", Date.class, Types.TIMESTAMP,
			Column.FLAG_DEFAULT);

	private HostPropertyTable() {
		super("SID_HostProperty", HostPropertyTable::new);
	}

}