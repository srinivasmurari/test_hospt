/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

/**
 * The table class for the &quot;SID_PropertyLocation&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyLocation
 * @generated
 */
public class PropertyLocationTable extends BaseTable<PropertyLocationTable> {

	public static final PropertyLocationTable INSTANCE =
		new PropertyLocationTable();

	public final Column<PropertyLocationTable, Long> locationId = createColumn(
		"locationId", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<PropertyLocationTable, Long> hostPropertyId =
		createColumn(
			"hostPropertyId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> plotNo = createColumn(
		"plotNo", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> street = createColumn(
		"street", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> landmark = createColumn(
		"landmark", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> locality = createColumn(
		"locality", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> city = createColumn(
		"city", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> state = createColumn(
		"state_", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> country = createColumn(
		"country", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> zipCode = createColumn(
		"zipCode", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<PropertyLocationTable, String> coordinates =
		createColumn(
			"coordinates", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);

	private PropertyLocationTable() {
		super("SID_PropertyLocation", PropertyLocationTable::new);
	}

}