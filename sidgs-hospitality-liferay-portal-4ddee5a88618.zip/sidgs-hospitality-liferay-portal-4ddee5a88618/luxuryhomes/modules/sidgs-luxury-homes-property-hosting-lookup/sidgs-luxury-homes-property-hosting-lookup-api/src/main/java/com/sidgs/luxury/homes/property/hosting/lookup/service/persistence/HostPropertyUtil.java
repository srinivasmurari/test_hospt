/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the host property service. This utility wraps <code>com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.HostPropertyPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see HostPropertyPersistence
 * @generated
 */
public class HostPropertyUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(HostProperty hostProperty) {
		getPersistence().clearCache(hostProperty);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, HostProperty> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<HostProperty> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<HostProperty> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<HostProperty> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static HostProperty update(HostProperty hostProperty) {
		return getPersistence().update(hostProperty);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static HostProperty update(
		HostProperty hostProperty, ServiceContext serviceContext) {

		return getPersistence().update(hostProperty, serviceContext);
	}

	/**
	 * Returns the host property where articleId = &#63; or throws a <code>NoSuchHostPropertyException</code> if it could not be found.
	 *
	 * @param articleId the article ID
	 * @return the matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public static HostProperty findByArticleId(String articleId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByArticleId(articleId);
	}

	/**
	 * Returns the host property where articleId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param articleId the article ID
	 * @return the matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchByArticleId(String articleId) {
		return getPersistence().fetchByArticleId(articleId);
	}

	/**
	 * Returns the host property where articleId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param articleId the article ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchByArticleId(
		String articleId, boolean useFinderCache) {

		return getPersistence().fetchByArticleId(articleId, useFinderCache);
	}

	/**
	 * Removes the host property where articleId = &#63; from the database.
	 *
	 * @param articleId the article ID
	 * @return the host property that was removed
	 */
	public static HostProperty removeByArticleId(String articleId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().removeByArticleId(articleId);
	}

	/**
	 * Returns the number of host properties where articleId = &#63;.
	 *
	 * @param articleId the article ID
	 * @return the number of matching host properties
	 */
	public static int countByArticleId(String articleId) {
		return getPersistence().countByArticleId(articleId);
	}

	/**
	 * Returns all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @return the matching host properties
	 */
	public static List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active) {

		return getPersistence().findByUserId_Active(createdByUserId, active);
	}

	/**
	 * Returns a range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	public static List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end) {

		return getPersistence().findByUserId_Active(
			createdByUserId, active, start, end);
	}

	/**
	 * Returns an ordered range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	public static List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().findByUserId_Active(
			createdByUserId, active, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	public static List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByUserId_Active(
			createdByUserId, active, start, end, orderByComparator,
			useFinderCache);
	}

	/**
	 * Returns the first host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public static HostProperty findByUserId_Active_First(
			long createdByUserId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByUserId_Active_First(
			createdByUserId, active, orderByComparator);
	}

	/**
	 * Returns the first host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchByUserId_Active_First(
		long createdByUserId, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().fetchByUserId_Active_First(
			createdByUserId, active, orderByComparator);
	}

	/**
	 * Returns the last host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public static HostProperty findByUserId_Active_Last(
			long createdByUserId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByUserId_Active_Last(
			createdByUserId, active, orderByComparator);
	}

	/**
	 * Returns the last host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchByUserId_Active_Last(
		long createdByUserId, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().fetchByUserId_Active_Last(
			createdByUserId, active, orderByComparator);
	}

	/**
	 * Returns the host properties before and after the current host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public static HostProperty[] findByUserId_Active_PrevAndNext(
			long hostPropertyId, long createdByUserId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByUserId_Active_PrevAndNext(
			hostPropertyId, createdByUserId, active, orderByComparator);
	}

	/**
	 * Removes all the host properties where createdByUserId = &#63; and active = &#63; from the database.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 */
	public static void removeByUserId_Active(
		long createdByUserId, boolean active) {

		getPersistence().removeByUserId_Active(createdByUserId, active);
	}

	/**
	 * Returns the number of host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @return the number of matching host properties
	 */
	public static int countByUserId_Active(
		long createdByUserId, boolean active) {

		return getPersistence().countByUserId_Active(createdByUserId, active);
	}

	/**
	 * Returns all the host properties where active = &#63;.
	 *
	 * @param active the active
	 * @return the matching host properties
	 */
	public static List<HostProperty> findByActive(boolean active) {
		return getPersistence().findByActive(active);
	}

	/**
	 * Returns a range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	public static List<HostProperty> findByActive(
		boolean active, int start, int end) {

		return getPersistence().findByActive(active, start, end);
	}

	/**
	 * Returns an ordered range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	public static List<HostProperty> findByActive(
		boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().findByActive(
			active, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	public static List<HostProperty> findByActive(
		boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByActive(
			active, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public static HostProperty findByActive_First(
			boolean active, OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByActive_First(active, orderByComparator);
	}

	/**
	 * Returns the first host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchByActive_First(
		boolean active, OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().fetchByActive_First(active, orderByComparator);
	}

	/**
	 * Returns the last host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public static HostProperty findByActive_Last(
			boolean active, OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByActive_Last(active, orderByComparator);
	}

	/**
	 * Returns the last host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchByActive_Last(
		boolean active, OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().fetchByActive_Last(active, orderByComparator);
	}

	/**
	 * Returns the host properties before and after the current host property in the ordered set where active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public static HostProperty[] findByActive_PrevAndNext(
			long hostPropertyId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByActive_PrevAndNext(
			hostPropertyId, active, orderByComparator);
	}

	/**
	 * Removes all the host properties where active = &#63; from the database.
	 *
	 * @param active the active
	 */
	public static void removeByActive(boolean active) {
		getPersistence().removeByActive(active);
	}

	/**
	 * Returns the number of host properties where active = &#63;.
	 *
	 * @param active the active
	 * @return the number of matching host properties
	 */
	public static int countByActive(boolean active) {
		return getPersistence().countByActive(active);
	}

	/**
	 * Returns all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @return the matching host properties
	 */
	public static List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active) {

		return getPersistence().findBySharedProperty_Active(
			sharedProperty, active);
	}

	/**
	 * Returns a range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	public static List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end) {

		return getPersistence().findBySharedProperty_Active(
			sharedProperty, active, start, end);
	}

	/**
	 * Returns an ordered range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	public static List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().findBySharedProperty_Active(
			sharedProperty, active, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	public static List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findBySharedProperty_Active(
			sharedProperty, active, start, end, orderByComparator,
			useFinderCache);
	}

	/**
	 * Returns the first host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public static HostProperty findBySharedProperty_Active_First(
			boolean sharedProperty, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findBySharedProperty_Active_First(
			sharedProperty, active, orderByComparator);
	}

	/**
	 * Returns the first host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchBySharedProperty_Active_First(
		boolean sharedProperty, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().fetchBySharedProperty_Active_First(
			sharedProperty, active, orderByComparator);
	}

	/**
	 * Returns the last host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public static HostProperty findBySharedProperty_Active_Last(
			boolean sharedProperty, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findBySharedProperty_Active_Last(
			sharedProperty, active, orderByComparator);
	}

	/**
	 * Returns the last host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public static HostProperty fetchBySharedProperty_Active_Last(
		boolean sharedProperty, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().fetchBySharedProperty_Active_Last(
			sharedProperty, active, orderByComparator);
	}

	/**
	 * Returns the host properties before and after the current host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public static HostProperty[] findBySharedProperty_Active_PrevAndNext(
			long hostPropertyId, boolean sharedProperty, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findBySharedProperty_Active_PrevAndNext(
			hostPropertyId, sharedProperty, active, orderByComparator);
	}

	/**
	 * Removes all the host properties where sharedProperty = &#63; and active = &#63; from the database.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 */
	public static void removeBySharedProperty_Active(
		boolean sharedProperty, boolean active) {

		getPersistence().removeBySharedProperty_Active(sharedProperty, active);
	}

	/**
	 * Returns the number of host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @return the number of matching host properties
	 */
	public static int countBySharedProperty_Active(
		boolean sharedProperty, boolean active) {

		return getPersistence().countBySharedProperty_Active(
			sharedProperty, active);
	}

	/**
	 * Caches the host property in the entity cache if it is enabled.
	 *
	 * @param hostProperty the host property
	 */
	public static void cacheResult(HostProperty hostProperty) {
		getPersistence().cacheResult(hostProperty);
	}

	/**
	 * Caches the host properties in the entity cache if it is enabled.
	 *
	 * @param hostProperties the host properties
	 */
	public static void cacheResult(List<HostProperty> hostProperties) {
		getPersistence().cacheResult(hostProperties);
	}

	/**
	 * Creates a new host property with the primary key. Does not add the host property to the database.
	 *
	 * @param hostPropertyId the primary key for the new host property
	 * @return the new host property
	 */
	public static HostProperty create(long hostPropertyId) {
		return getPersistence().create(hostPropertyId);
	}

	/**
	 * Removes the host property with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property that was removed
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public static HostProperty remove(long hostPropertyId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().remove(hostPropertyId);
	}

	public static HostProperty updateImpl(HostProperty hostProperty) {
		return getPersistence().updateImpl(hostProperty);
	}

	/**
	 * Returns the host property with the primary key or throws a <code>NoSuchHostPropertyException</code> if it could not be found.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public static HostProperty findByPrimaryKey(long hostPropertyId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return getPersistence().findByPrimaryKey(hostPropertyId);
	}

	/**
	 * Returns the host property with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property, or <code>null</code> if a host property with the primary key could not be found
	 */
	public static HostProperty fetchByPrimaryKey(long hostPropertyId) {
		return getPersistence().fetchByPrimaryKey(hostPropertyId);
	}

	/**
	 * Returns all the host properties.
	 *
	 * @return the host properties
	 */
	public static List<HostProperty> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of host properties
	 */
	public static List<HostProperty> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of host properties
	 */
	public static List<HostProperty> findAll(
		int start, int end, OrderByComparator<HostProperty> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of host properties
	 */
	public static List<HostProperty> findAll(
		int start, int end, OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the host properties from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of host properties.
	 *
	 * @return the number of host properties
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static HostPropertyPersistence getPersistence() {
		return _persistence;
	}

	public static void setPersistence(HostPropertyPersistence persistence) {
		_persistence = persistence;
	}

	private static volatile HostPropertyPersistence _persistence;

}