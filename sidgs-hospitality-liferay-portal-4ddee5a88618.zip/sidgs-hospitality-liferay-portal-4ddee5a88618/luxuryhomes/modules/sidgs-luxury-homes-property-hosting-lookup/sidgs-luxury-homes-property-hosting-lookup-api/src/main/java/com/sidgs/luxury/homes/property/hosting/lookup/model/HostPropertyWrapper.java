/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link HostProperty}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see HostProperty
 * @generated
 */
public class HostPropertyWrapper
	extends BaseModelWrapper<HostProperty>
	implements HostProperty, ModelWrapper<HostProperty> {

	public HostPropertyWrapper(HostProperty hostProperty) {
		super(hostProperty);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("hostPropertyId", getHostPropertyId());
		attributes.put("createdByUserId", getCreatedByUserId());
		attributes.put("createDate", getCreateDate());
		attributes.put("lastModifiedByUserId", getLastModifiedByUserId());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("articleId", getArticleId());
		attributes.put("totalGuests", getTotalGuests());
		attributes.put("bedrooms", getBedrooms());
		attributes.put("sharedProperty", isSharedProperty());
		attributes.put("availableFrom", getAvailableFrom());
		attributes.put("active", isActive());
		attributes.put("status", getStatus());
		attributes.put("statusByUserId", getStatusByUserId());
		attributes.put("statusUpdatedDate", getStatusUpdatedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long hostPropertyId = (Long)attributes.get("hostPropertyId");

		if (hostPropertyId != null) {
			setHostPropertyId(hostPropertyId);
		}

		Long createdByUserId = (Long)attributes.get("createdByUserId");

		if (createdByUserId != null) {
			setCreatedByUserId(createdByUserId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Long lastModifiedByUserId = (Long)attributes.get(
			"lastModifiedByUserId");

		if (lastModifiedByUserId != null) {
			setLastModifiedByUserId(lastModifiedByUserId);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String articleId = (String)attributes.get("articleId");

		if (articleId != null) {
			setArticleId(articleId);
		}

		Integer totalGuests = (Integer)attributes.get("totalGuests");

		if (totalGuests != null) {
			setTotalGuests(totalGuests);
		}

		Integer bedrooms = (Integer)attributes.get("bedrooms");

		if (bedrooms != null) {
			setBedrooms(bedrooms);
		}

		Boolean sharedProperty = (Boolean)attributes.get("sharedProperty");

		if (sharedProperty != null) {
			setSharedProperty(sharedProperty);
		}

		Date availableFrom = (Date)attributes.get("availableFrom");

		if (availableFrom != null) {
			setAvailableFrom(availableFrom);
		}

		Boolean active = (Boolean)attributes.get("active");

		if (active != null) {
			setActive(active);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Long statusByUserId = (Long)attributes.get("statusByUserId");

		if (statusByUserId != null) {
			setStatusByUserId(statusByUserId);
		}

		Date statusUpdatedDate = (Date)attributes.get("statusUpdatedDate");

		if (statusUpdatedDate != null) {
			setStatusUpdatedDate(statusUpdatedDate);
		}
	}

	@Override
	public HostProperty cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the active of this host property.
	 *
	 * @return the active of this host property
	 */
	@Override
	public boolean getActive() {
		return model.getActive();
	}

	/**
	 * Returns the article ID of this host property.
	 *
	 * @return the article ID of this host property
	 */
	@Override
	public String getArticleId() {
		return model.getArticleId();
	}

	/**
	 * Returns the available from of this host property.
	 *
	 * @return the available from of this host property
	 */
	@Override
	public Date getAvailableFrom() {
		return model.getAvailableFrom();
	}

	/**
	 * Returns the bedrooms of this host property.
	 *
	 * @return the bedrooms of this host property
	 */
	@Override
	public int getBedrooms() {
		return model.getBedrooms();
	}

	/**
	 * Returns the create date of this host property.
	 *
	 * @return the create date of this host property
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the created by user ID of this host property.
	 *
	 * @return the created by user ID of this host property
	 */
	@Override
	public long getCreatedByUserId() {
		return model.getCreatedByUserId();
	}

	/**
	 * Returns the created by user uuid of this host property.
	 *
	 * @return the created by user uuid of this host property
	 */
	@Override
	public String getCreatedByUserUuid() {
		return model.getCreatedByUserUuid();
	}

	/**
	 * Returns the host property ID of this host property.
	 *
	 * @return the host property ID of this host property
	 */
	@Override
	public long getHostPropertyId() {
		return model.getHostPropertyId();
	}

	/**
	 * Returns the last modified by user ID of this host property.
	 *
	 * @return the last modified by user ID of this host property
	 */
	@Override
	public long getLastModifiedByUserId() {
		return model.getLastModifiedByUserId();
	}

	/**
	 * Returns the last modified by user uuid of this host property.
	 *
	 * @return the last modified by user uuid of this host property
	 */
	@Override
	public String getLastModifiedByUserUuid() {
		return model.getLastModifiedByUserUuid();
	}

	/**
	 * Returns the modified date of this host property.
	 *
	 * @return the modified date of this host property
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the primary key of this host property.
	 *
	 * @return the primary key of this host property
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the shared property of this host property.
	 *
	 * @return the shared property of this host property
	 */
	@Override
	public boolean getSharedProperty() {
		return model.getSharedProperty();
	}

	/**
	 * Returns the status of this host property.
	 *
	 * @return the status of this host property
	 */
	@Override
	public int getStatus() {
		return model.getStatus();
	}

	/**
	 * Returns the status by user ID of this host property.
	 *
	 * @return the status by user ID of this host property
	 */
	@Override
	public long getStatusByUserId() {
		return model.getStatusByUserId();
	}

	/**
	 * Returns the status by user uuid of this host property.
	 *
	 * @return the status by user uuid of this host property
	 */
	@Override
	public String getStatusByUserUuid() {
		return model.getStatusByUserUuid();
	}

	/**
	 * Returns the status updated date of this host property.
	 *
	 * @return the status updated date of this host property
	 */
	@Override
	public Date getStatusUpdatedDate() {
		return model.getStatusUpdatedDate();
	}

	/**
	 * Returns the total guests of this host property.
	 *
	 * @return the total guests of this host property
	 */
	@Override
	public int getTotalGuests() {
		return model.getTotalGuests();
	}

	/**
	 * Returns <code>true</code> if this host property is active.
	 *
	 * @return <code>true</code> if this host property is active; <code>false</code> otherwise
	 */
	@Override
	public boolean isActive() {
		return model.isActive();
	}

	/**
	 * Returns <code>true</code> if this host property is shared property.
	 *
	 * @return <code>true</code> if this host property is shared property; <code>false</code> otherwise
	 */
	@Override
	public boolean isSharedProperty() {
		return model.isSharedProperty();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets whether this host property is active.
	 *
	 * @param active the active of this host property
	 */
	@Override
	public void setActive(boolean active) {
		model.setActive(active);
	}

	/**
	 * Sets the article ID of this host property.
	 *
	 * @param articleId the article ID of this host property
	 */
	@Override
	public void setArticleId(String articleId) {
		model.setArticleId(articleId);
	}

	/**
	 * Sets the available from of this host property.
	 *
	 * @param availableFrom the available from of this host property
	 */
	@Override
	public void setAvailableFrom(Date availableFrom) {
		model.setAvailableFrom(availableFrom);
	}

	/**
	 * Sets the bedrooms of this host property.
	 *
	 * @param bedrooms the bedrooms of this host property
	 */
	@Override
	public void setBedrooms(int bedrooms) {
		model.setBedrooms(bedrooms);
	}

	/**
	 * Sets the create date of this host property.
	 *
	 * @param createDate the create date of this host property
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the created by user ID of this host property.
	 *
	 * @param createdByUserId the created by user ID of this host property
	 */
	@Override
	public void setCreatedByUserId(long createdByUserId) {
		model.setCreatedByUserId(createdByUserId);
	}

	/**
	 * Sets the created by user uuid of this host property.
	 *
	 * @param createdByUserUuid the created by user uuid of this host property
	 */
	@Override
	public void setCreatedByUserUuid(String createdByUserUuid) {
		model.setCreatedByUserUuid(createdByUserUuid);
	}

	/**
	 * Sets the host property ID of this host property.
	 *
	 * @param hostPropertyId the host property ID of this host property
	 */
	@Override
	public void setHostPropertyId(long hostPropertyId) {
		model.setHostPropertyId(hostPropertyId);
	}

	/**
	 * Sets the last modified by user ID of this host property.
	 *
	 * @param lastModifiedByUserId the last modified by user ID of this host property
	 */
	@Override
	public void setLastModifiedByUserId(long lastModifiedByUserId) {
		model.setLastModifiedByUserId(lastModifiedByUserId);
	}

	/**
	 * Sets the last modified by user uuid of this host property.
	 *
	 * @param lastModifiedByUserUuid the last modified by user uuid of this host property
	 */
	@Override
	public void setLastModifiedByUserUuid(String lastModifiedByUserUuid) {
		model.setLastModifiedByUserUuid(lastModifiedByUserUuid);
	}

	/**
	 * Sets the modified date of this host property.
	 *
	 * @param modifiedDate the modified date of this host property
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the primary key of this host property.
	 *
	 * @param primaryKey the primary key of this host property
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets whether this host property is shared property.
	 *
	 * @param sharedProperty the shared property of this host property
	 */
	@Override
	public void setSharedProperty(boolean sharedProperty) {
		model.setSharedProperty(sharedProperty);
	}

	/**
	 * Sets the status of this host property.
	 *
	 * @param status the status of this host property
	 */
	@Override
	public void setStatus(int status) {
		model.setStatus(status);
	}

	/**
	 * Sets the status by user ID of this host property.
	 *
	 * @param statusByUserId the status by user ID of this host property
	 */
	@Override
	public void setStatusByUserId(long statusByUserId) {
		model.setStatusByUserId(statusByUserId);
	}

	/**
	 * Sets the status by user uuid of this host property.
	 *
	 * @param statusByUserUuid the status by user uuid of this host property
	 */
	@Override
	public void setStatusByUserUuid(String statusByUserUuid) {
		model.setStatusByUserUuid(statusByUserUuid);
	}

	/**
	 * Sets the status updated date of this host property.
	 *
	 * @param statusUpdatedDate the status updated date of this host property
	 */
	@Override
	public void setStatusUpdatedDate(Date statusUpdatedDate) {
		model.setStatusUpdatedDate(statusUpdatedDate);
	}

	/**
	 * Sets the total guests of this host property.
	 *
	 * @param totalGuests the total guests of this host property
	 */
	@Override
	public void setTotalGuests(int totalGuests) {
		model.setTotalGuests(totalGuests);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected HostPropertyWrapper wrap(HostProperty hostProperty) {
		return new HostPropertyWrapper(hostProperty);
	}

}