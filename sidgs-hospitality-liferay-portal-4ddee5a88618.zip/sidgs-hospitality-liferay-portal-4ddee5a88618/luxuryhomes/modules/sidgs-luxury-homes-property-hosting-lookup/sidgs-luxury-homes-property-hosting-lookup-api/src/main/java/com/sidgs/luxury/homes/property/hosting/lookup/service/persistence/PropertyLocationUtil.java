/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the property location service. This utility wraps <code>com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.PropertyLocationPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyLocationPersistence
 * @generated
 */
public class PropertyLocationUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(PropertyLocation propertyLocation) {
		getPersistence().clearCache(propertyLocation);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, PropertyLocation> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<PropertyLocation> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<PropertyLocation> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<PropertyLocation> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static PropertyLocation update(PropertyLocation propertyLocation) {
		return getPersistence().update(propertyLocation);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static PropertyLocation update(
		PropertyLocation propertyLocation, ServiceContext serviceContext) {

		return getPersistence().update(propertyLocation, serviceContext);
	}

	/**
	 * Returns the property location where hostPropertyId = &#63; or throws a <code>NoSuchPropertyLocationException</code> if it could not be found.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByHostPropertyId(long hostPropertyId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns the property location where hostPropertyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByHostPropertyId(long hostPropertyId) {
		return getPersistence().fetchByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns the property location where hostPropertyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param hostPropertyId the host property ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByHostPropertyId(
		long hostPropertyId, boolean useFinderCache) {

		return getPersistence().fetchByHostPropertyId(
			hostPropertyId, useFinderCache);
	}

	/**
	 * Removes the property location where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the property location that was removed
	 */
	public static PropertyLocation removeByHostPropertyId(long hostPropertyId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().removeByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns the number of property locations where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property locations
	 */
	public static int countByHostPropertyId(long hostPropertyId) {
		return getPersistence().countByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns all the property locations where locality = &#63;.
	 *
	 * @param locality the locality
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByLocality(String locality) {
		return getPersistence().findByLocality(locality);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality(
		String locality, int start, int end) {

		return getPersistence().findByLocality(locality, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality(
		String locality, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByLocality(
			locality, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality(
		String locality, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByLocality(
			locality, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_First(
			String locality,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_First(
			locality, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_First(
		String locality,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_First(
			locality, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_Last(
			String locality,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_Last(
			locality, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_Last(
		String locality,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_Last(
			locality, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByLocality_PrevAndNext(
			long locationId, String locality,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_PrevAndNext(
			locationId, locality, orderByComparator);
	}

	/**
	 * Removes all the property locations where locality = &#63; from the database.
	 *
	 * @param locality the locality
	 */
	public static void removeByLocality(String locality) {
		getPersistence().removeByLocality(locality);
	}

	/**
	 * Returns the number of property locations where locality = &#63;.
	 *
	 * @param locality the locality
	 * @return the number of matching property locations
	 */
	public static int countByLocality(String locality) {
		return getPersistence().countByLocality(locality);
	}

	/**
	 * Returns all the property locations where state = &#63;.
	 *
	 * @param state the state
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByState(String state) {
		return getPersistence().findByState(state);
	}

	/**
	 * Returns a range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByState(
		String state, int start, int end) {

		return getPersistence().findByState(state, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByState(
		String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByState(
			state, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByState(
		String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByState(
			state, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByState_First(
			String state, OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByState_First(state, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByState_First(
		String state, OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByState_First(state, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByState_Last(
			String state, OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByState_Last(state, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByState_Last(
		String state, OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByState_Last(state, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where state = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByState_PrevAndNext(
			long locationId, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByState_PrevAndNext(
			locationId, state, orderByComparator);
	}

	/**
	 * Removes all the property locations where state = &#63; from the database.
	 *
	 * @param state the state
	 */
	public static void removeByState(String state) {
		getPersistence().removeByState(state);
	}

	/**
	 * Returns the number of property locations where state = &#63;.
	 *
	 * @param state the state
	 * @return the number of matching property locations
	 */
	public static int countByState(String state) {
		return getPersistence().countByState(state);
	}

	/**
	 * Returns all the property locations where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByZipCode(String zipCode) {
		return getPersistence().findByZipCode(zipCode);
	}

	/**
	 * Returns a range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end) {

		return getPersistence().findByZipCode(zipCode, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByZipCode(
			zipCode, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByZipCode(
			zipCode, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByZipCode_First(
			String zipCode,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByZipCode_First(zipCode, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByZipCode_First(
		String zipCode, OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByZipCode_First(
			zipCode, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByZipCode_Last(
			String zipCode,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByZipCode_Last(zipCode, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByZipCode_Last(
		String zipCode, OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByZipCode_Last(zipCode, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where zipCode = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByZipCode_PrevAndNext(
			long locationId, String zipCode,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByZipCode_PrevAndNext(
			locationId, zipCode, orderByComparator);
	}

	/**
	 * Removes all the property locations where zipCode = &#63; from the database.
	 *
	 * @param zipCode the zip code
	 */
	public static void removeByZipCode(String zipCode) {
		getPersistence().removeByZipCode(zipCode);
	}

	/**
	 * Returns the number of property locations where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @return the number of matching property locations
	 */
	public static int countByZipCode(String zipCode) {
		return getPersistence().countByZipCode(zipCode);
	}

	/**
	 * Returns all the property locations where country = &#63;.
	 *
	 * @param country the country
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByCountry(String country) {
		return getPersistence().findByCountry(country);
	}

	/**
	 * Returns a range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByCountry(
		String country, int start, int end) {

		return getPersistence().findByCountry(country, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByCountry(
		String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByCountry(
			country, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByCountry(
		String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByCountry(
			country, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByCountry_First(
			String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByCountry_First(country, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByCountry_First(
		String country, OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByCountry_First(
			country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByCountry_Last(
			String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByCountry_Last(country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByCountry_Last(
		String country, OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByCountry_Last(country, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByCountry_PrevAndNext(
			long locationId, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByCountry_PrevAndNext(
			locationId, country, orderByComparator);
	}

	/**
	 * Removes all the property locations where country = &#63; from the database.
	 *
	 * @param country the country
	 */
	public static void removeByCountry(String country) {
		getPersistence().removeByCountry(country);
	}

	/**
	 * Returns the number of property locations where country = &#63;.
	 *
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public static int countByCountry(String country) {
		return getPersistence().countByCountry(country);
	}

	/**
	 * Returns all the property locations where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State(
		String locality, String state) {

		return getPersistence().findByLocality_State(locality, state);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end) {

		return getPersistence().findByLocality_State(
			locality, state, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByLocality_State(
			locality, state, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByLocality_State(
			locality, state, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_State_First(
			String locality, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_State_First(
			locality, state, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_State_First(
		String locality, String state,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_State_First(
			locality, state, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_State_Last(
			String locality, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_State_Last(
			locality, state, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_State_Last(
		String locality, String state,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_State_Last(
			locality, state, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByLocality_State_PrevAndNext(
			long locationId, String locality, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_State_PrevAndNext(
			locationId, locality, state, orderByComparator);
	}

	/**
	 * Removes all the property locations where locality = &#63; and state = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param state the state
	 */
	public static void removeByLocality_State(String locality, String state) {
		getPersistence().removeByLocality_State(locality, state);
	}

	/**
	 * Returns the number of property locations where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @return the number of matching property locations
	 */
	public static int countByLocality_State(String locality, String state) {
		return getPersistence().countByLocality_State(locality, state);
	}

	/**
	 * Returns all the property locations where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByLocality_Country(
		String locality, String country) {

		return getPersistence().findByLocality_Country(locality, country);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end) {

		return getPersistence().findByLocality_Country(
			locality, country, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByLocality_Country(
			locality, country, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByLocality_Country(
			locality, country, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_Country_First(
			String locality, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_Country_First(
			locality, country, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_Country_First(
		String locality, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_Country_First(
			locality, country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_Country_Last(
			String locality, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_Country_Last(
			locality, country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_Country_Last(
		String locality, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_Country_Last(
			locality, country, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByLocality_Country_PrevAndNext(
			long locationId, String locality, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_Country_PrevAndNext(
			locationId, locality, country, orderByComparator);
	}

	/**
	 * Removes all the property locations where locality = &#63; and country = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param country the country
	 */
	public static void removeByLocality_Country(
		String locality, String country) {

		getPersistence().removeByLocality_Country(locality, country);
	}

	/**
	 * Returns the number of property locations where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public static int countByLocality_Country(String locality, String country) {
		return getPersistence().countByLocality_Country(locality, country);
	}

	/**
	 * Returns all the property locations where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByState_Country(
		String state, String country) {

		return getPersistence().findByState_Country(state, country);
	}

	/**
	 * Returns a range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end) {

		return getPersistence().findByState_Country(state, country, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByState_Country(
			state, country, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByState_Country(
			state, country, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByState_Country_First(
			String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByState_Country_First(
			state, country, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByState_Country_First(
		String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByState_Country_First(
			state, country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByState_Country_Last(
			String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByState_Country_Last(
			state, country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByState_Country_Last(
		String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByState_Country_Last(
			state, country, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByState_Country_PrevAndNext(
			long locationId, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByState_Country_PrevAndNext(
			locationId, state, country, orderByComparator);
	}

	/**
	 * Removes all the property locations where state = &#63; and country = &#63; from the database.
	 *
	 * @param state the state
	 * @param country the country
	 */
	public static void removeByState_Country(String state, String country) {
		getPersistence().removeByState_Country(state, country);
	}

	/**
	 * Returns the number of property locations where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public static int countByState_Country(String state, String country) {
		return getPersistence().countByState_Country(state, country);
	}

	/**
	 * Returns all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @return the matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country) {

		return getPersistence().findByLocality_State_Country(
			locality, state, country);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end) {

		return getPersistence().findByLocality_State_Country(
			locality, state, country, start, end);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findByLocality_State_Country(
			locality, state, country, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public static List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByLocality_State_Country(
			locality, state, country, start, end, orderByComparator,
			useFinderCache);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_State_Country_First(
			String locality, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_State_Country_First(
			locality, state, country, orderByComparator);
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_State_Country_First(
		String locality, String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_State_Country_First(
			locality, state, country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public static PropertyLocation findByLocality_State_Country_Last(
			String locality, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_State_Country_Last(
			locality, state, country, orderByComparator);
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public static PropertyLocation fetchByLocality_State_Country_Last(
		String locality, String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().fetchByLocality_State_Country_Last(
			locality, state, country, orderByComparator);
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation[] findByLocality_State_Country_PrevAndNext(
			long locationId, String locality, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByLocality_State_Country_PrevAndNext(
			locationId, locality, state, country, orderByComparator);
	}

	/**
	 * Removes all the property locations where locality = &#63; and state = &#63; and country = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 */
	public static void removeByLocality_State_Country(
		String locality, String state, String country) {

		getPersistence().removeByLocality_State_Country(
			locality, state, country);
	}

	/**
	 * Returns the number of property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public static int countByLocality_State_Country(
		String locality, String state, String country) {

		return getPersistence().countByLocality_State_Country(
			locality, state, country);
	}

	/**
	 * Caches the property location in the entity cache if it is enabled.
	 *
	 * @param propertyLocation the property location
	 */
	public static void cacheResult(PropertyLocation propertyLocation) {
		getPersistence().cacheResult(propertyLocation);
	}

	/**
	 * Caches the property locations in the entity cache if it is enabled.
	 *
	 * @param propertyLocations the property locations
	 */
	public static void cacheResult(List<PropertyLocation> propertyLocations) {
		getPersistence().cacheResult(propertyLocations);
	}

	/**
	 * Creates a new property location with the primary key. Does not add the property location to the database.
	 *
	 * @param locationId the primary key for the new property location
	 * @return the new property location
	 */
	public static PropertyLocation create(long locationId) {
		return getPersistence().create(locationId);
	}

	/**
	 * Removes the property location with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location that was removed
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation remove(long locationId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().remove(locationId);
	}

	public static PropertyLocation updateImpl(
		PropertyLocation propertyLocation) {

		return getPersistence().updateImpl(propertyLocation);
	}

	/**
	 * Returns the property location with the primary key or throws a <code>NoSuchPropertyLocationException</code> if it could not be found.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public static PropertyLocation findByPrimaryKey(long locationId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return getPersistence().findByPrimaryKey(locationId);
	}

	/**
	 * Returns the property location with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location, or <code>null</code> if a property location with the primary key could not be found
	 */
	public static PropertyLocation fetchByPrimaryKey(long locationId) {
		return getPersistence().fetchByPrimaryKey(locationId);
	}

	/**
	 * Returns all the property locations.
	 *
	 * @return the property locations
	 */
	public static List<PropertyLocation> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of property locations
	 */
	public static List<PropertyLocation> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property locations
	 */
	public static List<PropertyLocation> findAll(
		int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property locations
	 */
	public static List<PropertyLocation> findAll(
		int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the property locations from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of property locations.
	 *
	 * @return the number of property locations
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static PropertyLocationPersistence getPersistence() {
		return _persistence;
	}

	public static void setPersistence(PropertyLocationPersistence persistence) {
		_persistence = persistence;
	}

	private static volatile PropertyLocationPersistence _persistence;

}