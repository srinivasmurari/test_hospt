/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

/**
 * The table class for the &quot;SID_PropertyFloor&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyFloor
 * @generated
 */
public class PropertyFloorTable extends BaseTable<PropertyFloorTable> {

	public static final PropertyFloorTable INSTANCE = new PropertyFloorTable();

	public final Column<PropertyFloorTable, Long> floorId = createColumn(
		"floorId", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<PropertyFloorTable, Long> hostPropertyId = createColumn(
		"hostPropertyId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<PropertyFloorTable, Integer> totalGuests = createColumn(
		"totalGuests", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);
	public final Column<PropertyFloorTable, Integer> bedrooms = createColumn(
		"bedrooms", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);
	public final Column<PropertyFloorTable, Integer> beds = createColumn(
		"beds", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);
	public final Column<PropertyFloorTable, Integer> bathrooms = createColumn(
		"bathrooms", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);

	private PropertyFloorTable() {
		super("SID_PropertyFloor", PropertyFloorTable::new);
	}

}