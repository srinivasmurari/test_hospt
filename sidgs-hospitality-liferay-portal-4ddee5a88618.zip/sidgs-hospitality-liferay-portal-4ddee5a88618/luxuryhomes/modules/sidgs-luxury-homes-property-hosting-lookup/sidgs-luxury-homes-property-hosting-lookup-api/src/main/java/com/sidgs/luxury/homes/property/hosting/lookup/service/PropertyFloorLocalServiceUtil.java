/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service;

import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor;

import java.io.Serializable;

import java.util.List;

/**
 * Provides the local service utility for PropertyFloor. This utility wraps
 * <code>com.sidgs.luxury.homes.property.hosting.lookup.service.impl.PropertyFloorLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyFloorLocalService
 * @generated
 */
public class PropertyFloorLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.sidgs.luxury.homes.property.hosting.lookup.service.impl.PropertyFloorLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the property floor to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyFloor the property floor
	 * @return the property floor that was added
	 */
	public static PropertyFloor addPropertyFloor(PropertyFloor propertyFloor) {
		return getService().addPropertyFloor(propertyFloor);
	}

	public static PropertyFloor addPropertyFloorPlan(
		long hostPropertyId, int totalGuests, int bedrooms, int beds,
		int bathrooms) {

		return getService().addPropertyFloorPlan(
			hostPropertyId, totalGuests, bedrooms, beds, bathrooms);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel createPersistedModel(
			Serializable primaryKeyObj)
		throws PortalException {

		return getService().createPersistedModel(primaryKeyObj);
	}

	/**
	 * Creates a new property floor with the primary key. Does not add the property floor to the database.
	 *
	 * @param floorId the primary key for the new property floor
	 * @return the new property floor
	 */
	public static PropertyFloor createPropertyFloor(long floorId) {
		return getService().createPropertyFloor(floorId);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel deletePersistedModel(
			PersistedModel persistedModel)
		throws PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	/**
	 * Deletes the property floor with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor that was removed
	 * @throws PortalException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor deletePropertyFloor(long floorId)
		throws PortalException {

		return getService().deletePropertyFloor(floorId);
	}

	/**
	 * Deletes the property floor from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyFloor the property floor
	 * @return the property floor that was removed
	 */
	public static PropertyFloor deletePropertyFloor(
		PropertyFloor propertyFloor) {

		return getService().deletePropertyFloor(propertyFloor);
	}

	public static <T> T dslQuery(DSLQuery dslQuery) {
		return getService().dslQuery(dslQuery);
	}

	public static int dslQueryCount(DSLQuery dslQuery) {
		return getService().dslQueryCount(dslQuery);
	}

	public static DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> List<T> dynamicQuery(DynamicQuery dynamicQuery) {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(DynamicQuery dynamicQuery) {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static PropertyFloor fetchPropertyFloor(long floorId) {
		return getService().fetchPropertyFloor(floorId);
	}

	public static com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return getService().getActionableDynamicQuery();
	}

	public static List<PropertyFloor> getFloorPlanByBathrooms(int bathrooms) {
		return getService().getFloorPlanByBathrooms(bathrooms);
	}

	public static List<PropertyFloor> getFloorPlanByBedrooms(int bedrooms) {
		return getService().getFloorPlanByBedrooms(bedrooms);
	}

	public static List<PropertyFloor> getFloorPlanByBeds(int beds) {
		return getService().getFloorPlanByBeds(beds);
	}

	public static List<PropertyFloor> getFloorPlanByPropertyId(
		long hostPropertyId) {

		return getService().getFloorPlanByPropertyId(hostPropertyId);
	}

	public static List<PropertyFloor> getFloorPlanByTotalGuests(
		int totalGuests) {

		return getService().getFloorPlanByTotalGuests(totalGuests);
	}

	public static List<PropertyFloor> getFloorPlanByTotalGuestsAndBedrooms(
		int totalGuests, int bedrooms) {

		return getService().getFloorPlanByTotalGuestsAndBedrooms(
			totalGuests, bedrooms);
	}

	public static
		com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
			getIndexableActionableDynamicQuery() {

		return getService().getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel getPersistedModel(Serializable primaryKeyObj)
		throws PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	 * Returns the property floor with the primary key.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor
	 * @throws PortalException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor getPropertyFloor(long floorId)
		throws PortalException {

		return getService().getPropertyFloor(floorId);
	}

	/**
	 * Returns a range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of property floors
	 */
	public static List<PropertyFloor> getPropertyFloors(int start, int end) {
		return getService().getPropertyFloors(start, end);
	}

	/**
	 * Returns the number of property floors.
	 *
	 * @return the number of property floors
	 */
	public static int getPropertyFloorsCount() {
		return getService().getPropertyFloorsCount();
	}

	/**
	 * Updates the property floor in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyFloorLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyFloor the property floor
	 * @return the property floor that was updated
	 */
	public static PropertyFloor updatePropertyFloor(
		PropertyFloor propertyFloor) {

		return getService().updatePropertyFloor(propertyFloor);
	}

	public static PropertyFloorLocalService getService() {
		return _service;
	}

	public static void setService(PropertyFloorLocalService service) {
		_service = service;
	}

	private static volatile PropertyFloorLocalService _service;

}