/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyPricingException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the property pricing service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyPricingUtil
 * @generated
 */
@ProviderType
public interface PropertyPricingPersistence
	extends BasePersistence<PropertyPricing> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link PropertyPricingUtil} to access the property pricing persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the property pricings where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property pricings
	 */
	public java.util.List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId);

	/**
	 * Returns a range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of matching property pricings
	 */
	public java.util.List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end);

	/**
	 * Returns an ordered range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property pricings
	 */
	public java.util.List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property pricings
	 */
	public java.util.List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public PropertyPricing findByHostPropertyId_First(
			long hostPropertyId,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
				orderByComparator)
		throws NoSuchPropertyPricingException;

	/**
	 * Returns the first property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public PropertyPricing fetchByHostPropertyId_First(
		long hostPropertyId,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator);

	/**
	 * Returns the last property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public PropertyPricing findByHostPropertyId_Last(
			long hostPropertyId,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
				orderByComparator)
		throws NoSuchPropertyPricingException;

	/**
	 * Returns the last property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public PropertyPricing fetchByHostPropertyId_Last(
		long hostPropertyId,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator);

	/**
	 * Returns the property pricings before and after the current property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param pricingId the primary key of the current property pricing
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public PropertyPricing[] findByHostPropertyId_PrevAndNext(
			long pricingId, long hostPropertyId,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
				orderByComparator)
		throws NoSuchPropertyPricingException;

	/**
	 * Removes all the property pricings where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 */
	public void removeByHostPropertyId(long hostPropertyId);

	/**
	 * Returns the number of property pricings where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property pricings
	 */
	public int countByHostPropertyId(long hostPropertyId);

	/**
	 * Returns the property pricing where floorId = &#63; or throws a <code>NoSuchPropertyPricingException</code> if it could not be found.
	 *
	 * @param floorId the floor ID
	 * @return the matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public PropertyPricing findByFloorId(long floorId)
		throws NoSuchPropertyPricingException;

	/**
	 * Returns the property pricing where floorId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param floorId the floor ID
	 * @return the matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public PropertyPricing fetchByFloorId(long floorId);

	/**
	 * Returns the property pricing where floorId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param floorId the floor ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public PropertyPricing fetchByFloorId(long floorId, boolean useFinderCache);

	/**
	 * Removes the property pricing where floorId = &#63; from the database.
	 *
	 * @param floorId the floor ID
	 * @return the property pricing that was removed
	 */
	public PropertyPricing removeByFloorId(long floorId)
		throws NoSuchPropertyPricingException;

	/**
	 * Returns the number of property pricings where floorId = &#63;.
	 *
	 * @param floorId the floor ID
	 * @return the number of matching property pricings
	 */
	public int countByFloorId(long floorId);

	/**
	 * Returns all the property pricings where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @return the matching property pricings
	 */
	public java.util.List<PropertyPricing> findByBasePrice(double basePrice);

	/**
	 * Returns a range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of matching property pricings
	 */
	public java.util.List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end);

	/**
	 * Returns an ordered range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property pricings
	 */
	public java.util.List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property pricings
	 */
	public java.util.List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public PropertyPricing findByBasePrice_First(
			double basePrice,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
				orderByComparator)
		throws NoSuchPropertyPricingException;

	/**
	 * Returns the first property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public PropertyPricing fetchByBasePrice_First(
		double basePrice,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator);

	/**
	 * Returns the last property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public PropertyPricing findByBasePrice_Last(
			double basePrice,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
				orderByComparator)
		throws NoSuchPropertyPricingException;

	/**
	 * Returns the last property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public PropertyPricing fetchByBasePrice_Last(
		double basePrice,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator);

	/**
	 * Returns the property pricings before and after the current property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param pricingId the primary key of the current property pricing
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public PropertyPricing[] findByBasePrice_PrevAndNext(
			long pricingId, double basePrice,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
				orderByComparator)
		throws NoSuchPropertyPricingException;

	/**
	 * Removes all the property pricings where basePrice = &#63; from the database.
	 *
	 * @param basePrice the base price
	 */
	public void removeByBasePrice(double basePrice);

	/**
	 * Returns the number of property pricings where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @return the number of matching property pricings
	 */
	public int countByBasePrice(double basePrice);

	/**
	 * Caches the property pricing in the entity cache if it is enabled.
	 *
	 * @param propertyPricing the property pricing
	 */
	public void cacheResult(PropertyPricing propertyPricing);

	/**
	 * Caches the property pricings in the entity cache if it is enabled.
	 *
	 * @param propertyPricings the property pricings
	 */
	public void cacheResult(java.util.List<PropertyPricing> propertyPricings);

	/**
	 * Creates a new property pricing with the primary key. Does not add the property pricing to the database.
	 *
	 * @param pricingId the primary key for the new property pricing
	 * @return the new property pricing
	 */
	public PropertyPricing create(long pricingId);

	/**
	 * Removes the property pricing with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing that was removed
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public PropertyPricing remove(long pricingId)
		throws NoSuchPropertyPricingException;

	public PropertyPricing updateImpl(PropertyPricing propertyPricing);

	/**
	 * Returns the property pricing with the primary key or throws a <code>NoSuchPropertyPricingException</code> if it could not be found.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public PropertyPricing findByPrimaryKey(long pricingId)
		throws NoSuchPropertyPricingException;

	/**
	 * Returns the property pricing with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing, or <code>null</code> if a property pricing with the primary key could not be found
	 */
	public PropertyPricing fetchByPrimaryKey(long pricingId);

	/**
	 * Returns all the property pricings.
	 *
	 * @return the property pricings
	 */
	public java.util.List<PropertyPricing> findAll();

	/**
	 * Returns a range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of property pricings
	 */
	public java.util.List<PropertyPricing> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property pricings
	 */
	public java.util.List<PropertyPricing> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property pricings
	 */
	public java.util.List<PropertyPricing> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyPricing>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the property pricings from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of property pricings.
	 *
	 * @return the number of property pricings
	 */
	public int countAll();

}