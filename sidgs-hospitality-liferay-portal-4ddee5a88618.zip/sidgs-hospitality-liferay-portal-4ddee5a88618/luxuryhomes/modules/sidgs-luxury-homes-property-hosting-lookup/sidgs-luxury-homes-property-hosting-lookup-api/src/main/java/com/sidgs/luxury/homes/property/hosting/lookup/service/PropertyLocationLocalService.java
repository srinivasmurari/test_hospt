/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service;

import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.Projection;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.search.Indexable;
import com.liferay.portal.kernel.search.IndexableType;
import com.liferay.portal.kernel.service.BaseLocalService;
import com.liferay.portal.kernel.service.PersistedModelLocalService;
import com.liferay.portal.kernel.transaction.Isolation;
import com.liferay.portal.kernel.transaction.Propagation;
import com.liferay.portal.kernel.transaction.Transactional;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyLocationException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation;

import java.io.Serializable;

import java.util.List;

import org.osgi.annotation.versioning.ProviderType;

/**
 * Provides the local service interface for PropertyLocation. Methods of this
 * service will not have security checks based on the propagated JAAS
 * credentials because this service can only be accessed from within the same
 * VM.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyLocationLocalServiceUtil
 * @generated
 */
@ProviderType
@Transactional(
	isolation = Isolation.PORTAL,
	rollbackFor = {PortalException.class, SystemException.class}
)
public interface PropertyLocationLocalService
	extends BaseLocalService, PersistedModelLocalService {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this interface directly. Add custom service methods to <code>com.sidgs.luxury.homes.property.hosting.lookup.service.impl.PropertyLocationLocalServiceImpl</code> and rerun ServiceBuilder to automatically copy the method declarations to this interface. Consume the property location local service via injection or a <code>org.osgi.util.tracker.ServiceTracker</code>. Use {@link PropertyLocationLocalServiceUtil} if injection and service tracking are not available.
	 */
	public PropertyLocation addPropertyLocation(
		long hostPropertyId, JSONObject addressJSON, String coordinates);

	/**
	 * Adds the property location to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyLocation the property location
	 * @return the property location that was added
	 */
	@Indexable(type = IndexableType.REINDEX)
	public PropertyLocation addPropertyLocation(
		PropertyLocation propertyLocation);

	/**
	 * @throws PortalException
	 */
	public PersistedModel createPersistedModel(Serializable primaryKeyObj)
		throws PortalException;

	/**
	 * Creates a new property location with the primary key. Does not add the property location to the database.
	 *
	 * @param locationId the primary key for the new property location
	 * @return the new property location
	 */
	@Transactional(enabled = false)
	public PropertyLocation createPropertyLocation(long locationId);

	/**
	 * @throws PortalException
	 */
	@Override
	public PersistedModel deletePersistedModel(PersistedModel persistedModel)
		throws PortalException;

	/**
	 * Deletes the property location with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location that was removed
	 * @throws PortalException if a property location with the primary key could not be found
	 */
	@Indexable(type = IndexableType.DELETE)
	public PropertyLocation deletePropertyLocation(long locationId)
		throws PortalException;

	/**
	 * Deletes the property location from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyLocation the property location
	 * @return the property location that was removed
	 */
	@Indexable(type = IndexableType.DELETE)
	public PropertyLocation deletePropertyLocation(
		PropertyLocation propertyLocation);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public <T> T dslQuery(DSLQuery dslQuery);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public int dslQueryCount(DSLQuery dslQuery);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public DynamicQuery dynamicQuery();

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public <T> List<T> dynamicQuery(DynamicQuery dynamicQuery);

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end);

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<T> orderByComparator);

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public long dynamicQueryCount(DynamicQuery dynamicQuery);

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public long dynamicQueryCount(
		DynamicQuery dynamicQuery, Projection projection);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public PropertyLocation fetchPropertyLocation(long locationId);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public ActionableDynamicQuery getActionableDynamicQuery();

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public IndexableActionableDynamicQuery getIndexableActionableDynamicQuery();

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public String getOSGiServiceIdentifier();

	/**
	 * @throws PortalException
	 */
	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public PersistedModel getPersistedModel(Serializable primaryKeyObj)
		throws PortalException;

	/**
	 * Returns the property location with the primary key.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location
	 * @throws PortalException if a property location with the primary key could not be found
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public PropertyLocation getPropertyLocation(long locationId)
		throws PortalException;

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocationByCountry(String country);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocationByLocalityAndCountry(
		String locality, String country);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocationByLocalityAndState(
		String locality, String state);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation>
		getPropertyLocationByLocalityAndStateAndCountry(
			String locality, String state, String country);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public PropertyLocation getPropertyLocationByPropertyId(long hostPropertyId)
		throws NoSuchPropertyLocationException;

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocationByPropertyId(
		String locality);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocationByState(String state);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocationByStateAndCountry(
		String state, String country);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocationByZipcode(String zipCode);

	/**
	 * Returns a range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of property locations
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<PropertyLocation> getPropertyLocations(int start, int end);

	/**
	 * Returns the number of property locations.
	 *
	 * @return the number of property locations
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public int getPropertyLocationsCount();

	/**
	 * Updates the property location in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyLocation the property location
	 * @return the property location that was updated
	 */
	@Indexable(type = IndexableType.REINDEX)
	public PropertyLocation updatePropertyLocation(
		PropertyLocation propertyLocation);

}