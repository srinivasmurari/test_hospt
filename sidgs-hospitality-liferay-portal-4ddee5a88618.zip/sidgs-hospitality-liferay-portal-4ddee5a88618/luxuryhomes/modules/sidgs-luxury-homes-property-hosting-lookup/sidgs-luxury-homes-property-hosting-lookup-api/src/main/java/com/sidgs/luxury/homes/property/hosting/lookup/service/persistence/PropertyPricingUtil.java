/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the property pricing service. This utility wraps <code>com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.PropertyPricingPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyPricingPersistence
 * @generated
 */
public class PropertyPricingUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(PropertyPricing propertyPricing) {
		getPersistence().clearCache(propertyPricing);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, PropertyPricing> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<PropertyPricing> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<PropertyPricing> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<PropertyPricing> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static PropertyPricing update(PropertyPricing propertyPricing) {
		return getPersistence().update(propertyPricing);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static PropertyPricing update(
		PropertyPricing propertyPricing, ServiceContext serviceContext) {

		return getPersistence().update(propertyPricing, serviceContext);
	}

	/**
	 * Returns all the property pricings where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property pricings
	 */
	public static List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId) {

		return getPersistence().findByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns a range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of matching property pricings
	 */
	public static List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end) {

		return getPersistence().findByHostPropertyId(
			hostPropertyId, start, end);
	}

	/**
	 * Returns an ordered range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property pricings
	 */
	public static List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().findByHostPropertyId(
			hostPropertyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property pricings
	 */
	public static List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByHostPropertyId(
			hostPropertyId, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public static PropertyPricing findByHostPropertyId_First(
			long hostPropertyId,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByHostPropertyId_First(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the first property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public static PropertyPricing fetchByHostPropertyId_First(
		long hostPropertyId,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().fetchByHostPropertyId_First(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the last property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public static PropertyPricing findByHostPropertyId_Last(
			long hostPropertyId,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByHostPropertyId_Last(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the last property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public static PropertyPricing fetchByHostPropertyId_Last(
		long hostPropertyId,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().fetchByHostPropertyId_Last(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the property pricings before and after the current property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param pricingId the primary key of the current property pricing
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public static PropertyPricing[] findByHostPropertyId_PrevAndNext(
			long pricingId, long hostPropertyId,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByHostPropertyId_PrevAndNext(
			pricingId, hostPropertyId, orderByComparator);
	}

	/**
	 * Removes all the property pricings where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 */
	public static void removeByHostPropertyId(long hostPropertyId) {
		getPersistence().removeByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns the number of property pricings where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property pricings
	 */
	public static int countByHostPropertyId(long hostPropertyId) {
		return getPersistence().countByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns the property pricing where floorId = &#63; or throws a <code>NoSuchPropertyPricingException</code> if it could not be found.
	 *
	 * @param floorId the floor ID
	 * @return the matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public static PropertyPricing findByFloorId(long floorId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByFloorId(floorId);
	}

	/**
	 * Returns the property pricing where floorId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param floorId the floor ID
	 * @return the matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public static PropertyPricing fetchByFloorId(long floorId) {
		return getPersistence().fetchByFloorId(floorId);
	}

	/**
	 * Returns the property pricing where floorId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param floorId the floor ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public static PropertyPricing fetchByFloorId(
		long floorId, boolean useFinderCache) {

		return getPersistence().fetchByFloorId(floorId, useFinderCache);
	}

	/**
	 * Removes the property pricing where floorId = &#63; from the database.
	 *
	 * @param floorId the floor ID
	 * @return the property pricing that was removed
	 */
	public static PropertyPricing removeByFloorId(long floorId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().removeByFloorId(floorId);
	}

	/**
	 * Returns the number of property pricings where floorId = &#63;.
	 *
	 * @param floorId the floor ID
	 * @return the number of matching property pricings
	 */
	public static int countByFloorId(long floorId) {
		return getPersistence().countByFloorId(floorId);
	}

	/**
	 * Returns all the property pricings where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @return the matching property pricings
	 */
	public static List<PropertyPricing> findByBasePrice(double basePrice) {
		return getPersistence().findByBasePrice(basePrice);
	}

	/**
	 * Returns a range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of matching property pricings
	 */
	public static List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end) {

		return getPersistence().findByBasePrice(basePrice, start, end);
	}

	/**
	 * Returns an ordered range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property pricings
	 */
	public static List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().findByBasePrice(
			basePrice, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property pricings
	 */
	public static List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByBasePrice(
			basePrice, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public static PropertyPricing findByBasePrice_First(
			double basePrice,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByBasePrice_First(
			basePrice, orderByComparator);
	}

	/**
	 * Returns the first property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public static PropertyPricing fetchByBasePrice_First(
		double basePrice,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().fetchByBasePrice_First(
			basePrice, orderByComparator);
	}

	/**
	 * Returns the last property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	public static PropertyPricing findByBasePrice_Last(
			double basePrice,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByBasePrice_Last(
			basePrice, orderByComparator);
	}

	/**
	 * Returns the last property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	public static PropertyPricing fetchByBasePrice_Last(
		double basePrice,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().fetchByBasePrice_Last(
			basePrice, orderByComparator);
	}

	/**
	 * Returns the property pricings before and after the current property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param pricingId the primary key of the current property pricing
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public static PropertyPricing[] findByBasePrice_PrevAndNext(
			long pricingId, double basePrice,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByBasePrice_PrevAndNext(
			pricingId, basePrice, orderByComparator);
	}

	/**
	 * Removes all the property pricings where basePrice = &#63; from the database.
	 *
	 * @param basePrice the base price
	 */
	public static void removeByBasePrice(double basePrice) {
		getPersistence().removeByBasePrice(basePrice);
	}

	/**
	 * Returns the number of property pricings where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @return the number of matching property pricings
	 */
	public static int countByBasePrice(double basePrice) {
		return getPersistence().countByBasePrice(basePrice);
	}

	/**
	 * Caches the property pricing in the entity cache if it is enabled.
	 *
	 * @param propertyPricing the property pricing
	 */
	public static void cacheResult(PropertyPricing propertyPricing) {
		getPersistence().cacheResult(propertyPricing);
	}

	/**
	 * Caches the property pricings in the entity cache if it is enabled.
	 *
	 * @param propertyPricings the property pricings
	 */
	public static void cacheResult(List<PropertyPricing> propertyPricings) {
		getPersistence().cacheResult(propertyPricings);
	}

	/**
	 * Creates a new property pricing with the primary key. Does not add the property pricing to the database.
	 *
	 * @param pricingId the primary key for the new property pricing
	 * @return the new property pricing
	 */
	public static PropertyPricing create(long pricingId) {
		return getPersistence().create(pricingId);
	}

	/**
	 * Removes the property pricing with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing that was removed
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public static PropertyPricing remove(long pricingId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().remove(pricingId);
	}

	public static PropertyPricing updateImpl(PropertyPricing propertyPricing) {
		return getPersistence().updateImpl(propertyPricing);
	}

	/**
	 * Returns the property pricing with the primary key or throws a <code>NoSuchPropertyPricingException</code> if it could not be found.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	public static PropertyPricing findByPrimaryKey(long pricingId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return getPersistence().findByPrimaryKey(pricingId);
	}

	/**
	 * Returns the property pricing with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing, or <code>null</code> if a property pricing with the primary key could not be found
	 */
	public static PropertyPricing fetchByPrimaryKey(long pricingId) {
		return getPersistence().fetchByPrimaryKey(pricingId);
	}

	/**
	 * Returns all the property pricings.
	 *
	 * @return the property pricings
	 */
	public static List<PropertyPricing> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of property pricings
	 */
	public static List<PropertyPricing> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property pricings
	 */
	public static List<PropertyPricing> findAll(
		int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property pricings
	 */
	public static List<PropertyPricing> findAll(
		int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the property pricings from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of property pricings.
	 *
	 * @return the number of property pricings
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static PropertyPricingPersistence getPersistence() {
		return _persistence;
	}

	public static void setPersistence(PropertyPricingPersistence persistence) {
		_persistence = persistence;
	}

	private static volatile PropertyPricingPersistence _persistence;

}