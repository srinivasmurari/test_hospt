/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service;

import com.liferay.portal.kernel.service.ServiceWrapper;
import com.liferay.portal.kernel.service.persistence.BasePersistence;

/**
 * Provides a wrapper for {@link HostPropertyLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see HostPropertyLocalService
 * @generated
 */
public class HostPropertyLocalServiceWrapper
	implements HostPropertyLocalService,
			   ServiceWrapper<HostPropertyLocalService> {

	public HostPropertyLocalServiceWrapper() {
		this(null);
	}

	public HostPropertyLocalServiceWrapper(
		HostPropertyLocalService hostPropertyLocalService) {

		_hostPropertyLocalService = hostPropertyLocalService;
	}

	/**
	 * Adds the host property to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect HostPropertyLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param hostProperty the host property
	 * @return the host property that was added
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
		addHostProperty(
			com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
				hostProperty) {

		return _hostPropertyLocalService.addHostProperty(hostProperty);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
		addHostProperty(
			long userId, String articleId, int totalGuests, int bedrooms,
			java.util.Date availableFrom) {

		return _hostPropertyLocalService.addHostProperty(
			userId, articleId, totalGuests, bedrooms, availableFrom);
	}

	/**
	 * Creates a new host property with the primary key. Does not add the host property to the database.
	 *
	 * @param hostPropertyId the primary key for the new host property
	 * @return the new host property
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
		createHostProperty(long hostPropertyId) {

		return _hostPropertyLocalService.createHostProperty(hostPropertyId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _hostPropertyLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Deletes the host property from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect HostPropertyLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param hostProperty the host property
	 * @return the host property that was removed
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
		deleteHostProperty(
			com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
				hostProperty) {

		return _hostPropertyLocalService.deleteHostProperty(hostProperty);
	}

	/**
	 * Deletes the host property with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect HostPropertyLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property that was removed
	 * @throws PortalException if a host property with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
			deleteHostProperty(long hostPropertyId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _hostPropertyLocalService.deleteHostProperty(hostPropertyId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _hostPropertyLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _hostPropertyLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _hostPropertyLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _hostPropertyLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _hostPropertyLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _hostPropertyLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _hostPropertyLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _hostPropertyLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _hostPropertyLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
		fetchHostProperty(long hostPropertyId) {

		return _hostPropertyLocalService.fetchHostProperty(hostPropertyId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _hostPropertyLocalService.getActionableDynamicQuery();
	}

	/**
	 * Returns a range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of host properties
	 */
	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty>
			getHostProperties(int start, int end) {

		return _hostPropertyLocalService.getHostProperties(start, end);
	}

	/**
	 * Returns the number of host properties.
	 *
	 * @return the number of host properties
	 */
	@Override
	public int getHostPropertiesCount() {
		return _hostPropertyLocalService.getHostPropertiesCount();
	}

	/**
	 * Returns the host property with the primary key.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property
	 * @throws PortalException if a host property with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
			getHostProperty(long hostPropertyId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _hostPropertyLocalService.getHostProperty(hostPropertyId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _hostPropertyLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _hostPropertyLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _hostPropertyLocalService.getPersistedModel(primaryKeyObj);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
			getPropertyByArticleId(String articleId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchHostPropertyException {

		return _hostPropertyLocalService.getPropertyByArticleId(articleId);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty>
			getPropertyByFlag(boolean active) {

		return _hostPropertyLocalService.getPropertyByFlag(active);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty>
			getPropertyByUserIdAndFlag(long userId, boolean active) {

		return _hostPropertyLocalService.getPropertyByUserIdAndFlag(
			userId, active);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty>
			getPropertyFromAvailableDate(java.util.Date startDate) {

		return _hostPropertyLocalService.getPropertyFromAvailableDate(
			startDate);
	}

	/**
	 * Updates the host property in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect HostPropertyLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param hostProperty the host property
	 * @return the host property that was updated
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
		updateHostProperty(
			com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty
				hostProperty) {

		return _hostPropertyLocalService.updateHostProperty(hostProperty);
	}

	@Override
	public BasePersistence<?> getBasePersistence() {
		return _hostPropertyLocalService.getBasePersistence();
	}

	@Override
	public HostPropertyLocalService getWrappedService() {
		return _hostPropertyLocalService;
	}

	@Override
	public void setWrappedService(
		HostPropertyLocalService hostPropertyLocalService) {

		_hostPropertyLocalService = hostPropertyLocalService;
	}

	private HostPropertyLocalService _hostPropertyLocalService;

}