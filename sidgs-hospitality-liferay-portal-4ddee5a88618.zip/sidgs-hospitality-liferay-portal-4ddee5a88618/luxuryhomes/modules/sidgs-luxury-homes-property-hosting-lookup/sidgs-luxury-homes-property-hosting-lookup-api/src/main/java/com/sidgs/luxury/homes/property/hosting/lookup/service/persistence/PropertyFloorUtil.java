/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the property floor service. This utility wraps <code>com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.PropertyFloorPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyFloorPersistence
 * @generated
 */
public class PropertyFloorUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(PropertyFloor propertyFloor) {
		getPersistence().clearCache(propertyFloor);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, PropertyFloor> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<PropertyFloor> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<PropertyFloor> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<PropertyFloor> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static PropertyFloor update(PropertyFloor propertyFloor) {
		return getPersistence().update(propertyFloor);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static PropertyFloor update(
		PropertyFloor propertyFloor, ServiceContext serviceContext) {

		return getPersistence().update(propertyFloor, serviceContext);
	}

	/**
	 * Returns all the property floors where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property floors
	 */
	public static List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId) {

		return getPersistence().findByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns a range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public static List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end) {

		return getPersistence().findByHostPropertyId(
			hostPropertyId, start, end);
	}

	/**
	 * Returns an ordered range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findByHostPropertyId(
			hostPropertyId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property floors where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByHostPropertyId(
			hostPropertyId, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByHostPropertyId_First(
			long hostPropertyId,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByHostPropertyId_First(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the first property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByHostPropertyId_First(
		long hostPropertyId,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByHostPropertyId_First(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByHostPropertyId_Last(
			long hostPropertyId,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByHostPropertyId_Last(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByHostPropertyId_Last(
		long hostPropertyId,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByHostPropertyId_Last(
			hostPropertyId, orderByComparator);
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor[] findByHostPropertyId_PrevAndNext(
			long floorId, long hostPropertyId,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByHostPropertyId_PrevAndNext(
			floorId, hostPropertyId, orderByComparator);
	}

	/**
	 * Removes all the property floors where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 */
	public static void removeByHostPropertyId(long hostPropertyId) {
		getPersistence().removeByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns the number of property floors where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property floors
	 */
	public static int countByHostPropertyId(long hostPropertyId) {
		return getPersistence().countByHostPropertyId(hostPropertyId);
	}

	/**
	 * Returns all the property floors where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @return the matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests(int totalGuests) {
		return getPersistence().findByTotalGuests(totalGuests);
	}

	/**
	 * Returns a range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end) {

		return getPersistence().findByTotalGuests(totalGuests, start, end);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findByTotalGuests(
			totalGuests, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests(
		int totalGuests, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByTotalGuests(
			totalGuests, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByTotalGuests_First(
			int totalGuests, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByTotalGuests_First(
			totalGuests, orderByComparator);
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByTotalGuests_First(
		int totalGuests, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByTotalGuests_First(
			totalGuests, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByTotalGuests_Last(
			int totalGuests, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByTotalGuests_Last(
			totalGuests, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByTotalGuests_Last(
		int totalGuests, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByTotalGuests_Last(
			totalGuests, orderByComparator);
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where totalGuests = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param totalGuests the total guests
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor[] findByTotalGuests_PrevAndNext(
			long floorId, int totalGuests,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByTotalGuests_PrevAndNext(
			floorId, totalGuests, orderByComparator);
	}

	/**
	 * Removes all the property floors where totalGuests = &#63; from the database.
	 *
	 * @param totalGuests the total guests
	 */
	public static void removeByTotalGuests(int totalGuests) {
		getPersistence().removeByTotalGuests(totalGuests);
	}

	/**
	 * Returns the number of property floors where totalGuests = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @return the number of matching property floors
	 */
	public static int countByTotalGuests(int totalGuests) {
		return getPersistence().countByTotalGuests(totalGuests);
	}

	/**
	 * Returns all the property floors where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @return the matching property floors
	 */
	public static List<PropertyFloor> findByBedrooms(int bedrooms) {
		return getPersistence().findByBedrooms(bedrooms);
	}

	/**
	 * Returns a range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public static List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end) {

		return getPersistence().findByBedrooms(bedrooms, start, end);
	}

	/**
	 * Returns an ordered range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findByBedrooms(
			bedrooms, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property floors where bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByBedrooms(
		int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByBedrooms(
			bedrooms, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByBedrooms_First(
			int bedrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBedrooms_First(
			bedrooms, orderByComparator);
	}

	/**
	 * Returns the first property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByBedrooms_First(
		int bedrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByBedrooms_First(
			bedrooms, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByBedrooms_Last(
			int bedrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBedrooms_Last(
			bedrooms, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByBedrooms_Last(
		int bedrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByBedrooms_Last(
			bedrooms, orderByComparator);
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where bedrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor[] findByBedrooms_PrevAndNext(
			long floorId, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBedrooms_PrevAndNext(
			floorId, bedrooms, orderByComparator);
	}

	/**
	 * Removes all the property floors where bedrooms = &#63; from the database.
	 *
	 * @param bedrooms the bedrooms
	 */
	public static void removeByBedrooms(int bedrooms) {
		getPersistence().removeByBedrooms(bedrooms);
	}

	/**
	 * Returns the number of property floors where bedrooms = &#63;.
	 *
	 * @param bedrooms the bedrooms
	 * @return the number of matching property floors
	 */
	public static int countByBedrooms(int bedrooms) {
		return getPersistence().countByBedrooms(bedrooms);
	}

	/**
	 * Returns all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @return the matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms) {

		return getPersistence().findByTotalGuests_Bedrooms(
			totalGuests, bedrooms);
	}

	/**
	 * Returns a range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end) {

		return getPersistence().findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, start, end);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByTotalGuests_Bedrooms(
			totalGuests, bedrooms, start, end, orderByComparator,
			useFinderCache);
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByTotalGuests_Bedrooms_First(
			int totalGuests, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByTotalGuests_Bedrooms_First(
			totalGuests, bedrooms, orderByComparator);
	}

	/**
	 * Returns the first property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByTotalGuests_Bedrooms_First(
		int totalGuests, int bedrooms,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByTotalGuests_Bedrooms_First(
			totalGuests, bedrooms, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByTotalGuests_Bedrooms_Last(
			int totalGuests, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByTotalGuests_Bedrooms_Last(
			totalGuests, bedrooms, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByTotalGuests_Bedrooms_Last(
		int totalGuests, int bedrooms,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByTotalGuests_Bedrooms_Last(
			totalGuests, bedrooms, orderByComparator);
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor[] findByTotalGuests_Bedrooms_PrevAndNext(
			long floorId, int totalGuests, int bedrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByTotalGuests_Bedrooms_PrevAndNext(
			floorId, totalGuests, bedrooms, orderByComparator);
	}

	/**
	 * Removes all the property floors where totalGuests = &#63; and bedrooms = &#63; from the database.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 */
	public static void removeByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms) {

		getPersistence().removeByTotalGuests_Bedrooms(totalGuests, bedrooms);
	}

	/**
	 * Returns the number of property floors where totalGuests = &#63; and bedrooms = &#63;.
	 *
	 * @param totalGuests the total guests
	 * @param bedrooms the bedrooms
	 * @return the number of matching property floors
	 */
	public static int countByTotalGuests_Bedrooms(
		int totalGuests, int bedrooms) {

		return getPersistence().countByTotalGuests_Bedrooms(
			totalGuests, bedrooms);
	}

	/**
	 * Returns all the property floors where beds = &#63;.
	 *
	 * @param beds the beds
	 * @return the matching property floors
	 */
	public static List<PropertyFloor> findByBeds(int beds) {
		return getPersistence().findByBeds(beds);
	}

	/**
	 * Returns a range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public static List<PropertyFloor> findByBeds(int beds, int start, int end) {
		return getPersistence().findByBeds(beds, start, end);
	}

	/**
	 * Returns an ordered range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByBeds(
		int beds, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findByBeds(beds, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property floors where beds = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param beds the beds
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByBeds(
		int beds, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByBeds(
			beds, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByBeds_First(
			int beds, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBeds_First(beds, orderByComparator);
	}

	/**
	 * Returns the first property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByBeds_First(
		int beds, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByBeds_First(beds, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByBeds_Last(
			int beds, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBeds_Last(beds, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where beds = &#63;.
	 *
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByBeds_Last(
		int beds, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByBeds_Last(beds, orderByComparator);
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where beds = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param beds the beds
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor[] findByBeds_PrevAndNext(
			long floorId, int beds,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBeds_PrevAndNext(
			floorId, beds, orderByComparator);
	}

	/**
	 * Removes all the property floors where beds = &#63; from the database.
	 *
	 * @param beds the beds
	 */
	public static void removeByBeds(int beds) {
		getPersistence().removeByBeds(beds);
	}

	/**
	 * Returns the number of property floors where beds = &#63;.
	 *
	 * @param beds the beds
	 * @return the number of matching property floors
	 */
	public static int countByBeds(int beds) {
		return getPersistence().countByBeds(beds);
	}

	/**
	 * Returns all the property floors where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @return the matching property floors
	 */
	public static List<PropertyFloor> findByBathrooms(int bathrooms) {
		return getPersistence().findByBathrooms(bathrooms);
	}

	/**
	 * Returns a range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of matching property floors
	 */
	public static List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end) {

		return getPersistence().findByBathrooms(bathrooms, start, end);
	}

	/**
	 * Returns an ordered range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findByBathrooms(
			bathrooms, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property floors where bathrooms = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param bathrooms the bathrooms
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property floors
	 */
	public static List<PropertyFloor> findByBathrooms(
		int bathrooms, int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByBathrooms(
			bathrooms, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByBathrooms_First(
			int bathrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBathrooms_First(
			bathrooms, orderByComparator);
	}

	/**
	 * Returns the first property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByBathrooms_First(
		int bathrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByBathrooms_First(
			bathrooms, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor
	 * @throws NoSuchPropertyFloorException if a matching property floor could not be found
	 */
	public static PropertyFloor findByBathrooms_Last(
			int bathrooms, OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBathrooms_Last(
			bathrooms, orderByComparator);
	}

	/**
	 * Returns the last property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property floor, or <code>null</code> if a matching property floor could not be found
	 */
	public static PropertyFloor fetchByBathrooms_Last(
		int bathrooms, OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().fetchByBathrooms_Last(
			bathrooms, orderByComparator);
	}

	/**
	 * Returns the property floors before and after the current property floor in the ordered set where bathrooms = &#63;.
	 *
	 * @param floorId the primary key of the current property floor
	 * @param bathrooms the bathrooms
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor[] findByBathrooms_PrevAndNext(
			long floorId, int bathrooms,
			OrderByComparator<PropertyFloor> orderByComparator)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByBathrooms_PrevAndNext(
			floorId, bathrooms, orderByComparator);
	}

	/**
	 * Removes all the property floors where bathrooms = &#63; from the database.
	 *
	 * @param bathrooms the bathrooms
	 */
	public static void removeByBathrooms(int bathrooms) {
		getPersistence().removeByBathrooms(bathrooms);
	}

	/**
	 * Returns the number of property floors where bathrooms = &#63;.
	 *
	 * @param bathrooms the bathrooms
	 * @return the number of matching property floors
	 */
	public static int countByBathrooms(int bathrooms) {
		return getPersistence().countByBathrooms(bathrooms);
	}

	/**
	 * Caches the property floor in the entity cache if it is enabled.
	 *
	 * @param propertyFloor the property floor
	 */
	public static void cacheResult(PropertyFloor propertyFloor) {
		getPersistence().cacheResult(propertyFloor);
	}

	/**
	 * Caches the property floors in the entity cache if it is enabled.
	 *
	 * @param propertyFloors the property floors
	 */
	public static void cacheResult(List<PropertyFloor> propertyFloors) {
		getPersistence().cacheResult(propertyFloors);
	}

	/**
	 * Creates a new property floor with the primary key. Does not add the property floor to the database.
	 *
	 * @param floorId the primary key for the new property floor
	 * @return the new property floor
	 */
	public static PropertyFloor create(long floorId) {
		return getPersistence().create(floorId);
	}

	/**
	 * Removes the property floor with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor that was removed
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor remove(long floorId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().remove(floorId);
	}

	public static PropertyFloor updateImpl(PropertyFloor propertyFloor) {
		return getPersistence().updateImpl(propertyFloor);
	}

	/**
	 * Returns the property floor with the primary key or throws a <code>NoSuchPropertyFloorException</code> if it could not be found.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor
	 * @throws NoSuchPropertyFloorException if a property floor with the primary key could not be found
	 */
	public static PropertyFloor findByPrimaryKey(long floorId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyFloorException {

		return getPersistence().findByPrimaryKey(floorId);
	}

	/**
	 * Returns the property floor with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param floorId the primary key of the property floor
	 * @return the property floor, or <code>null</code> if a property floor with the primary key could not be found
	 */
	public static PropertyFloor fetchByPrimaryKey(long floorId) {
		return getPersistence().fetchByPrimaryKey(floorId);
	}

	/**
	 * Returns all the property floors.
	 *
	 * @return the property floors
	 */
	public static List<PropertyFloor> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @return the range of property floors
	 */
	public static List<PropertyFloor> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property floors
	 */
	public static List<PropertyFloor> findAll(
		int start, int end,
		OrderByComparator<PropertyFloor> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the property floors.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyFloorModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property floors
	 * @param end the upper bound of the range of property floors (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property floors
	 */
	public static List<PropertyFloor> findAll(
		int start, int end, OrderByComparator<PropertyFloor> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the property floors from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of property floors.
	 *
	 * @return the number of property floors
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static PropertyFloorPersistence getPersistence() {
		return _persistence;
	}

	public static void setPersistence(PropertyFloorPersistence persistence) {
		_persistence = persistence;
	}

	private static volatile PropertyFloorPersistence _persistence;

}