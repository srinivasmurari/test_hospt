/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link PropertyLocation}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyLocation
 * @generated
 */
public class PropertyLocationWrapper
	extends BaseModelWrapper<PropertyLocation>
	implements ModelWrapper<PropertyLocation>, PropertyLocation {

	public PropertyLocationWrapper(PropertyLocation propertyLocation) {
		super(propertyLocation);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("locationId", getLocationId());
		attributes.put("hostPropertyId", getHostPropertyId());
		attributes.put("plotNo", getPlotNo());
		attributes.put("street", getStreet());
		attributes.put("landmark", getLandmark());
		attributes.put("locality", getLocality());
		attributes.put("city", getCity());
		attributes.put("state", getState());
		attributes.put("country", getCountry());
		attributes.put("zipCode", getZipCode());
		attributes.put("coordinates", getCoordinates());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long locationId = (Long)attributes.get("locationId");

		if (locationId != null) {
			setLocationId(locationId);
		}

		Long hostPropertyId = (Long)attributes.get("hostPropertyId");

		if (hostPropertyId != null) {
			setHostPropertyId(hostPropertyId);
		}

		String plotNo = (String)attributes.get("plotNo");

		if (plotNo != null) {
			setPlotNo(plotNo);
		}

		String street = (String)attributes.get("street");

		if (street != null) {
			setStreet(street);
		}

		String landmark = (String)attributes.get("landmark");

		if (landmark != null) {
			setLandmark(landmark);
		}

		String locality = (String)attributes.get("locality");

		if (locality != null) {
			setLocality(locality);
		}

		String city = (String)attributes.get("city");

		if (city != null) {
			setCity(city);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String country = (String)attributes.get("country");

		if (country != null) {
			setCountry(country);
		}

		String zipCode = (String)attributes.get("zipCode");

		if (zipCode != null) {
			setZipCode(zipCode);
		}

		String coordinates = (String)attributes.get("coordinates");

		if (coordinates != null) {
			setCoordinates(coordinates);
		}
	}

	@Override
	public PropertyLocation cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the city of this property location.
	 *
	 * @return the city of this property location
	 */
	@Override
	public String getCity() {
		return model.getCity();
	}

	/**
	 * Returns the coordinates of this property location.
	 *
	 * @return the coordinates of this property location
	 */
	@Override
	public String getCoordinates() {
		return model.getCoordinates();
	}

	/**
	 * Returns the country of this property location.
	 *
	 * @return the country of this property location
	 */
	@Override
	public String getCountry() {
		return model.getCountry();
	}

	/**
	 * Returns the host property ID of this property location.
	 *
	 * @return the host property ID of this property location
	 */
	@Override
	public long getHostPropertyId() {
		return model.getHostPropertyId();
	}

	/**
	 * Returns the landmark of this property location.
	 *
	 * @return the landmark of this property location
	 */
	@Override
	public String getLandmark() {
		return model.getLandmark();
	}

	/**
	 * Returns the locality of this property location.
	 *
	 * @return the locality of this property location
	 */
	@Override
	public String getLocality() {
		return model.getLocality();
	}

	/**
	 * Returns the location ID of this property location.
	 *
	 * @return the location ID of this property location
	 */
	@Override
	public long getLocationId() {
		return model.getLocationId();
	}

	/**
	 * Returns the plot no of this property location.
	 *
	 * @return the plot no of this property location
	 */
	@Override
	public String getPlotNo() {
		return model.getPlotNo();
	}

	/**
	 * Returns the primary key of this property location.
	 *
	 * @return the primary key of this property location
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the state of this property location.
	 *
	 * @return the state of this property location
	 */
	@Override
	public String getState() {
		return model.getState();
	}

	/**
	 * Returns the street of this property location.
	 *
	 * @return the street of this property location
	 */
	@Override
	public String getStreet() {
		return model.getStreet();
	}

	/**
	 * Returns the zip code of this property location.
	 *
	 * @return the zip code of this property location
	 */
	@Override
	public String getZipCode() {
		return model.getZipCode();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the city of this property location.
	 *
	 * @param city the city of this property location
	 */
	@Override
	public void setCity(String city) {
		model.setCity(city);
	}

	/**
	 * Sets the coordinates of this property location.
	 *
	 * @param coordinates the coordinates of this property location
	 */
	@Override
	public void setCoordinates(String coordinates) {
		model.setCoordinates(coordinates);
	}

	/**
	 * Sets the country of this property location.
	 *
	 * @param country the country of this property location
	 */
	@Override
	public void setCountry(String country) {
		model.setCountry(country);
	}

	/**
	 * Sets the host property ID of this property location.
	 *
	 * @param hostPropertyId the host property ID of this property location
	 */
	@Override
	public void setHostPropertyId(long hostPropertyId) {
		model.setHostPropertyId(hostPropertyId);
	}

	/**
	 * Sets the landmark of this property location.
	 *
	 * @param landmark the landmark of this property location
	 */
	@Override
	public void setLandmark(String landmark) {
		model.setLandmark(landmark);
	}

	/**
	 * Sets the locality of this property location.
	 *
	 * @param locality the locality of this property location
	 */
	@Override
	public void setLocality(String locality) {
		model.setLocality(locality);
	}

	/**
	 * Sets the location ID of this property location.
	 *
	 * @param locationId the location ID of this property location
	 */
	@Override
	public void setLocationId(long locationId) {
		model.setLocationId(locationId);
	}

	/**
	 * Sets the plot no of this property location.
	 *
	 * @param plotNo the plot no of this property location
	 */
	@Override
	public void setPlotNo(String plotNo) {
		model.setPlotNo(plotNo);
	}

	/**
	 * Sets the primary key of this property location.
	 *
	 * @param primaryKey the primary key of this property location
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the state of this property location.
	 *
	 * @param state the state of this property location
	 */
	@Override
	public void setState(String state) {
		model.setState(state);
	}

	/**
	 * Sets the street of this property location.
	 *
	 * @param street the street of this property location
	 */
	@Override
	public void setStreet(String street) {
		model.setStreet(street);
	}

	/**
	 * Sets the zip code of this property location.
	 *
	 * @param zipCode the zip code of this property location
	 */
	@Override
	public void setZipCode(String zipCode) {
		model.setZipCode(zipCode);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected PropertyLocationWrapper wrap(PropertyLocation propertyLocation) {
		return new PropertyLocationWrapper(propertyLocation);
	}

}