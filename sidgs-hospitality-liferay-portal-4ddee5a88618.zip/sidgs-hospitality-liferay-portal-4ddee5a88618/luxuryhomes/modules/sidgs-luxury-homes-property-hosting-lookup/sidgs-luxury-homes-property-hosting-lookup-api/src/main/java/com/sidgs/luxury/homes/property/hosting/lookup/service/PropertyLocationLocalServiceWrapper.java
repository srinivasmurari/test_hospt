/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service;

import com.liferay.portal.kernel.service.ServiceWrapper;
import com.liferay.portal.kernel.service.persistence.BasePersistence;

/**
 * Provides a wrapper for {@link PropertyLocationLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyLocationLocalService
 * @generated
 */
public class PropertyLocationLocalServiceWrapper
	implements PropertyLocationLocalService,
			   ServiceWrapper<PropertyLocationLocalService> {

	public PropertyLocationLocalServiceWrapper() {
		this(null);
	}

	public PropertyLocationLocalServiceWrapper(
		PropertyLocationLocalService propertyLocationLocalService) {

		_propertyLocationLocalService = propertyLocationLocalService;
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
		addPropertyLocation(
			long hostPropertyId,
			com.liferay.portal.kernel.json.JSONObject addressJSON,
			String coordinates) {

		return _propertyLocationLocalService.addPropertyLocation(
			hostPropertyId, addressJSON, coordinates);
	}

	/**
	 * Adds the property location to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyLocation the property location
	 * @return the property location that was added
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
		addPropertyLocation(
			com.sidgs.luxury.homes.property.hosting.lookup.model.
				PropertyLocation propertyLocation) {

		return _propertyLocationLocalService.addPropertyLocation(
			propertyLocation);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyLocationLocalService.createPersistedModel(
			primaryKeyObj);
	}

	/**
	 * Creates a new property location with the primary key. Does not add the property location to the database.
	 *
	 * @param locationId the primary key for the new property location
	 * @return the new property location
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
		createPropertyLocation(long locationId) {

		return _propertyLocationLocalService.createPropertyLocation(locationId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyLocationLocalService.deletePersistedModel(
			persistedModel);
	}

	/**
	 * Deletes the property location with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location that was removed
	 * @throws PortalException if a property location with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
			deletePropertyLocation(long locationId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyLocationLocalService.deletePropertyLocation(locationId);
	}

	/**
	 * Deletes the property location from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyLocation the property location
	 * @return the property location that was removed
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
		deletePropertyLocation(
			com.sidgs.luxury.homes.property.hosting.lookup.model.
				PropertyLocation propertyLocation) {

		return _propertyLocationLocalService.deletePropertyLocation(
			propertyLocation);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _propertyLocationLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _propertyLocationLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _propertyLocationLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _propertyLocationLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _propertyLocationLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _propertyLocationLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _propertyLocationLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _propertyLocationLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
		fetchPropertyLocation(long locationId) {

		return _propertyLocationLocalService.fetchPropertyLocation(locationId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _propertyLocationLocalService.getActionableDynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _propertyLocationLocalService.
			getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _propertyLocationLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyLocationLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Returns the property location with the primary key.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location
	 * @throws PortalException if a property location with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
			getPropertyLocation(long locationId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyLocationLocalService.getPropertyLocation(locationId);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByCountry(String country) {

		return _propertyLocationLocalService.getPropertyLocationByCountry(
			country);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByLocalityAndCountry(
				String locality, String country) {

		return _propertyLocationLocalService.
			getPropertyLocationByLocalityAndCountry(locality, country);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByLocalityAndState(
				String locality, String state) {

		return _propertyLocationLocalService.
			getPropertyLocationByLocalityAndState(locality, state);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByLocalityAndStateAndCountry(
				String locality, String state, String country) {

		return _propertyLocationLocalService.
			getPropertyLocationByLocalityAndStateAndCountry(
				locality, state, country);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
			getPropertyLocationByPropertyId(long hostPropertyId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyLocationException {

		return _propertyLocationLocalService.getPropertyLocationByPropertyId(
			hostPropertyId);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByPropertyId(String locality) {

		return _propertyLocationLocalService.getPropertyLocationByPropertyId(
			locality);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByState(String state) {

		return _propertyLocationLocalService.getPropertyLocationByState(state);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByStateAndCountry(String state, String country) {

		return _propertyLocationLocalService.
			getPropertyLocationByStateAndCountry(state, country);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocationByZipcode(String zipCode) {

		return _propertyLocationLocalService.getPropertyLocationByZipcode(
			zipCode);
	}

	/**
	 * Returns a range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of property locations
	 */
	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation>
			getPropertyLocations(int start, int end) {

		return _propertyLocationLocalService.getPropertyLocations(start, end);
	}

	/**
	 * Returns the number of property locations.
	 *
	 * @return the number of property locations
	 */
	@Override
	public int getPropertyLocationsCount() {
		return _propertyLocationLocalService.getPropertyLocationsCount();
	}

	/**
	 * Updates the property location in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyLocationLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyLocation the property location
	 * @return the property location that was updated
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation
		updatePropertyLocation(
			com.sidgs.luxury.homes.property.hosting.lookup.model.
				PropertyLocation propertyLocation) {

		return _propertyLocationLocalService.updatePropertyLocation(
			propertyLocation);
	}

	@Override
	public BasePersistence<?> getBasePersistence() {
		return _propertyLocationLocalService.getBasePersistence();
	}

	@Override
	public PropertyLocationLocalService getWrappedService() {
		return _propertyLocationLocalService;
	}

	@Override
	public void setWrappedService(
		PropertyLocationLocalService propertyLocationLocalService) {

		_propertyLocationLocalService = propertyLocationLocalService;
	}

	private PropertyLocationLocalService _propertyLocationLocalService;

}