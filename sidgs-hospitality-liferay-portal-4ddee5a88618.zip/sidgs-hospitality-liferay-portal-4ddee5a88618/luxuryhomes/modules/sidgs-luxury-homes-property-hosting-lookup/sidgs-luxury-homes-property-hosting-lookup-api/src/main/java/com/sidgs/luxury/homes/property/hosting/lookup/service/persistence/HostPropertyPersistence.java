/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchHostPropertyException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the host property service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see HostPropertyUtil
 * @generated
 */
@ProviderType
public interface HostPropertyPersistence extends BasePersistence<HostProperty> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link HostPropertyUtil} to access the host property persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns the host property where articleId = &#63; or throws a <code>NoSuchHostPropertyException</code> if it could not be found.
	 *
	 * @param articleId the article ID
	 * @return the matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public HostProperty findByArticleId(String articleId)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the host property where articleId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param articleId the article ID
	 * @return the matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchByArticleId(String articleId);

	/**
	 * Returns the host property where articleId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param articleId the article ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchByArticleId(
		String articleId, boolean useFinderCache);

	/**
	 * Removes the host property where articleId = &#63; from the database.
	 *
	 * @param articleId the article ID
	 * @return the host property that was removed
	 */
	public HostProperty removeByArticleId(String articleId)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the number of host properties where articleId = &#63;.
	 *
	 * @param articleId the article ID
	 * @return the number of matching host properties
	 */
	public int countByArticleId(String articleId);

	/**
	 * Returns all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @return the matching host properties
	 */
	public java.util.List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active);

	/**
	 * Returns a range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	public java.util.List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end);

	/**
	 * Returns an ordered range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	public java.util.List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns an ordered range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	public java.util.List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public HostProperty findByUserId_Active_First(
			long createdByUserId, boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the first host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchByUserId_Active_First(
		long createdByUserId, boolean active,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns the last host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public HostProperty findByUserId_Active_Last(
			long createdByUserId, boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the last host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchByUserId_Active_Last(
		long createdByUserId, boolean active,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns the host properties before and after the current host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public HostProperty[] findByUserId_Active_PrevAndNext(
			long hostPropertyId, long createdByUserId, boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Removes all the host properties where createdByUserId = &#63; and active = &#63; from the database.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 */
	public void removeByUserId_Active(long createdByUserId, boolean active);

	/**
	 * Returns the number of host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @return the number of matching host properties
	 */
	public int countByUserId_Active(long createdByUserId, boolean active);

	/**
	 * Returns all the host properties where active = &#63;.
	 *
	 * @param active the active
	 * @return the matching host properties
	 */
	public java.util.List<HostProperty> findByActive(boolean active);

	/**
	 * Returns a range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	public java.util.List<HostProperty> findByActive(
		boolean active, int start, int end);

	/**
	 * Returns an ordered range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	public java.util.List<HostProperty> findByActive(
		boolean active, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns an ordered range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	public java.util.List<HostProperty> findByActive(
		boolean active, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public HostProperty findByActive_First(
			boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the first host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchByActive_First(
		boolean active,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns the last host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public HostProperty findByActive_Last(
			boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the last host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchByActive_Last(
		boolean active,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns the host properties before and after the current host property in the ordered set where active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public HostProperty[] findByActive_PrevAndNext(
			long hostPropertyId, boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Removes all the host properties where active = &#63; from the database.
	 *
	 * @param active the active
	 */
	public void removeByActive(boolean active);

	/**
	 * Returns the number of host properties where active = &#63;.
	 *
	 * @param active the active
	 * @return the number of matching host properties
	 */
	public int countByActive(boolean active);

	/**
	 * Returns all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @return the matching host properties
	 */
	public java.util.List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active);

	/**
	 * Returns a range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	public java.util.List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end);

	/**
	 * Returns an ordered range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	public java.util.List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns an ordered range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	public java.util.List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public HostProperty findBySharedProperty_Active_First(
			boolean sharedProperty, boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the first host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchBySharedProperty_Active_First(
		boolean sharedProperty, boolean active,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns the last host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	public HostProperty findBySharedProperty_Active_Last(
			boolean sharedProperty, boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the last host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	public HostProperty fetchBySharedProperty_Active_Last(
		boolean sharedProperty, boolean active,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns the host properties before and after the current host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public HostProperty[] findBySharedProperty_Active_PrevAndNext(
			long hostPropertyId, boolean sharedProperty, boolean active,
			com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
				orderByComparator)
		throws NoSuchHostPropertyException;

	/**
	 * Removes all the host properties where sharedProperty = &#63; and active = &#63; from the database.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 */
	public void removeBySharedProperty_Active(
		boolean sharedProperty, boolean active);

	/**
	 * Returns the number of host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @return the number of matching host properties
	 */
	public int countBySharedProperty_Active(
		boolean sharedProperty, boolean active);

	/**
	 * Caches the host property in the entity cache if it is enabled.
	 *
	 * @param hostProperty the host property
	 */
	public void cacheResult(HostProperty hostProperty);

	/**
	 * Caches the host properties in the entity cache if it is enabled.
	 *
	 * @param hostProperties the host properties
	 */
	public void cacheResult(java.util.List<HostProperty> hostProperties);

	/**
	 * Creates a new host property with the primary key. Does not add the host property to the database.
	 *
	 * @param hostPropertyId the primary key for the new host property
	 * @return the new host property
	 */
	public HostProperty create(long hostPropertyId);

	/**
	 * Removes the host property with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property that was removed
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public HostProperty remove(long hostPropertyId)
		throws NoSuchHostPropertyException;

	public HostProperty updateImpl(HostProperty hostProperty);

	/**
	 * Returns the host property with the primary key or throws a <code>NoSuchHostPropertyException</code> if it could not be found.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	public HostProperty findByPrimaryKey(long hostPropertyId)
		throws NoSuchHostPropertyException;

	/**
	 * Returns the host property with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property, or <code>null</code> if a host property with the primary key could not be found
	 */
	public HostProperty fetchByPrimaryKey(long hostPropertyId);

	/**
	 * Returns all the host properties.
	 *
	 * @return the host properties
	 */
	public java.util.List<HostProperty> findAll();

	/**
	 * Returns a range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of host properties
	 */
	public java.util.List<HostProperty> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of host properties
	 */
	public java.util.List<HostProperty> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator);

	/**
	 * Returns an ordered range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of host properties
	 */
	public java.util.List<HostProperty> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<HostProperty>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the host properties from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of host properties.
	 *
	 * @return the number of host properties
	 */
	public int countAll();

}