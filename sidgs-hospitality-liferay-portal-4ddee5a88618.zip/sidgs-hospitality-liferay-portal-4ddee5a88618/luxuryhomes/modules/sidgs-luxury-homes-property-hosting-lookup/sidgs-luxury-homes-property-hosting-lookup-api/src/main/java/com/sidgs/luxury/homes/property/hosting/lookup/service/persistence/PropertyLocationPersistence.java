/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyLocationException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the property location service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see PropertyLocationUtil
 * @generated
 */
@ProviderType
public interface PropertyLocationPersistence
	extends BasePersistence<PropertyLocation> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link PropertyLocationUtil} to access the property location persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns the property location where hostPropertyId = &#63; or throws a <code>NoSuchPropertyLocationException</code> if it could not be found.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByHostPropertyId(long hostPropertyId)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the property location where hostPropertyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByHostPropertyId(long hostPropertyId);

	/**
	 * Returns the property location where hostPropertyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param hostPropertyId the host property ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByHostPropertyId(
		long hostPropertyId, boolean useFinderCache);

	/**
	 * Removes the property location where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the property location that was removed
	 */
	public PropertyLocation removeByHostPropertyId(long hostPropertyId)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the number of property locations where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property locations
	 */
	public int countByHostPropertyId(long hostPropertyId);

	/**
	 * Returns all the property locations where locality = &#63;.
	 *
	 * @param locality the locality
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality(String locality);

	/**
	 * Returns a range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality(
		String locality, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality(
		String locality, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality(
		String locality, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_First(
			String locality,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_First(
		String locality,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_Last(
			String locality,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_Last(
		String locality,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByLocality_PrevAndNext(
			long locationId, String locality,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where locality = &#63; from the database.
	 *
	 * @param locality the locality
	 */
	public void removeByLocality(String locality);

	/**
	 * Returns the number of property locations where locality = &#63;.
	 *
	 * @param locality the locality
	 * @return the number of matching property locations
	 */
	public int countByLocality(String locality);

	/**
	 * Returns all the property locations where state = &#63;.
	 *
	 * @param state the state
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByState(String state);

	/**
	 * Returns a range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByState(
		String state, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByState(
		String state, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByState(
		String state, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByState_First(
			String state,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByState_First(
		String state,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByState_Last(
			String state,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByState_Last(
		String state,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where state = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByState_PrevAndNext(
			long locationId, String state,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where state = &#63; from the database.
	 *
	 * @param state the state
	 */
	public void removeByState(String state);

	/**
	 * Returns the number of property locations where state = &#63;.
	 *
	 * @param state the state
	 * @return the number of matching property locations
	 */
	public int countByState(String state);

	/**
	 * Returns all the property locations where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByZipCode(String zipCode);

	/**
	 * Returns a range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByZipCode_First(
			String zipCode,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByZipCode_First(
		String zipCode,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByZipCode_Last(
			String zipCode,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByZipCode_Last(
		String zipCode,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where zipCode = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByZipCode_PrevAndNext(
			long locationId, String zipCode,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where zipCode = &#63; from the database.
	 *
	 * @param zipCode the zip code
	 */
	public void removeByZipCode(String zipCode);

	/**
	 * Returns the number of property locations where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @return the number of matching property locations
	 */
	public int countByZipCode(String zipCode);

	/**
	 * Returns all the property locations where country = &#63;.
	 *
	 * @param country the country
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByCountry(String country);

	/**
	 * Returns a range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByCountry(
		String country, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByCountry(
		String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByCountry(
		String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByCountry_First(
			String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByCountry_First(
		String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByCountry_Last(
			String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByCountry_Last(
		String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByCountry_PrevAndNext(
			long locationId, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where country = &#63; from the database.
	 *
	 * @param country the country
	 */
	public void removeByCountry(String country);

	/**
	 * Returns the number of property locations where country = &#63;.
	 *
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public int countByCountry(String country);

	/**
	 * Returns all the property locations where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State(
		String locality, String state);

	/**
	 * Returns a range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_State_First(
			String locality, String state,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_State_First(
		String locality, String state,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_State_Last(
			String locality, String state,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_State_Last(
		String locality, String state,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByLocality_State_PrevAndNext(
			long locationId, String locality, String state,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where locality = &#63; and state = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param state the state
	 */
	public void removeByLocality_State(String locality, String state);

	/**
	 * Returns the number of property locations where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @return the number of matching property locations
	 */
	public int countByLocality_State(String locality, String state);

	/**
	 * Returns all the property locations where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_Country(
		String locality, String country);

	/**
	 * Returns a range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_Country_First(
			String locality, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_Country_First(
		String locality, String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_Country_Last(
			String locality, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_Country_Last(
		String locality, String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByLocality_Country_PrevAndNext(
			long locationId, String locality, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where locality = &#63; and country = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param country the country
	 */
	public void removeByLocality_Country(String locality, String country);

	/**
	 * Returns the number of property locations where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public int countByLocality_Country(String locality, String country);

	/**
	 * Returns all the property locations where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByState_Country(
		String state, String country);

	/**
	 * Returns a range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByState_Country_First(
			String state, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByState_Country_First(
		String state, String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByState_Country_Last(
			String state, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByState_Country_Last(
		String state, String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByState_Country_PrevAndNext(
			long locationId, String state, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where state = &#63; and country = &#63; from the database.
	 *
	 * @param state the state
	 * @param country the country
	 */
	public void removeByState_Country(String state, String country);

	/**
	 * Returns the number of property locations where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public int countByState_Country(String state, String country);

	/**
	 * Returns all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @return the matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country);

	/**
	 * Returns a range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	public java.util.List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_State_Country_First(
			String locality, String state, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_State_Country_First(
		String locality, String state, String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	public PropertyLocation findByLocality_State_Country_Last(
			String locality, String state, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	public PropertyLocation fetchByLocality_State_Country_Last(
		String locality, String state, String country,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation[] findByLocality_State_Country_PrevAndNext(
			long locationId, String locality, String state, String country,
			com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
				orderByComparator)
		throws NoSuchPropertyLocationException;

	/**
	 * Removes all the property locations where locality = &#63; and state = &#63; and country = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 */
	public void removeByLocality_State_Country(
		String locality, String state, String country);

	/**
	 * Returns the number of property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @return the number of matching property locations
	 */
	public int countByLocality_State_Country(
		String locality, String state, String country);

	/**
	 * Caches the property location in the entity cache if it is enabled.
	 *
	 * @param propertyLocation the property location
	 */
	public void cacheResult(PropertyLocation propertyLocation);

	/**
	 * Caches the property locations in the entity cache if it is enabled.
	 *
	 * @param propertyLocations the property locations
	 */
	public void cacheResult(java.util.List<PropertyLocation> propertyLocations);

	/**
	 * Creates a new property location with the primary key. Does not add the property location to the database.
	 *
	 * @param locationId the primary key for the new property location
	 * @return the new property location
	 */
	public PropertyLocation create(long locationId);

	/**
	 * Removes the property location with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location that was removed
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation remove(long locationId)
		throws NoSuchPropertyLocationException;

	public PropertyLocation updateImpl(PropertyLocation propertyLocation);

	/**
	 * Returns the property location with the primary key or throws a <code>NoSuchPropertyLocationException</code> if it could not be found.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	public PropertyLocation findByPrimaryKey(long locationId)
		throws NoSuchPropertyLocationException;

	/**
	 * Returns the property location with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location, or <code>null</code> if a property location with the primary key could not be found
	 */
	public PropertyLocation fetchByPrimaryKey(long locationId);

	/**
	 * Returns all the property locations.
	 *
	 * @return the property locations
	 */
	public java.util.List<PropertyLocation> findAll();

	/**
	 * Returns a range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of property locations
	 */
	public java.util.List<PropertyLocation> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property locations
	 */
	public java.util.List<PropertyLocation> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator);

	/**
	 * Returns an ordered range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property locations
	 */
	public java.util.List<PropertyLocation> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<PropertyLocation>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the property locations from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of property locations.
	 *
	 * @return the number of property locations
	 */
	public int countAll();

}