/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service;

import com.liferay.portal.kernel.service.ServiceWrapper;
import com.liferay.portal.kernel.service.persistence.BasePersistence;

/**
 * Provides a wrapper for {@link PropertyPricingLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see PropertyPricingLocalService
 * @generated
 */
public class PropertyPricingLocalServiceWrapper
	implements PropertyPricingLocalService,
			   ServiceWrapper<PropertyPricingLocalService> {

	public PropertyPricingLocalServiceWrapper() {
		this(null);
	}

	public PropertyPricingLocalServiceWrapper(
		PropertyPricingLocalService propertyPricingLocalService) {

		_propertyPricingLocalService = propertyPricingLocalService;
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
		addPropertyLocation(
			long hostPropertyId, long floorId, String currency,
			double basePrice) {

		return _propertyPricingLocalService.addPropertyLocation(
			hostPropertyId, floorId, currency, basePrice);
	}

	/**
	 * Adds the property pricing to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyPricingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyPricing the property pricing
	 * @return the property pricing that was added
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
		addPropertyPricing(
			com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
				propertyPricing) {

		return _propertyPricingLocalService.addPropertyPricing(propertyPricing);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyPricingLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Creates a new property pricing with the primary key. Does not add the property pricing to the database.
	 *
	 * @param pricingId the primary key for the new property pricing
	 * @return the new property pricing
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
		createPropertyPricing(long pricingId) {

		return _propertyPricingLocalService.createPropertyPricing(pricingId);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyPricingLocalService.deletePersistedModel(
			persistedModel);
	}

	/**
	 * Deletes the property pricing with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyPricingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing that was removed
	 * @throws PortalException if a property pricing with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
			deletePropertyPricing(long pricingId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyPricingLocalService.deletePropertyPricing(pricingId);
	}

	/**
	 * Deletes the property pricing from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyPricingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyPricing the property pricing
	 * @return the property pricing that was removed
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
		deletePropertyPricing(
			com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
				propertyPricing) {

		return _propertyPricingLocalService.deletePropertyPricing(
			propertyPricing);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _propertyPricingLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _propertyPricingLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _propertyPricingLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _propertyPricingLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _propertyPricingLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _propertyPricingLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _propertyPricingLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _propertyPricingLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
		fetchPropertyPricing(long pricingId) {

		return _propertyPricingLocalService.fetchPropertyPricing(pricingId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _propertyPricingLocalService.getActionableDynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _propertyPricingLocalService.
			getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _propertyPricingLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyPricingLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Returns the property pricing with the primary key.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing
	 * @throws PortalException if a property pricing with the primary key could not be found
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
			getPropertyPricing(long pricingId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _propertyPricingLocalService.getPropertyPricing(pricingId);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing>
			getPropertyPricingByFloorId(double startValue, double endValue) {

		return _propertyPricingLocalService.getPropertyPricingByFloorId(
			startValue, endValue);
	}

	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
			getPropertyPricingByFloorId(long floorId)
		throws com.sidgs.luxury.homes.property.hosting.lookup.exception.
			NoSuchPropertyPricingException {

		return _propertyPricingLocalService.getPropertyPricingByFloorId(
			floorId);
	}

	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing>
			getPropertyPricingByHostPropertyId(long hostPropertyId) {

		return _propertyPricingLocalService.getPropertyPricingByHostPropertyId(
			hostPropertyId);
	}

	/**
	 * Returns a range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of property pricings
	 */
	@Override
	public java.util.List
		<com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing>
			getPropertyPricings(int start, int end) {

		return _propertyPricingLocalService.getPropertyPricings(start, end);
	}

	/**
	 * Returns the number of property pricings.
	 *
	 * @return the number of property pricings
	 */
	@Override
	public int getPropertyPricingsCount() {
		return _propertyPricingLocalService.getPropertyPricingsCount();
	}

	/**
	 * Updates the property pricing in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect PropertyPricingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param propertyPricing the property pricing
	 * @return the property pricing that was updated
	 */
	@Override
	public com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
		updatePropertyPricing(
			com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing
				propertyPricing) {

		return _propertyPricingLocalService.updatePropertyPricing(
			propertyPricing);
	}

	@Override
	public BasePersistence<?> getBasePersistence() {
		return _propertyPricingLocalService.getBasePersistence();
	}

	@Override
	public PropertyPricingLocalService getWrappedService() {
		return _propertyPricingLocalService;
	}

	@Override
	public void setWrappedService(
		PropertyPricingLocalService propertyPricingLocalService) {

		_propertyPricingLocalService = propertyPricingLocalService;
	}

	private PropertyPricingLocalService _propertyPricingLocalService;

}