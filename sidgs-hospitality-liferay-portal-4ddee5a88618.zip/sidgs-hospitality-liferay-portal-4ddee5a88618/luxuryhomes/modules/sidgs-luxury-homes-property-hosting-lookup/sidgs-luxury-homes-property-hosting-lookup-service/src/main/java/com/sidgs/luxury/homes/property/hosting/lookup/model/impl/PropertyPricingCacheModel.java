/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing PropertyPricing in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class PropertyPricingCacheModel
	implements CacheModel<PropertyPricing>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof PropertyPricingCacheModel)) {
			return false;
		}

		PropertyPricingCacheModel propertyPricingCacheModel =
			(PropertyPricingCacheModel)object;

		if (pricingId == propertyPricingCacheModel.pricingId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, pricingId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{pricingId=");
		sb.append(pricingId);
		sb.append(", hostPropertyId=");
		sb.append(hostPropertyId);
		sb.append(", floorId=");
		sb.append(floorId);
		sb.append(", currency=");
		sb.append(currency);
		sb.append(", basePrice=");
		sb.append(basePrice);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public PropertyPricing toEntityModel() {
		PropertyPricingImpl propertyPricingImpl = new PropertyPricingImpl();

		propertyPricingImpl.setPricingId(pricingId);
		propertyPricingImpl.setHostPropertyId(hostPropertyId);
		propertyPricingImpl.setFloorId(floorId);

		if (currency == null) {
			propertyPricingImpl.setCurrency("");
		}
		else {
			propertyPricingImpl.setCurrency(currency);
		}

		propertyPricingImpl.setBasePrice(basePrice);

		propertyPricingImpl.resetOriginalValues();

		return propertyPricingImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		pricingId = objectInput.readLong();

		hostPropertyId = objectInput.readLong();

		floorId = objectInput.readLong();
		currency = objectInput.readUTF();

		basePrice = objectInput.readDouble();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(pricingId);

		objectOutput.writeLong(hostPropertyId);

		objectOutput.writeLong(floorId);

		if (currency == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(currency);
		}

		objectOutput.writeDouble(basePrice);
	}

	public long pricingId;
	public long hostPropertyId;
	public long floorId;
	public String currency;
	public double basePrice;

}