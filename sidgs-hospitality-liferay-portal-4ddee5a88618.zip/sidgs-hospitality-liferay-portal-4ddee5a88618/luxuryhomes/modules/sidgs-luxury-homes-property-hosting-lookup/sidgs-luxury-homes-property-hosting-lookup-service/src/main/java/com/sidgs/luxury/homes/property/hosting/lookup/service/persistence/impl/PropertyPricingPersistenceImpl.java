/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyPricingException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricing;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyPricingTable;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyPricingImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyPricingModelImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.PropertyPricingPersistence;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.PropertyPricingUtil;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.constants.SIDPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the property pricing service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = PropertyPricingPersistence.class)
public class PropertyPricingPersistenceImpl
	extends BasePersistenceImpl<PropertyPricing>
	implements PropertyPricingPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>PropertyPricingUtil</code> to access the property pricing persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		PropertyPricingImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByHostPropertyId;
	private FinderPath _finderPathWithoutPaginationFindByHostPropertyId;
	private FinderPath _finderPathCountByHostPropertyId;

	/**
	 * Returns all the property pricings where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByHostPropertyId(long hostPropertyId) {
		return findByHostPropertyId(
			hostPropertyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end) {

		return findByHostPropertyId(hostPropertyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return findByHostPropertyId(
			hostPropertyId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property pricings where hostPropertyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param hostPropertyId the host property ID
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByHostPropertyId(
		long hostPropertyId, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByHostPropertyId;
				finderArgs = new Object[] {hostPropertyId};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByHostPropertyId;
			finderArgs = new Object[] {
				hostPropertyId, start, end, orderByComparator
			};
		}

		List<PropertyPricing> list = null;

		if (useFinderCache) {
			list = (List<PropertyPricing>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyPricing propertyPricing : list) {
					if (hostPropertyId != propertyPricing.getHostPropertyId()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYPRICING_WHERE);

			sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyPricingModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(hostPropertyId);

				list = (List<PropertyPricing>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing findByHostPropertyId_First(
			long hostPropertyId,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = fetchByHostPropertyId_First(
			hostPropertyId, orderByComparator);

		if (propertyPricing != null) {
			return propertyPricing;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("hostPropertyId=");
		sb.append(hostPropertyId);

		sb.append("}");

		throw new NoSuchPropertyPricingException(sb.toString());
	}

	/**
	 * Returns the first property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing fetchByHostPropertyId_First(
		long hostPropertyId,
		OrderByComparator<PropertyPricing> orderByComparator) {

		List<PropertyPricing> list = findByHostPropertyId(
			hostPropertyId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing findByHostPropertyId_Last(
			long hostPropertyId,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = fetchByHostPropertyId_Last(
			hostPropertyId, orderByComparator);

		if (propertyPricing != null) {
			return propertyPricing;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("hostPropertyId=");
		sb.append(hostPropertyId);

		sb.append("}");

		throw new NoSuchPropertyPricingException(sb.toString());
	}

	/**
	 * Returns the last property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing fetchByHostPropertyId_Last(
		long hostPropertyId,
		OrderByComparator<PropertyPricing> orderByComparator) {

		int count = countByHostPropertyId(hostPropertyId);

		if (count == 0) {
			return null;
		}

		List<PropertyPricing> list = findByHostPropertyId(
			hostPropertyId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property pricings before and after the current property pricing in the ordered set where hostPropertyId = &#63;.
	 *
	 * @param pricingId the primary key of the current property pricing
	 * @param hostPropertyId the host property ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	@Override
	public PropertyPricing[] findByHostPropertyId_PrevAndNext(
			long pricingId, long hostPropertyId,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = findByPrimaryKey(pricingId);

		Session session = null;

		try {
			session = openSession();

			PropertyPricing[] array = new PropertyPricingImpl[3];

			array[0] = getByHostPropertyId_PrevAndNext(
				session, propertyPricing, hostPropertyId, orderByComparator,
				true);

			array[1] = propertyPricing;

			array[2] = getByHostPropertyId_PrevAndNext(
				session, propertyPricing, hostPropertyId, orderByComparator,
				false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyPricing getByHostPropertyId_PrevAndNext(
		Session session, PropertyPricing propertyPricing, long hostPropertyId,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYPRICING_WHERE);

		sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyPricingModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(hostPropertyId);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyPricing)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyPricing> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property pricings where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 */
	@Override
	public void removeByHostPropertyId(long hostPropertyId) {
		for (PropertyPricing propertyPricing :
				findByHostPropertyId(
					hostPropertyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(propertyPricing);
		}
	}

	/**
	 * Returns the number of property pricings where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property pricings
	 */
	@Override
	public int countByHostPropertyId(long hostPropertyId) {
		FinderPath finderPath = _finderPathCountByHostPropertyId;

		Object[] finderArgs = new Object[] {hostPropertyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYPRICING_WHERE);

			sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(hostPropertyId);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2 =
		"propertyPricing.hostPropertyId = ?";

	private FinderPath _finderPathFetchByFloorId;
	private FinderPath _finderPathCountByFloorId;

	/**
	 * Returns the property pricing where floorId = &#63; or throws a <code>NoSuchPropertyPricingException</code> if it could not be found.
	 *
	 * @param floorId the floor ID
	 * @return the matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing findByFloorId(long floorId)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = fetchByFloorId(floorId);

		if (propertyPricing == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("floorId=");
			sb.append(floorId);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchPropertyPricingException(sb.toString());
		}

		return propertyPricing;
	}

	/**
	 * Returns the property pricing where floorId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param floorId the floor ID
	 * @return the matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing fetchByFloorId(long floorId) {
		return fetchByFloorId(floorId, true);
	}

	/**
	 * Returns the property pricing where floorId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param floorId the floor ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing fetchByFloorId(
		long floorId, boolean useFinderCache) {

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {floorId};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchByFloorId, finderArgs, this);
		}

		if (result instanceof PropertyPricing) {
			PropertyPricing propertyPricing = (PropertyPricing)result;

			if (floorId != propertyPricing.getFloorId()) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_PROPERTYPRICING_WHERE);

			sb.append(_FINDER_COLUMN_FLOORID_FLOORID_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(floorId);

				List<PropertyPricing> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchByFloorId, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {floorId};
							}

							_log.warn(
								"PropertyPricingPersistenceImpl.fetchByFloorId(long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					PropertyPricing propertyPricing = list.get(0);

					result = propertyPricing;

					cacheResult(propertyPricing);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (PropertyPricing)result;
		}
	}

	/**
	 * Removes the property pricing where floorId = &#63; from the database.
	 *
	 * @param floorId the floor ID
	 * @return the property pricing that was removed
	 */
	@Override
	public PropertyPricing removeByFloorId(long floorId)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = findByFloorId(floorId);

		return remove(propertyPricing);
	}

	/**
	 * Returns the number of property pricings where floorId = &#63;.
	 *
	 * @param floorId the floor ID
	 * @return the number of matching property pricings
	 */
	@Override
	public int countByFloorId(long floorId) {
		FinderPath finderPath = _finderPathCountByFloorId;

		Object[] finderArgs = new Object[] {floorId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYPRICING_WHERE);

			sb.append(_FINDER_COLUMN_FLOORID_FLOORID_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(floorId);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_FLOORID_FLOORID_2 =
		"propertyPricing.floorId = ?";

	private FinderPath _finderPathWithPaginationFindByBasePrice;
	private FinderPath _finderPathWithoutPaginationFindByBasePrice;
	private FinderPath _finderPathCountByBasePrice;

	/**
	 * Returns all the property pricings where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @return the matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByBasePrice(double basePrice) {
		return findByBasePrice(
			basePrice, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end) {

		return findByBasePrice(basePrice, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return findByBasePrice(basePrice, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property pricings where basePrice = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param basePrice the base price
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property pricings
	 */
	@Override
	public List<PropertyPricing> findByBasePrice(
		double basePrice, int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByBasePrice;
				finderArgs = new Object[] {basePrice};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByBasePrice;
			finderArgs = new Object[] {
				basePrice, start, end, orderByComparator
			};
		}

		List<PropertyPricing> list = null;

		if (useFinderCache) {
			list = (List<PropertyPricing>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyPricing propertyPricing : list) {
					if (basePrice != propertyPricing.getBasePrice()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYPRICING_WHERE);

			sb.append(_FINDER_COLUMN_BASEPRICE_BASEPRICE_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyPricingModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(basePrice);

				list = (List<PropertyPricing>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing findByBasePrice_First(
			double basePrice,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = fetchByBasePrice_First(
			basePrice, orderByComparator);

		if (propertyPricing != null) {
			return propertyPricing;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("basePrice=");
		sb.append(basePrice);

		sb.append("}");

		throw new NoSuchPropertyPricingException(sb.toString());
	}

	/**
	 * Returns the first property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing fetchByBasePrice_First(
		double basePrice,
		OrderByComparator<PropertyPricing> orderByComparator) {

		List<PropertyPricing> list = findByBasePrice(
			basePrice, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing
	 * @throws NoSuchPropertyPricingException if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing findByBasePrice_Last(
			double basePrice,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = fetchByBasePrice_Last(
			basePrice, orderByComparator);

		if (propertyPricing != null) {
			return propertyPricing;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("basePrice=");
		sb.append(basePrice);

		sb.append("}");

		throw new NoSuchPropertyPricingException(sb.toString());
	}

	/**
	 * Returns the last property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property pricing, or <code>null</code> if a matching property pricing could not be found
	 */
	@Override
	public PropertyPricing fetchByBasePrice_Last(
		double basePrice,
		OrderByComparator<PropertyPricing> orderByComparator) {

		int count = countByBasePrice(basePrice);

		if (count == 0) {
			return null;
		}

		List<PropertyPricing> list = findByBasePrice(
			basePrice, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property pricings before and after the current property pricing in the ordered set where basePrice = &#63;.
	 *
	 * @param pricingId the primary key of the current property pricing
	 * @param basePrice the base price
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	@Override
	public PropertyPricing[] findByBasePrice_PrevAndNext(
			long pricingId, double basePrice,
			OrderByComparator<PropertyPricing> orderByComparator)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = findByPrimaryKey(pricingId);

		Session session = null;

		try {
			session = openSession();

			PropertyPricing[] array = new PropertyPricingImpl[3];

			array[0] = getByBasePrice_PrevAndNext(
				session, propertyPricing, basePrice, orderByComparator, true);

			array[1] = propertyPricing;

			array[2] = getByBasePrice_PrevAndNext(
				session, propertyPricing, basePrice, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyPricing getByBasePrice_PrevAndNext(
		Session session, PropertyPricing propertyPricing, double basePrice,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYPRICING_WHERE);

		sb.append(_FINDER_COLUMN_BASEPRICE_BASEPRICE_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyPricingModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(basePrice);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyPricing)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyPricing> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property pricings where basePrice = &#63; from the database.
	 *
	 * @param basePrice the base price
	 */
	@Override
	public void removeByBasePrice(double basePrice) {
		for (PropertyPricing propertyPricing :
				findByBasePrice(
					basePrice, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyPricing);
		}
	}

	/**
	 * Returns the number of property pricings where basePrice = &#63;.
	 *
	 * @param basePrice the base price
	 * @return the number of matching property pricings
	 */
	@Override
	public int countByBasePrice(double basePrice) {
		FinderPath finderPath = _finderPathCountByBasePrice;

		Object[] finderArgs = new Object[] {basePrice};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYPRICING_WHERE);

			sb.append(_FINDER_COLUMN_BASEPRICE_BASEPRICE_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(basePrice);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_BASEPRICE_BASEPRICE_2 =
		"propertyPricing.basePrice = ?";

	public PropertyPricingPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("currency", "currency_");

		setDBColumnNames(dbColumnNames);

		setModelClass(PropertyPricing.class);

		setModelImplClass(PropertyPricingImpl.class);
		setModelPKClass(long.class);

		setTable(PropertyPricingTable.INSTANCE);
	}

	/**
	 * Caches the property pricing in the entity cache if it is enabled.
	 *
	 * @param propertyPricing the property pricing
	 */
	@Override
	public void cacheResult(PropertyPricing propertyPricing) {
		entityCache.putResult(
			PropertyPricingImpl.class, propertyPricing.getPrimaryKey(),
			propertyPricing);

		finderCache.putResult(
			_finderPathFetchByFloorId,
			new Object[] {propertyPricing.getFloorId()}, propertyPricing);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the property pricings in the entity cache if it is enabled.
	 *
	 * @param propertyPricings the property pricings
	 */
	@Override
	public void cacheResult(List<PropertyPricing> propertyPricings) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (propertyPricings.size() >
				 _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (PropertyPricing propertyPricing : propertyPricings) {
			if (entityCache.getResult(
					PropertyPricingImpl.class,
					propertyPricing.getPrimaryKey()) == null) {

				cacheResult(propertyPricing);
			}
		}
	}

	/**
	 * Clears the cache for all property pricings.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(PropertyPricingImpl.class);

		finderCache.clearCache(PropertyPricingImpl.class);
	}

	/**
	 * Clears the cache for the property pricing.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(PropertyPricing propertyPricing) {
		entityCache.removeResult(PropertyPricingImpl.class, propertyPricing);
	}

	@Override
	public void clearCache(List<PropertyPricing> propertyPricings) {
		for (PropertyPricing propertyPricing : propertyPricings) {
			entityCache.removeResult(
				PropertyPricingImpl.class, propertyPricing);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(PropertyPricingImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(PropertyPricingImpl.class, primaryKey);
		}
	}

	protected void cacheUniqueFindersCache(
		PropertyPricingModelImpl propertyPricingModelImpl) {

		Object[] args = new Object[] {propertyPricingModelImpl.getFloorId()};

		finderCache.putResult(_finderPathCountByFloorId, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchByFloorId, args, propertyPricingModelImpl);
	}

	/**
	 * Creates a new property pricing with the primary key. Does not add the property pricing to the database.
	 *
	 * @param pricingId the primary key for the new property pricing
	 * @return the new property pricing
	 */
	@Override
	public PropertyPricing create(long pricingId) {
		PropertyPricing propertyPricing = new PropertyPricingImpl();

		propertyPricing.setNew(true);
		propertyPricing.setPrimaryKey(pricingId);

		return propertyPricing;
	}

	/**
	 * Removes the property pricing with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing that was removed
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	@Override
	public PropertyPricing remove(long pricingId)
		throws NoSuchPropertyPricingException {

		return remove((Serializable)pricingId);
	}

	/**
	 * Removes the property pricing with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the property pricing
	 * @return the property pricing that was removed
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	@Override
	public PropertyPricing remove(Serializable primaryKey)
		throws NoSuchPropertyPricingException {

		Session session = null;

		try {
			session = openSession();

			PropertyPricing propertyPricing = (PropertyPricing)session.get(
				PropertyPricingImpl.class, primaryKey);

			if (propertyPricing == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchPropertyPricingException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(propertyPricing);
		}
		catch (NoSuchPropertyPricingException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected PropertyPricing removeImpl(PropertyPricing propertyPricing) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(propertyPricing)) {
				propertyPricing = (PropertyPricing)session.get(
					PropertyPricingImpl.class,
					propertyPricing.getPrimaryKeyObj());
			}

			if (propertyPricing != null) {
				session.delete(propertyPricing);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (propertyPricing != null) {
			clearCache(propertyPricing);
		}

		return propertyPricing;
	}

	@Override
	public PropertyPricing updateImpl(PropertyPricing propertyPricing) {
		boolean isNew = propertyPricing.isNew();

		if (!(propertyPricing instanceof PropertyPricingModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(propertyPricing.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					propertyPricing);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in propertyPricing proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom PropertyPricing implementation " +
					propertyPricing.getClass());
		}

		PropertyPricingModelImpl propertyPricingModelImpl =
			(PropertyPricingModelImpl)propertyPricing;

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(propertyPricing);
			}
			else {
				propertyPricing = (PropertyPricing)session.merge(
					propertyPricing);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			PropertyPricingImpl.class, propertyPricingModelImpl, false, true);

		cacheUniqueFindersCache(propertyPricingModelImpl);

		if (isNew) {
			propertyPricing.setNew(false);
		}

		propertyPricing.resetOriginalValues();

		return propertyPricing;
	}

	/**
	 * Returns the property pricing with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the property pricing
	 * @return the property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	@Override
	public PropertyPricing findByPrimaryKey(Serializable primaryKey)
		throws NoSuchPropertyPricingException {

		PropertyPricing propertyPricing = fetchByPrimaryKey(primaryKey);

		if (propertyPricing == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchPropertyPricingException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return propertyPricing;
	}

	/**
	 * Returns the property pricing with the primary key or throws a <code>NoSuchPropertyPricingException</code> if it could not be found.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing
	 * @throws NoSuchPropertyPricingException if a property pricing with the primary key could not be found
	 */
	@Override
	public PropertyPricing findByPrimaryKey(long pricingId)
		throws NoSuchPropertyPricingException {

		return findByPrimaryKey((Serializable)pricingId);
	}

	/**
	 * Returns the property pricing with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param pricingId the primary key of the property pricing
	 * @return the property pricing, or <code>null</code> if a property pricing with the primary key could not be found
	 */
	@Override
	public PropertyPricing fetchByPrimaryKey(long pricingId) {
		return fetchByPrimaryKey((Serializable)pricingId);
	}

	/**
	 * Returns all the property pricings.
	 *
	 * @return the property pricings
	 */
	@Override
	public List<PropertyPricing> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @return the range of property pricings
	 */
	@Override
	public List<PropertyPricing> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property pricings
	 */
	@Override
	public List<PropertyPricing> findAll(
		int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property pricings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyPricingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property pricings
	 * @param end the upper bound of the range of property pricings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property pricings
	 */
	@Override
	public List<PropertyPricing> findAll(
		int start, int end,
		OrderByComparator<PropertyPricing> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<PropertyPricing> list = null;

		if (useFinderCache) {
			list = (List<PropertyPricing>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_PROPERTYPRICING);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_PROPERTYPRICING;

				sql = sql.concat(PropertyPricingModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<PropertyPricing>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the property pricings from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (PropertyPricing propertyPricing : findAll()) {
			remove(propertyPricing);
		}
	}

	/**
	 * Returns the number of property pricings.
	 *
	 * @return the number of property pricings
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_PROPERTYPRICING);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "pricingId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_PROPERTYPRICING;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return PropertyPricingModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the property pricing persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathWithPaginationFindByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByHostPropertyId",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"hostPropertyId"}, true);

		_finderPathWithoutPaginationFindByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByHostPropertyId",
			new String[] {Long.class.getName()},
			new String[] {"hostPropertyId"}, true);

		_finderPathCountByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByHostPropertyId",
			new String[] {Long.class.getName()},
			new String[] {"hostPropertyId"}, false);

		_finderPathFetchByFloorId = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchByFloorId",
			new String[] {Long.class.getName()}, new String[] {"floorId"},
			true);

		_finderPathCountByFloorId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByFloorId",
			new String[] {Long.class.getName()}, new String[] {"floorId"},
			false);

		_finderPathWithPaginationFindByBasePrice = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByBasePrice",
			new String[] {
				Double.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"basePrice"}, true);

		_finderPathWithoutPaginationFindByBasePrice = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByBasePrice",
			new String[] {Double.class.getName()}, new String[] {"basePrice"},
			true);

		_finderPathCountByBasePrice = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByBasePrice",
			new String[] {Double.class.getName()}, new String[] {"basePrice"},
			false);

		PropertyPricingUtil.setPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		PropertyPricingUtil.setPersistence(null);

		entityCache.removeCache(PropertyPricingImpl.class.getName());
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_PROPERTYPRICING =
		"SELECT propertyPricing FROM PropertyPricing propertyPricing";

	private static final String _SQL_SELECT_PROPERTYPRICING_WHERE =
		"SELECT propertyPricing FROM PropertyPricing propertyPricing WHERE ";

	private static final String _SQL_COUNT_PROPERTYPRICING =
		"SELECT COUNT(propertyPricing) FROM PropertyPricing propertyPricing";

	private static final String _SQL_COUNT_PROPERTYPRICING_WHERE =
		"SELECT COUNT(propertyPricing) FROM PropertyPricing propertyPricing WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "propertyPricing.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No PropertyPricing exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No PropertyPricing exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		PropertyPricingPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"currency"});

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

}