/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchPropertyLocationException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocationTable;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.PropertyLocationModelImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.PropertyLocationPersistence;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.PropertyLocationUtil;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.constants.SIDPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the property location service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = PropertyLocationPersistence.class)
public class PropertyLocationPersistenceImpl
	extends BasePersistenceImpl<PropertyLocation>
	implements PropertyLocationPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>PropertyLocationUtil</code> to access the property location persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		PropertyLocationImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathFetchByHostPropertyId;
	private FinderPath _finderPathCountByHostPropertyId;

	/**
	 * Returns the property location where hostPropertyId = &#63; or throws a <code>NoSuchPropertyLocationException</code> if it could not be found.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByHostPropertyId(long hostPropertyId)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByHostPropertyId(
			hostPropertyId);

		if (propertyLocation == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("hostPropertyId=");
			sb.append(hostPropertyId);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchPropertyLocationException(sb.toString());
		}

		return propertyLocation;
	}

	/**
	 * Returns the property location where hostPropertyId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByHostPropertyId(long hostPropertyId) {
		return fetchByHostPropertyId(hostPropertyId, true);
	}

	/**
	 * Returns the property location where hostPropertyId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param hostPropertyId the host property ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByHostPropertyId(
		long hostPropertyId, boolean useFinderCache) {

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {hostPropertyId};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchByHostPropertyId, finderArgs, this);
		}

		if (result instanceof PropertyLocation) {
			PropertyLocation propertyLocation = (PropertyLocation)result;

			if (hostPropertyId != propertyLocation.getHostPropertyId()) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(hostPropertyId);

				List<PropertyLocation> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchByHostPropertyId, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {hostPropertyId};
							}

							_log.warn(
								"PropertyLocationPersistenceImpl.fetchByHostPropertyId(long, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					PropertyLocation propertyLocation = list.get(0);

					result = propertyLocation;

					cacheResult(propertyLocation);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (PropertyLocation)result;
		}
	}

	/**
	 * Removes the property location where hostPropertyId = &#63; from the database.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the property location that was removed
	 */
	@Override
	public PropertyLocation removeByHostPropertyId(long hostPropertyId)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = findByHostPropertyId(
			hostPropertyId);

		return remove(propertyLocation);
	}

	/**
	 * Returns the number of property locations where hostPropertyId = &#63;.
	 *
	 * @param hostPropertyId the host property ID
	 * @return the number of matching property locations
	 */
	@Override
	public int countByHostPropertyId(long hostPropertyId) {
		FinderPath finderPath = _finderPathCountByHostPropertyId;

		Object[] finderArgs = new Object[] {hostPropertyId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			sb.append(_FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(hostPropertyId);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_HOSTPROPERTYID_HOSTPROPERTYID_2 =
		"propertyLocation.hostPropertyId = ?";

	private FinderPath _finderPathWithPaginationFindByLocality;
	private FinderPath _finderPathWithoutPaginationFindByLocality;
	private FinderPath _finderPathCountByLocality;

	/**
	 * Returns all the property locations where locality = &#63;.
	 *
	 * @param locality the locality
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality(String locality) {
		return findByLocality(
			locality, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality(
		String locality, int start, int end) {

		return findByLocality(locality, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality(
		String locality, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByLocality(locality, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality(
		String locality, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		locality = Objects.toString(locality, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByLocality;
				finderArgs = new Object[] {locality};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByLocality;
			finderArgs = new Object[] {locality, start, end, orderByComparator};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!locality.equals(propertyLocation.getLocality())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_LOCALITY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_First(
			String locality,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_First(
			locality, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_First(
		String locality,
		OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByLocality(
			locality, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_Last(
			String locality,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_Last(
			locality, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63;.
	 *
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_Last(
		String locality,
		OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByLocality(locality);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByLocality(
			locality, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByLocality_PrevAndNext(
			long locationId, String locality,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		locality = Objects.toString(locality, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByLocality_PrevAndNext(
				session, propertyLocation, locality, orderByComparator, true);

			array[1] = propertyLocation;

			array[2] = getByLocality_PrevAndNext(
				session, propertyLocation, locality, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByLocality_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String locality,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindLocality = false;

		if (locality.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_LOCALITY_3);
		}
		else {
			bindLocality = true;

			sb.append(_FINDER_COLUMN_LOCALITY_LOCALITY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindLocality) {
			queryPos.add(locality);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where locality = &#63; from the database.
	 *
	 * @param locality the locality
	 */
	@Override
	public void removeByLocality(String locality) {
		for (PropertyLocation propertyLocation :
				findByLocality(
					locality, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where locality = &#63;.
	 *
	 * @param locality the locality
	 * @return the number of matching property locations
	 */
	@Override
	public int countByLocality(String locality) {
		locality = Objects.toString(locality, "");

		FinderPath finderPath = _finderPathCountByLocality;

		Object[] finderArgs = new Object[] {locality};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_LOCALITY_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_LOCALITY_LOCALITY_2 =
		"propertyLocation.locality = ?";

	private static final String _FINDER_COLUMN_LOCALITY_LOCALITY_3 =
		"(propertyLocation.locality IS NULL OR propertyLocation.locality = '')";

	private FinderPath _finderPathWithPaginationFindByState;
	private FinderPath _finderPathWithoutPaginationFindByState;
	private FinderPath _finderPathCountByState;

	/**
	 * Returns all the property locations where state = &#63;.
	 *
	 * @param state the state
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState(String state) {
		return findByState(state, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState(
		String state, int start, int end) {

		return findByState(state, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState(
		String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByState(state, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState(
		String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		state = Objects.toString(state, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByState;
				finderArgs = new Object[] {state};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByState;
			finderArgs = new Object[] {state, start, end, orderByComparator};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!state.equals(propertyLocation.getState())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_STATE_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_STATE_STATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindState) {
					queryPos.add(state);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByState_First(
			String state, OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByState_First(
			state, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("state=");
		sb.append(state);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByState_First(
		String state, OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByState(
			state, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByState_Last(
			String state, OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByState_Last(
			state, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("state=");
		sb.append(state);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63;.
	 *
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByState_Last(
		String state, OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByState(state);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByState(
			state, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where state = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByState_PrevAndNext(
			long locationId, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		state = Objects.toString(state, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByState_PrevAndNext(
				session, propertyLocation, state, orderByComparator, true);

			array[1] = propertyLocation;

			array[2] = getByState_PrevAndNext(
				session, propertyLocation, state, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByState_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String state,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindState = false;

		if (state.isEmpty()) {
			sb.append(_FINDER_COLUMN_STATE_STATE_3);
		}
		else {
			bindState = true;

			sb.append(_FINDER_COLUMN_STATE_STATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindState) {
			queryPos.add(state);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where state = &#63; from the database.
	 *
	 * @param state the state
	 */
	@Override
	public void removeByState(String state) {
		for (PropertyLocation propertyLocation :
				findByState(
					state, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where state = &#63;.
	 *
	 * @param state the state
	 * @return the number of matching property locations
	 */
	@Override
	public int countByState(String state) {
		state = Objects.toString(state, "");

		FinderPath finderPath = _finderPathCountByState;

		Object[] finderArgs = new Object[] {state};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_STATE_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_STATE_STATE_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindState) {
					queryPos.add(state);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATE_STATE_2 =
		"propertyLocation.state = ?";

	private static final String _FINDER_COLUMN_STATE_STATE_3 =
		"(propertyLocation.state IS NULL OR propertyLocation.state = '')";

	private FinderPath _finderPathWithPaginationFindByZipCode;
	private FinderPath _finderPathWithoutPaginationFindByZipCode;
	private FinderPath _finderPathCountByZipCode;

	/**
	 * Returns all the property locations where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByZipCode(String zipCode) {
		return findByZipCode(
			zipCode, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end) {

		return findByZipCode(zipCode, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByZipCode(zipCode, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where zipCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param zipCode the zip code
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByZipCode(
		String zipCode, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		zipCode = Objects.toString(zipCode, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByZipCode;
				finderArgs = new Object[] {zipCode};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByZipCode;
			finderArgs = new Object[] {zipCode, start, end, orderByComparator};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!zipCode.equals(propertyLocation.getZipCode())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindZipCode = false;

			if (zipCode.isEmpty()) {
				sb.append(_FINDER_COLUMN_ZIPCODE_ZIPCODE_3);
			}
			else {
				bindZipCode = true;

				sb.append(_FINDER_COLUMN_ZIPCODE_ZIPCODE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindZipCode) {
					queryPos.add(zipCode);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByZipCode_First(
			String zipCode,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByZipCode_First(
			zipCode, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("zipCode=");
		sb.append(zipCode);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByZipCode_First(
		String zipCode, OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByZipCode(
			zipCode, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByZipCode_Last(
			String zipCode,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByZipCode_Last(
			zipCode, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("zipCode=");
		sb.append(zipCode);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByZipCode_Last(
		String zipCode, OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByZipCode(zipCode);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByZipCode(
			zipCode, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where zipCode = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param zipCode the zip code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByZipCode_PrevAndNext(
			long locationId, String zipCode,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		zipCode = Objects.toString(zipCode, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByZipCode_PrevAndNext(
				session, propertyLocation, zipCode, orderByComparator, true);

			array[1] = propertyLocation;

			array[2] = getByZipCode_PrevAndNext(
				session, propertyLocation, zipCode, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByZipCode_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String zipCode,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindZipCode = false;

		if (zipCode.isEmpty()) {
			sb.append(_FINDER_COLUMN_ZIPCODE_ZIPCODE_3);
		}
		else {
			bindZipCode = true;

			sb.append(_FINDER_COLUMN_ZIPCODE_ZIPCODE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindZipCode) {
			queryPos.add(zipCode);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where zipCode = &#63; from the database.
	 *
	 * @param zipCode the zip code
	 */
	@Override
	public void removeByZipCode(String zipCode) {
		for (PropertyLocation propertyLocation :
				findByZipCode(
					zipCode, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where zipCode = &#63;.
	 *
	 * @param zipCode the zip code
	 * @return the number of matching property locations
	 */
	@Override
	public int countByZipCode(String zipCode) {
		zipCode = Objects.toString(zipCode, "");

		FinderPath finderPath = _finderPathCountByZipCode;

		Object[] finderArgs = new Object[] {zipCode};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindZipCode = false;

			if (zipCode.isEmpty()) {
				sb.append(_FINDER_COLUMN_ZIPCODE_ZIPCODE_3);
			}
			else {
				bindZipCode = true;

				sb.append(_FINDER_COLUMN_ZIPCODE_ZIPCODE_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindZipCode) {
					queryPos.add(zipCode);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ZIPCODE_ZIPCODE_2 =
		"propertyLocation.zipCode = ?";

	private static final String _FINDER_COLUMN_ZIPCODE_ZIPCODE_3 =
		"(propertyLocation.zipCode IS NULL OR propertyLocation.zipCode = '')";

	private FinderPath _finderPathWithPaginationFindByCountry;
	private FinderPath _finderPathWithoutPaginationFindByCountry;
	private FinderPath _finderPathCountByCountry;

	/**
	 * Returns all the property locations where country = &#63;.
	 *
	 * @param country the country
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByCountry(String country) {
		return findByCountry(
			country, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByCountry(
		String country, int start, int end) {

		return findByCountry(country, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByCountry(
		String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByCountry(country, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByCountry(
		String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		country = Objects.toString(country, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByCountry;
				finderArgs = new Object[] {country};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByCountry;
			finderArgs = new Object[] {country, start, end, orderByComparator};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!country.equals(propertyLocation.getCountry())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCountry) {
					queryPos.add(country);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByCountry_First(
			String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByCountry_First(
			country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByCountry_First(
		String country, OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByCountry(
			country, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByCountry_Last(
			String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByCountry_Last(
			country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where country = &#63;.
	 *
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByCountry_Last(
		String country, OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByCountry(country);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByCountry(
			country, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByCountry_PrevAndNext(
			long locationId, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		country = Objects.toString(country, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByCountry_PrevAndNext(
				session, propertyLocation, country, orderByComparator, true);

			array[1] = propertyLocation;

			array[2] = getByCountry_PrevAndNext(
				session, propertyLocation, country, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByCountry_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String country,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindCountry = false;

		if (country.isEmpty()) {
			sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_3);
		}
		else {
			bindCountry = true;

			sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindCountry) {
			queryPos.add(country);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where country = &#63; from the database.
	 *
	 * @param country the country
	 */
	@Override
	public void removeByCountry(String country) {
		for (PropertyLocation propertyLocation :
				findByCountry(
					country, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where country = &#63;.
	 *
	 * @param country the country
	 * @return the number of matching property locations
	 */
	@Override
	public int countByCountry(String country) {
		country = Objects.toString(country, "");

		FinderPath finderPath = _finderPathCountByCountry;

		Object[] finderArgs = new Object[] {country};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_COUNTRY_COUNTRY_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCountry) {
					queryPos.add(country);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COUNTRY_COUNTRY_2 =
		"propertyLocation.country = ?";

	private static final String _FINDER_COLUMN_COUNTRY_COUNTRY_3 =
		"(propertyLocation.country IS NULL OR propertyLocation.country = '')";

	private FinderPath _finderPathWithPaginationFindByLocality_State;
	private FinderPath _finderPathWithoutPaginationFindByLocality_State;
	private FinderPath _finderPathCountByLocality_State;

	/**
	 * Returns all the property locations where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State(
		String locality, String state) {

		return findByLocality_State(
			locality, state, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end) {

		return findByLocality_State(locality, state, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByLocality_State(
			locality, state, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State(
		String locality, String state, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		locality = Objects.toString(locality, "");
		state = Objects.toString(state, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByLocality_State;
				finderArgs = new Object[] {locality, state};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByLocality_State;
			finderArgs = new Object[] {
				locality, state, start, end, orderByComparator
			};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!locality.equals(propertyLocation.getLocality()) ||
						!state.equals(propertyLocation.getState())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(4);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_LOCALITY_2);
			}

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_STATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				if (bindState) {
					queryPos.add(state);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_State_First(
			String locality, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_State_First(
			locality, state, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append(", state=");
		sb.append(state);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_State_First(
		String locality, String state,
		OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByLocality_State(
			locality, state, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_State_Last(
			String locality, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_State_Last(
			locality, state, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append(", state=");
		sb.append(state);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_State_Last(
		String locality, String state,
		OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByLocality_State(locality, state);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByLocality_State(
			locality, state, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and state = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param state the state
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByLocality_State_PrevAndNext(
			long locationId, String locality, String state,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		locality = Objects.toString(locality, "");
		state = Objects.toString(state, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByLocality_State_PrevAndNext(
				session, propertyLocation, locality, state, orderByComparator,
				true);

			array[1] = propertyLocation;

			array[2] = getByLocality_State_PrevAndNext(
				session, propertyLocation, locality, state, orderByComparator,
				false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByLocality_State_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String locality,
		String state, OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(4);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindLocality = false;

		if (locality.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_STATE_LOCALITY_3);
		}
		else {
			bindLocality = true;

			sb.append(_FINDER_COLUMN_LOCALITY_STATE_LOCALITY_2);
		}

		boolean bindState = false;

		if (state.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_STATE_STATE_3);
		}
		else {
			bindState = true;

			sb.append(_FINDER_COLUMN_LOCALITY_STATE_STATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindLocality) {
			queryPos.add(locality);
		}

		if (bindState) {
			queryPos.add(state);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where locality = &#63; and state = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param state the state
	 */
	@Override
	public void removeByLocality_State(String locality, String state) {
		for (PropertyLocation propertyLocation :
				findByLocality_State(
					locality, state, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where locality = &#63; and state = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @return the number of matching property locations
	 */
	@Override
	public int countByLocality_State(String locality, String state) {
		locality = Objects.toString(locality, "");
		state = Objects.toString(state, "");

		FinderPath finderPath = _finderPathCountByLocality_State;

		Object[] finderArgs = new Object[] {locality, state};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_LOCALITY_2);
			}

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_STATE_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				if (bindState) {
					queryPos.add(state);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_LOCALITY_STATE_LOCALITY_2 =
		"propertyLocation.locality = ? AND ";

	private static final String _FINDER_COLUMN_LOCALITY_STATE_LOCALITY_3 =
		"(propertyLocation.locality IS NULL OR propertyLocation.locality = '') AND ";

	private static final String _FINDER_COLUMN_LOCALITY_STATE_STATE_2 =
		"propertyLocation.state = ?";

	private static final String _FINDER_COLUMN_LOCALITY_STATE_STATE_3 =
		"(propertyLocation.state IS NULL OR propertyLocation.state = '')";

	private FinderPath _finderPathWithPaginationFindByLocality_Country;
	private FinderPath _finderPathWithoutPaginationFindByLocality_Country;
	private FinderPath _finderPathCountByLocality_Country;

	/**
	 * Returns all the property locations where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_Country(
		String locality, String country) {

		return findByLocality_Country(
			locality, country, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end) {

		return findByLocality_Country(locality, country, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByLocality_Country(
			locality, country, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_Country(
		String locality, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		locality = Objects.toString(locality, "");
		country = Objects.toString(country, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByLocality_Country;
				finderArgs = new Object[] {locality, country};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByLocality_Country;
			finderArgs = new Object[] {
				locality, country, start, end, orderByComparator
			};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!locality.equals(propertyLocation.getLocality()) ||
						!country.equals(propertyLocation.getCountry())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(4);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_2);
			}

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				if (bindCountry) {
					queryPos.add(country);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_Country_First(
			String locality, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_Country_First(
			locality, country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append(", country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_Country_First(
		String locality, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByLocality_Country(
			locality, country, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_Country_Last(
			String locality, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_Country_Last(
			locality, country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append(", country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_Country_Last(
		String locality, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByLocality_Country(locality, country);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByLocality_Country(
			locality, country, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByLocality_Country_PrevAndNext(
			long locationId, String locality, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		locality = Objects.toString(locality, "");
		country = Objects.toString(country, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByLocality_Country_PrevAndNext(
				session, propertyLocation, locality, country, orderByComparator,
				true);

			array[1] = propertyLocation;

			array[2] = getByLocality_Country_PrevAndNext(
				session, propertyLocation, locality, country, orderByComparator,
				false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByLocality_Country_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String locality,
		String country, OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(4);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindLocality = false;

		if (locality.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_3);
		}
		else {
			bindLocality = true;

			sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_2);
		}

		boolean bindCountry = false;

		if (country.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_3);
		}
		else {
			bindCountry = true;

			sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindLocality) {
			queryPos.add(locality);
		}

		if (bindCountry) {
			queryPos.add(country);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where locality = &#63; and country = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param country the country
	 */
	@Override
	public void removeByLocality_Country(String locality, String country) {
		for (PropertyLocation propertyLocation :
				findByLocality_Country(
					locality, country, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where locality = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param country the country
	 * @return the number of matching property locations
	 */
	@Override
	public int countByLocality_Country(String locality, String country) {
		locality = Objects.toString(locality, "");
		country = Objects.toString(country, "");

		FinderPath finderPath = _finderPathCountByLocality_Country;

		Object[] finderArgs = new Object[] {locality, country};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_2);
			}

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				if (bindCountry) {
					queryPos.add(country);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_2 =
		"propertyLocation.locality = ? AND ";

	private static final String _FINDER_COLUMN_LOCALITY_COUNTRY_LOCALITY_3 =
		"(propertyLocation.locality IS NULL OR propertyLocation.locality = '') AND ";

	private static final String _FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_2 =
		"propertyLocation.country = ?";

	private static final String _FINDER_COLUMN_LOCALITY_COUNTRY_COUNTRY_3 =
		"(propertyLocation.country IS NULL OR propertyLocation.country = '')";

	private FinderPath _finderPathWithPaginationFindByState_Country;
	private FinderPath _finderPathWithoutPaginationFindByState_Country;
	private FinderPath _finderPathCountByState_Country;

	/**
	 * Returns all the property locations where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState_Country(
		String state, String country) {

		return findByState_Country(
			state, country, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end) {

		return findByState_Country(state, country, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByState_Country(
			state, country, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByState_Country(
		String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		state = Objects.toString(state, "");
		country = Objects.toString(country, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByState_Country;
				finderArgs = new Object[] {state, country};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByState_Country;
			finderArgs = new Object[] {
				state, country, start, end, orderByComparator
			};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!state.equals(propertyLocation.getState()) ||
						!country.equals(propertyLocation.getCountry())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(4);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_STATE_COUNTRY_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_STATE_COUNTRY_STATE_2);
			}

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_STATE_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_STATE_COUNTRY_COUNTRY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindState) {
					queryPos.add(state);
				}

				if (bindCountry) {
					queryPos.add(country);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByState_Country_First(
			String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByState_Country_First(
			state, country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("state=");
		sb.append(state);

		sb.append(", country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByState_Country_First(
		String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByState_Country(
			state, country, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByState_Country_Last(
			String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByState_Country_Last(
			state, country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("state=");
		sb.append(state);

		sb.append(", country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByState_Country_Last(
		String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByState_Country(state, country);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByState_Country(
			state, country, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where state = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByState_Country_PrevAndNext(
			long locationId, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		state = Objects.toString(state, "");
		country = Objects.toString(country, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByState_Country_PrevAndNext(
				session, propertyLocation, state, country, orderByComparator,
				true);

			array[1] = propertyLocation;

			array[2] = getByState_Country_PrevAndNext(
				session, propertyLocation, state, country, orderByComparator,
				false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByState_Country_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String state,
		String country, OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(4);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindState = false;

		if (state.isEmpty()) {
			sb.append(_FINDER_COLUMN_STATE_COUNTRY_STATE_3);
		}
		else {
			bindState = true;

			sb.append(_FINDER_COLUMN_STATE_COUNTRY_STATE_2);
		}

		boolean bindCountry = false;

		if (country.isEmpty()) {
			sb.append(_FINDER_COLUMN_STATE_COUNTRY_COUNTRY_3);
		}
		else {
			bindCountry = true;

			sb.append(_FINDER_COLUMN_STATE_COUNTRY_COUNTRY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindState) {
			queryPos.add(state);
		}

		if (bindCountry) {
			queryPos.add(country);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where state = &#63; and country = &#63; from the database.
	 *
	 * @param state the state
	 * @param country the country
	 */
	@Override
	public void removeByState_Country(String state, String country) {
		for (PropertyLocation propertyLocation :
				findByState_Country(
					state, country, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
					null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where state = &#63; and country = &#63;.
	 *
	 * @param state the state
	 * @param country the country
	 * @return the number of matching property locations
	 */
	@Override
	public int countByState_Country(String state, String country) {
		state = Objects.toString(state, "");
		country = Objects.toString(country, "");

		FinderPath finderPath = _finderPathCountByState_Country;

		Object[] finderArgs = new Object[] {state, country};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_STATE_COUNTRY_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_STATE_COUNTRY_STATE_2);
			}

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_STATE_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_STATE_COUNTRY_COUNTRY_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindState) {
					queryPos.add(state);
				}

				if (bindCountry) {
					queryPos.add(country);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATE_COUNTRY_STATE_2 =
		"propertyLocation.state = ? AND ";

	private static final String _FINDER_COLUMN_STATE_COUNTRY_STATE_3 =
		"(propertyLocation.state IS NULL OR propertyLocation.state = '') AND ";

	private static final String _FINDER_COLUMN_STATE_COUNTRY_COUNTRY_2 =
		"propertyLocation.country = ?";

	private static final String _FINDER_COLUMN_STATE_COUNTRY_COUNTRY_3 =
		"(propertyLocation.country IS NULL OR propertyLocation.country = '')";

	private FinderPath _finderPathWithPaginationFindByLocality_State_Country;
	private FinderPath _finderPathWithoutPaginationFindByLocality_State_Country;
	private FinderPath _finderPathCountByLocality_State_Country;

	/**
	 * Returns all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @return the matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country) {

		return findByLocality_State_Country(
			locality, state, country, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end) {

		return findByLocality_State_Country(
			locality, state, country, start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findByLocality_State_Country(
			locality, state, country, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching property locations
	 */
	@Override
	public List<PropertyLocation> findByLocality_State_Country(
		String locality, String state, String country, int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		locality = Objects.toString(locality, "");
		state = Objects.toString(state, "");
		country = Objects.toString(country, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath =
					_finderPathWithoutPaginationFindByLocality_State_Country;
				finderArgs = new Object[] {locality, state, country};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByLocality_State_Country;
			finderArgs = new Object[] {
				locality, state, country, start, end, orderByComparator
			};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (PropertyLocation propertyLocation : list) {
					if (!locality.equals(propertyLocation.getLocality()) ||
						!state.equals(propertyLocation.getState()) ||
						!country.equals(propertyLocation.getCountry())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					5 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(5);
			}

			sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_2);
			}

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_2);
			}

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				if (bindState) {
					queryPos.add(state);
				}

				if (bindCountry) {
					queryPos.add(country);
				}

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_State_Country_First(
			String locality, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_State_Country_First(
			locality, state, country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(8);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append(", state=");
		sb.append(state);

		sb.append(", country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the first property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_State_Country_First(
		String locality, String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		List<PropertyLocation> list = findByLocality_State_Country(
			locality, state, country, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location
	 * @throws NoSuchPropertyLocationException if a matching property location could not be found
	 */
	@Override
	public PropertyLocation findByLocality_State_Country_Last(
			String locality, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByLocality_State_Country_Last(
			locality, state, country, orderByComparator);

		if (propertyLocation != null) {
			return propertyLocation;
		}

		StringBundler sb = new StringBundler(8);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("locality=");
		sb.append(locality);

		sb.append(", state=");
		sb.append(state);

		sb.append(", country=");
		sb.append(country);

		sb.append("}");

		throw new NoSuchPropertyLocationException(sb.toString());
	}

	/**
	 * Returns the last property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching property location, or <code>null</code> if a matching property location could not be found
	 */
	@Override
	public PropertyLocation fetchByLocality_State_Country_Last(
		String locality, String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator) {

		int count = countByLocality_State_Country(locality, state, country);

		if (count == 0) {
			return null;
		}

		List<PropertyLocation> list = findByLocality_State_Country(
			locality, state, country, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the property locations before and after the current property location in the ordered set where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locationId the primary key of the current property location
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation[] findByLocality_State_Country_PrevAndNext(
			long locationId, String locality, String state, String country,
			OrderByComparator<PropertyLocation> orderByComparator)
		throws NoSuchPropertyLocationException {

		locality = Objects.toString(locality, "");
		state = Objects.toString(state, "");
		country = Objects.toString(country, "");

		PropertyLocation propertyLocation = findByPrimaryKey(locationId);

		Session session = null;

		try {
			session = openSession();

			PropertyLocation[] array = new PropertyLocationImpl[3];

			array[0] = getByLocality_State_Country_PrevAndNext(
				session, propertyLocation, locality, state, country,
				orderByComparator, true);

			array[1] = propertyLocation;

			array[2] = getByLocality_State_Country_PrevAndNext(
				session, propertyLocation, locality, state, country,
				orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected PropertyLocation getByLocality_State_Country_PrevAndNext(
		Session session, PropertyLocation propertyLocation, String locality,
		String state, String country,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				6 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(5);
		}

		sb.append(_SQL_SELECT_PROPERTYLOCATION_WHERE);

		boolean bindLocality = false;

		if (locality.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_3);
		}
		else {
			bindLocality = true;

			sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_2);
		}

		boolean bindState = false;

		if (state.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_3);
		}
		else {
			bindState = true;

			sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_2);
		}

		boolean bindCountry = false;

		if (country.isEmpty()) {
			sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_3);
		}
		else {
			bindCountry = true;

			sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(PropertyLocationModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindLocality) {
			queryPos.add(locality);
		}

		if (bindState) {
			queryPos.add(state);
		}

		if (bindCountry) {
			queryPos.add(country);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						propertyLocation)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<PropertyLocation> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the property locations where locality = &#63; and state = &#63; and country = &#63; from the database.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 */
	@Override
	public void removeByLocality_State_Country(
		String locality, String state, String country) {

		for (PropertyLocation propertyLocation :
				findByLocality_State_Country(
					locality, state, country, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations where locality = &#63; and state = &#63; and country = &#63;.
	 *
	 * @param locality the locality
	 * @param state the state
	 * @param country the country
	 * @return the number of matching property locations
	 */
	@Override
	public int countByLocality_State_Country(
		String locality, String state, String country) {

		locality = Objects.toString(locality, "");
		state = Objects.toString(state, "");
		country = Objects.toString(country, "");

		FinderPath finderPath = _finderPathCountByLocality_State_Country;

		Object[] finderArgs = new Object[] {locality, state, country};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_SQL_COUNT_PROPERTYLOCATION_WHERE);

			boolean bindLocality = false;

			if (locality.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_3);
			}
			else {
				bindLocality = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_2);
			}

			boolean bindState = false;

			if (state.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_3);
			}
			else {
				bindState = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_2);
			}

			boolean bindCountry = false;

			if (country.isEmpty()) {
				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_3);
			}
			else {
				bindCountry = true;

				sb.append(_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindLocality) {
					queryPos.add(locality);
				}

				if (bindState) {
					queryPos.add(state);
				}

				if (bindCountry) {
					queryPos.add(country);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_2 =
			"propertyLocation.locality = ? AND ";

	private static final String
		_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_LOCALITY_3 =
			"(propertyLocation.locality IS NULL OR propertyLocation.locality = '') AND ";

	private static final String _FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_2 =
		"propertyLocation.state = ? AND ";

	private static final String _FINDER_COLUMN_LOCALITY_STATE_COUNTRY_STATE_3 =
		"(propertyLocation.state IS NULL OR propertyLocation.state = '') AND ";

	private static final String
		_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_2 =
			"propertyLocation.country = ?";

	private static final String
		_FINDER_COLUMN_LOCALITY_STATE_COUNTRY_COUNTRY_3 =
			"(propertyLocation.country IS NULL OR propertyLocation.country = '')";

	public PropertyLocationPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("state", "state_");

		setDBColumnNames(dbColumnNames);

		setModelClass(PropertyLocation.class);

		setModelImplClass(PropertyLocationImpl.class);
		setModelPKClass(long.class);

		setTable(PropertyLocationTable.INSTANCE);
	}

	/**
	 * Caches the property location in the entity cache if it is enabled.
	 *
	 * @param propertyLocation the property location
	 */
	@Override
	public void cacheResult(PropertyLocation propertyLocation) {
		entityCache.putResult(
			PropertyLocationImpl.class, propertyLocation.getPrimaryKey(),
			propertyLocation);

		finderCache.putResult(
			_finderPathFetchByHostPropertyId,
			new Object[] {propertyLocation.getHostPropertyId()},
			propertyLocation);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the property locations in the entity cache if it is enabled.
	 *
	 * @param propertyLocations the property locations
	 */
	@Override
	public void cacheResult(List<PropertyLocation> propertyLocations) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (propertyLocations.size() >
				 _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (PropertyLocation propertyLocation : propertyLocations) {
			if (entityCache.getResult(
					PropertyLocationImpl.class,
					propertyLocation.getPrimaryKey()) == null) {

				cacheResult(propertyLocation);
			}
		}
	}

	/**
	 * Clears the cache for all property locations.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(PropertyLocationImpl.class);

		finderCache.clearCache(PropertyLocationImpl.class);
	}

	/**
	 * Clears the cache for the property location.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(PropertyLocation propertyLocation) {
		entityCache.removeResult(PropertyLocationImpl.class, propertyLocation);
	}

	@Override
	public void clearCache(List<PropertyLocation> propertyLocations) {
		for (PropertyLocation propertyLocation : propertyLocations) {
			entityCache.removeResult(
				PropertyLocationImpl.class, propertyLocation);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(PropertyLocationImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(PropertyLocationImpl.class, primaryKey);
		}
	}

	protected void cacheUniqueFindersCache(
		PropertyLocationModelImpl propertyLocationModelImpl) {

		Object[] args = new Object[] {
			propertyLocationModelImpl.getHostPropertyId()
		};

		finderCache.putResult(
			_finderPathCountByHostPropertyId, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchByHostPropertyId, args, propertyLocationModelImpl);
	}

	/**
	 * Creates a new property location with the primary key. Does not add the property location to the database.
	 *
	 * @param locationId the primary key for the new property location
	 * @return the new property location
	 */
	@Override
	public PropertyLocation create(long locationId) {
		PropertyLocation propertyLocation = new PropertyLocationImpl();

		propertyLocation.setNew(true);
		propertyLocation.setPrimaryKey(locationId);

		return propertyLocation;
	}

	/**
	 * Removes the property location with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location that was removed
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation remove(long locationId)
		throws NoSuchPropertyLocationException {

		return remove((Serializable)locationId);
	}

	/**
	 * Removes the property location with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the property location
	 * @return the property location that was removed
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation remove(Serializable primaryKey)
		throws NoSuchPropertyLocationException {

		Session session = null;

		try {
			session = openSession();

			PropertyLocation propertyLocation = (PropertyLocation)session.get(
				PropertyLocationImpl.class, primaryKey);

			if (propertyLocation == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchPropertyLocationException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(propertyLocation);
		}
		catch (NoSuchPropertyLocationException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected PropertyLocation removeImpl(PropertyLocation propertyLocation) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(propertyLocation)) {
				propertyLocation = (PropertyLocation)session.get(
					PropertyLocationImpl.class,
					propertyLocation.getPrimaryKeyObj());
			}

			if (propertyLocation != null) {
				session.delete(propertyLocation);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (propertyLocation != null) {
			clearCache(propertyLocation);
		}

		return propertyLocation;
	}

	@Override
	public PropertyLocation updateImpl(PropertyLocation propertyLocation) {
		boolean isNew = propertyLocation.isNew();

		if (!(propertyLocation instanceof PropertyLocationModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(propertyLocation.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					propertyLocation);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in propertyLocation proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom PropertyLocation implementation " +
					propertyLocation.getClass());
		}

		PropertyLocationModelImpl propertyLocationModelImpl =
			(PropertyLocationModelImpl)propertyLocation;

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(propertyLocation);
			}
			else {
				propertyLocation = (PropertyLocation)session.merge(
					propertyLocation);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			PropertyLocationImpl.class, propertyLocationModelImpl, false, true);

		cacheUniqueFindersCache(propertyLocationModelImpl);

		if (isNew) {
			propertyLocation.setNew(false);
		}

		propertyLocation.resetOriginalValues();

		return propertyLocation;
	}

	/**
	 * Returns the property location with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the property location
	 * @return the property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation findByPrimaryKey(Serializable primaryKey)
		throws NoSuchPropertyLocationException {

		PropertyLocation propertyLocation = fetchByPrimaryKey(primaryKey);

		if (propertyLocation == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchPropertyLocationException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return propertyLocation;
	}

	/**
	 * Returns the property location with the primary key or throws a <code>NoSuchPropertyLocationException</code> if it could not be found.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location
	 * @throws NoSuchPropertyLocationException if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation findByPrimaryKey(long locationId)
		throws NoSuchPropertyLocationException {

		return findByPrimaryKey((Serializable)locationId);
	}

	/**
	 * Returns the property location with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param locationId the primary key of the property location
	 * @return the property location, or <code>null</code> if a property location with the primary key could not be found
	 */
	@Override
	public PropertyLocation fetchByPrimaryKey(long locationId) {
		return fetchByPrimaryKey((Serializable)locationId);
	}

	/**
	 * Returns all the property locations.
	 *
	 * @return the property locations
	 */
	@Override
	public List<PropertyLocation> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @return the range of property locations
	 */
	@Override
	public List<PropertyLocation> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of property locations
	 */
	@Override
	public List<PropertyLocation> findAll(
		int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the property locations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>PropertyLocationModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of property locations
	 * @param end the upper bound of the range of property locations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of property locations
	 */
	@Override
	public List<PropertyLocation> findAll(
		int start, int end,
		OrderByComparator<PropertyLocation> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<PropertyLocation> list = null;

		if (useFinderCache) {
			list = (List<PropertyLocation>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_PROPERTYLOCATION);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_PROPERTYLOCATION;

				sql = sql.concat(PropertyLocationModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<PropertyLocation>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the property locations from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (PropertyLocation propertyLocation : findAll()) {
			remove(propertyLocation);
		}
	}

	/**
	 * Returns the number of property locations.
	 *
	 * @return the number of property locations
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_PROPERTYLOCATION);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "locationId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_PROPERTYLOCATION;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return PropertyLocationModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the property location persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathFetchByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchByHostPropertyId",
			new String[] {Long.class.getName()},
			new String[] {"hostPropertyId"}, true);

		_finderPathCountByHostPropertyId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByHostPropertyId",
			new String[] {Long.class.getName()},
			new String[] {"hostPropertyId"}, false);

		_finderPathWithPaginationFindByLocality = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByLocality",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"locality"}, true);

		_finderPathWithoutPaginationFindByLocality = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByLocality",
			new String[] {String.class.getName()}, new String[] {"locality"},
			true);

		_finderPathCountByLocality = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByLocality",
			new String[] {String.class.getName()}, new String[] {"locality"},
			false);

		_finderPathWithPaginationFindByState = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByState",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"state_"}, true);

		_finderPathWithoutPaginationFindByState = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByState",
			new String[] {String.class.getName()}, new String[] {"state_"},
			true);

		_finderPathCountByState = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByState",
			new String[] {String.class.getName()}, new String[] {"state_"},
			false);

		_finderPathWithPaginationFindByZipCode = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByZipCode",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"zipCode"}, true);

		_finderPathWithoutPaginationFindByZipCode = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByZipCode",
			new String[] {String.class.getName()}, new String[] {"zipCode"},
			true);

		_finderPathCountByZipCode = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByZipCode",
			new String[] {String.class.getName()}, new String[] {"zipCode"},
			false);

		_finderPathWithPaginationFindByCountry = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCountry",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"country"}, true);

		_finderPathWithoutPaginationFindByCountry = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCountry",
			new String[] {String.class.getName()}, new String[] {"country"},
			true);

		_finderPathCountByCountry = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCountry",
			new String[] {String.class.getName()}, new String[] {"country"},
			false);

		_finderPathWithPaginationFindByLocality_State = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByLocality_State",
			new String[] {
				String.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			},
			new String[] {"locality", "state_"}, true);

		_finderPathWithoutPaginationFindByLocality_State = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByLocality_State",
			new String[] {String.class.getName(), String.class.getName()},
			new String[] {"locality", "state_"}, true);

		_finderPathCountByLocality_State = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByLocality_State",
			new String[] {String.class.getName(), String.class.getName()},
			new String[] {"locality", "state_"}, false);

		_finderPathWithPaginationFindByLocality_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByLocality_Country",
			new String[] {
				String.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			},
			new String[] {"locality", "country"}, true);

		_finderPathWithoutPaginationFindByLocality_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByLocality_Country",
			new String[] {String.class.getName(), String.class.getName()},
			new String[] {"locality", "country"}, true);

		_finderPathCountByLocality_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByLocality_Country",
			new String[] {String.class.getName(), String.class.getName()},
			new String[] {"locality", "country"}, false);

		_finderPathWithPaginationFindByState_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByState_Country",
			new String[] {
				String.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			},
			new String[] {"state_", "country"}, true);

		_finderPathWithoutPaginationFindByState_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByState_Country",
			new String[] {String.class.getName(), String.class.getName()},
			new String[] {"state_", "country"}, true);

		_finderPathCountByState_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByState_Country",
			new String[] {String.class.getName(), String.class.getName()},
			new String[] {"state_", "country"}, false);

		_finderPathWithPaginationFindByLocality_State_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByLocality_State_Country",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"locality", "state_", "country"}, true);

		_finderPathWithoutPaginationFindByLocality_State_Country =
			new FinderPath(
				FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
				"findByLocality_State_Country",
				new String[] {
					String.class.getName(), String.class.getName(),
					String.class.getName()
				},
				new String[] {"locality", "state_", "country"}, true);

		_finderPathCountByLocality_State_Country = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByLocality_State_Country",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName()
			},
			new String[] {"locality", "state_", "country"}, false);

		PropertyLocationUtil.setPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		PropertyLocationUtil.setPersistence(null);

		entityCache.removeCache(PropertyLocationImpl.class.getName());
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_PROPERTYLOCATION =
		"SELECT propertyLocation FROM PropertyLocation propertyLocation";

	private static final String _SQL_SELECT_PROPERTYLOCATION_WHERE =
		"SELECT propertyLocation FROM PropertyLocation propertyLocation WHERE ";

	private static final String _SQL_COUNT_PROPERTYLOCATION =
		"SELECT COUNT(propertyLocation) FROM PropertyLocation propertyLocation";

	private static final String _SQL_COUNT_PROPERTYLOCATION_WHERE =
		"SELECT COUNT(propertyLocation) FROM PropertyLocation propertyLocation WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "propertyLocation.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No PropertyLocation exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No PropertyLocation exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		PropertyLocationPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"state"});

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

}