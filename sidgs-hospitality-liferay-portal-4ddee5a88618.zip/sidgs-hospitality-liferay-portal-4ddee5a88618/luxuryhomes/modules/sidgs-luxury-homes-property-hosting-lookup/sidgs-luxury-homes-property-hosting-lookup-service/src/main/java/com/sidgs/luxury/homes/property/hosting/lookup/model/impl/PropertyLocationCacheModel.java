/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyLocation;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing PropertyLocation in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class PropertyLocationCacheModel
	implements CacheModel<PropertyLocation>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof PropertyLocationCacheModel)) {
			return false;
		}

		PropertyLocationCacheModel propertyLocationCacheModel =
			(PropertyLocationCacheModel)object;

		if (locationId == propertyLocationCacheModel.locationId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, locationId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{locationId=");
		sb.append(locationId);
		sb.append(", hostPropertyId=");
		sb.append(hostPropertyId);
		sb.append(", plotNo=");
		sb.append(plotNo);
		sb.append(", street=");
		sb.append(street);
		sb.append(", landmark=");
		sb.append(landmark);
		sb.append(", locality=");
		sb.append(locality);
		sb.append(", city=");
		sb.append(city);
		sb.append(", state=");
		sb.append(state);
		sb.append(", country=");
		sb.append(country);
		sb.append(", zipCode=");
		sb.append(zipCode);
		sb.append(", coordinates=");
		sb.append(coordinates);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public PropertyLocation toEntityModel() {
		PropertyLocationImpl propertyLocationImpl = new PropertyLocationImpl();

		propertyLocationImpl.setLocationId(locationId);
		propertyLocationImpl.setHostPropertyId(hostPropertyId);

		if (plotNo == null) {
			propertyLocationImpl.setPlotNo("");
		}
		else {
			propertyLocationImpl.setPlotNo(plotNo);
		}

		if (street == null) {
			propertyLocationImpl.setStreet("");
		}
		else {
			propertyLocationImpl.setStreet(street);
		}

		if (landmark == null) {
			propertyLocationImpl.setLandmark("");
		}
		else {
			propertyLocationImpl.setLandmark(landmark);
		}

		if (locality == null) {
			propertyLocationImpl.setLocality("");
		}
		else {
			propertyLocationImpl.setLocality(locality);
		}

		if (city == null) {
			propertyLocationImpl.setCity("");
		}
		else {
			propertyLocationImpl.setCity(city);
		}

		if (state == null) {
			propertyLocationImpl.setState("");
		}
		else {
			propertyLocationImpl.setState(state);
		}

		if (country == null) {
			propertyLocationImpl.setCountry("");
		}
		else {
			propertyLocationImpl.setCountry(country);
		}

		if (zipCode == null) {
			propertyLocationImpl.setZipCode("");
		}
		else {
			propertyLocationImpl.setZipCode(zipCode);
		}

		if (coordinates == null) {
			propertyLocationImpl.setCoordinates("");
		}
		else {
			propertyLocationImpl.setCoordinates(coordinates);
		}

		propertyLocationImpl.resetOriginalValues();

		return propertyLocationImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		locationId = objectInput.readLong();

		hostPropertyId = objectInput.readLong();
		plotNo = objectInput.readUTF();
		street = objectInput.readUTF();
		landmark = objectInput.readUTF();
		locality = objectInput.readUTF();
		city = objectInput.readUTF();
		state = objectInput.readUTF();
		country = objectInput.readUTF();
		zipCode = objectInput.readUTF();
		coordinates = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(locationId);

		objectOutput.writeLong(hostPropertyId);

		if (plotNo == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(plotNo);
		}

		if (street == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(street);
		}

		if (landmark == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(landmark);
		}

		if (locality == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(locality);
		}

		if (city == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(city);
		}

		if (state == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(state);
		}

		if (country == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(country);
		}

		if (zipCode == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(zipCode);
		}

		if (coordinates == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(coordinates);
		}
	}

	public long locationId;
	public long hostPropertyId;
	public String plotNo;
	public String street;
	public String landmark;
	public String locality;
	public String city;
	public String state;
	public String country;
	public String zipCode;
	public String coordinates;

}