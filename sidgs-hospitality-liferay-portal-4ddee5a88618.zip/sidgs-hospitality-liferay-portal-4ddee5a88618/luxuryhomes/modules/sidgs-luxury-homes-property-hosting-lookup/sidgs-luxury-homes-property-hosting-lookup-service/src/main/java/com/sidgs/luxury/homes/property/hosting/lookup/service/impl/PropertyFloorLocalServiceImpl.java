/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.impl;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor;
import com.sidgs.luxury.homes.property.hosting.lookup.service.base.PropertyFloorLocalServiceBaseImpl;

import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor",
	service = AopService.class
)
public class PropertyFloorLocalServiceImpl extends PropertyFloorLocalServiceBaseImpl {
	private static final Log log = LogFactoryUtil.getLog(PropertyFloorLocalServiceImpl.class);
	public PropertyFloor addPropertyFloorPlan(long hostPropertyId, int totalGuests, int bedrooms, int beds, int bathrooms) {
		PropertyFloor propertyFloor = propertyFloorPersistence.create(CounterLocalServiceUtil.increment(PropertyFloor.class.getName()));
		propertyFloor.setHostPropertyId(hostPropertyId);
		propertyFloor.setTotalGuests(totalGuests);
		propertyFloor.setBedrooms(bedrooms);
		propertyFloor.setBeds(beds);
		propertyFloor.setBathrooms(bathrooms);
		propertyFloor = propertyFloorPersistence.update(propertyFloor);
		log.info("Floor Plan added into PropertyFloor table with propertyId ::"+propertyFloor.getHostPropertyId());
		return propertyFloor;
	}
	
	public List<PropertyFloor> getFloorPlanByPropertyId(long hostPropertyId) {
		return propertyFloorPersistence.findByHostPropertyId(hostPropertyId);
	}
	
	public List<PropertyFloor> getFloorPlanByTotalGuests(int totalGuests) {
		return propertyFloorPersistence.findByTotalGuests(totalGuests);
	}
	
	public List<PropertyFloor> getFloorPlanByBedrooms(int bedrooms) {
		return propertyFloorPersistence.findByBedrooms(bedrooms);
	}
	
	public List<PropertyFloor> getFloorPlanByBeds(int beds) {
		return propertyFloorPersistence.findByBeds(beds);
	}
	
	public List<PropertyFloor> getFloorPlanByBathrooms(int bathrooms) {
		return propertyFloorPersistence.findByBathrooms(bathrooms);
	}
	
	public List<PropertyFloor> getFloorPlanByTotalGuestsAndBedrooms(int totalGuests, int bedrooms) {
		return propertyFloorPersistence.findByTotalGuests_Bedrooms(totalGuests, bedrooms);
	}
}