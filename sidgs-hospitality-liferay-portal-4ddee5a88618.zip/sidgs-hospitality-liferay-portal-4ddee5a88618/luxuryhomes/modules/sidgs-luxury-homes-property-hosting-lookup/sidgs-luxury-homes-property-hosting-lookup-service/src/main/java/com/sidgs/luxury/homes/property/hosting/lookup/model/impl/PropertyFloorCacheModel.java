/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.sidgs.luxury.homes.property.hosting.lookup.model.PropertyFloor;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing PropertyFloor in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class PropertyFloorCacheModel
	implements CacheModel<PropertyFloor>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof PropertyFloorCacheModel)) {
			return false;
		}

		PropertyFloorCacheModel propertyFloorCacheModel =
			(PropertyFloorCacheModel)object;

		if (floorId == propertyFloorCacheModel.floorId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, floorId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{floorId=");
		sb.append(floorId);
		sb.append(", hostPropertyId=");
		sb.append(hostPropertyId);
		sb.append(", totalGuests=");
		sb.append(totalGuests);
		sb.append(", bedrooms=");
		sb.append(bedrooms);
		sb.append(", beds=");
		sb.append(beds);
		sb.append(", bathrooms=");
		sb.append(bathrooms);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public PropertyFloor toEntityModel() {
		PropertyFloorImpl propertyFloorImpl = new PropertyFloorImpl();

		propertyFloorImpl.setFloorId(floorId);
		propertyFloorImpl.setHostPropertyId(hostPropertyId);
		propertyFloorImpl.setTotalGuests(totalGuests);
		propertyFloorImpl.setBedrooms(bedrooms);
		propertyFloorImpl.setBeds(beds);
		propertyFloorImpl.setBathrooms(bathrooms);

		propertyFloorImpl.resetOriginalValues();

		return propertyFloorImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		floorId = objectInput.readLong();

		hostPropertyId = objectInput.readLong();

		totalGuests = objectInput.readInt();

		bedrooms = objectInput.readInt();

		beds = objectInput.readInt();

		bathrooms = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(floorId);

		objectOutput.writeLong(hostPropertyId);

		objectOutput.writeInt(totalGuests);

		objectOutput.writeInt(bedrooms);

		objectOutput.writeInt(beds);

		objectOutput.writeInt(bathrooms);
	}

	public long floorId;
	public long hostPropertyId;
	public int totalGuests;
	public int bedrooms;
	public int beds;
	public int bathrooms;

}