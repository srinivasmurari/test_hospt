/**
 * SPDX-FileCopyrightText: (c) 2023 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import com.sidgs.luxury.homes.property.hosting.lookup.exception.NoSuchHostPropertyException;
import com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty;
import com.sidgs.luxury.homes.property.hosting.lookup.model.HostPropertyTable;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.HostPropertyImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.model.impl.HostPropertyModelImpl;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.HostPropertyPersistence;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.HostPropertyUtil;
import com.sidgs.luxury.homes.property.hosting.lookup.service.persistence.impl.constants.SIDPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the host property service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = HostPropertyPersistence.class)
public class HostPropertyPersistenceImpl
	extends BasePersistenceImpl<HostProperty>
	implements HostPropertyPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>HostPropertyUtil</code> to access the host property persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		HostPropertyImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathFetchByArticleId;
	private FinderPath _finderPathCountByArticleId;

	/**
	 * Returns the host property where articleId = &#63; or throws a <code>NoSuchHostPropertyException</code> if it could not be found.
	 *
	 * @param articleId the article ID
	 * @return the matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	@Override
	public HostProperty findByArticleId(String articleId)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchByArticleId(articleId);

		if (hostProperty == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("articleId=");
			sb.append(articleId);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchHostPropertyException(sb.toString());
		}

		return hostProperty;
	}

	/**
	 * Returns the host property where articleId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param articleId the article ID
	 * @return the matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchByArticleId(String articleId) {
		return fetchByArticleId(articleId, true);
	}

	/**
	 * Returns the host property where articleId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param articleId the article ID
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchByArticleId(
		String articleId, boolean useFinderCache) {

		articleId = Objects.toString(articleId, "");

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {articleId};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchByArticleId, finderArgs, this);
		}

		if (result instanceof HostProperty) {
			HostProperty hostProperty = (HostProperty)result;

			if (!Objects.equals(articleId, hostProperty.getArticleId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_HOSTPROPERTY_WHERE);

			boolean bindArticleId = false;

			if (articleId.isEmpty()) {
				sb.append(_FINDER_COLUMN_ARTICLEID_ARTICLEID_3);
			}
			else {
				bindArticleId = true;

				sb.append(_FINDER_COLUMN_ARTICLEID_ARTICLEID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindArticleId) {
					queryPos.add(articleId);
				}

				List<HostProperty> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchByArticleId, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {articleId};
							}

							_log.warn(
								"HostPropertyPersistenceImpl.fetchByArticleId(String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					HostProperty hostProperty = list.get(0);

					result = hostProperty;

					cacheResult(hostProperty);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (HostProperty)result;
		}
	}

	/**
	 * Removes the host property where articleId = &#63; from the database.
	 *
	 * @param articleId the article ID
	 * @return the host property that was removed
	 */
	@Override
	public HostProperty removeByArticleId(String articleId)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = findByArticleId(articleId);

		return remove(hostProperty);
	}

	/**
	 * Returns the number of host properties where articleId = &#63;.
	 *
	 * @param articleId the article ID
	 * @return the number of matching host properties
	 */
	@Override
	public int countByArticleId(String articleId) {
		articleId = Objects.toString(articleId, "");

		FinderPath finderPath = _finderPathCountByArticleId;

		Object[] finderArgs = new Object[] {articleId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_HOSTPROPERTY_WHERE);

			boolean bindArticleId = false;

			if (articleId.isEmpty()) {
				sb.append(_FINDER_COLUMN_ARTICLEID_ARTICLEID_3);
			}
			else {
				bindArticleId = true;

				sb.append(_FINDER_COLUMN_ARTICLEID_ARTICLEID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindArticleId) {
					queryPos.add(articleId);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ARTICLEID_ARTICLEID_2 =
		"hostProperty.articleId = ?";

	private static final String _FINDER_COLUMN_ARTICLEID_ARTICLEID_3 =
		"(hostProperty.articleId IS NULL OR hostProperty.articleId = '')";

	private FinderPath _finderPathWithPaginationFindByUserId_Active;
	private FinderPath _finderPathWithoutPaginationFindByUserId_Active;
	private FinderPath _finderPathCountByUserId_Active;

	/**
	 * Returns all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @return the matching host properties
	 */
	@Override
	public List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active) {

		return findByUserId_Active(
			createdByUserId, active, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	@Override
	public List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end) {

		return findByUserId_Active(createdByUserId, active, start, end, null);
	}

	/**
	 * Returns an ordered range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	@Override
	public List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator) {

		return findByUserId_Active(
			createdByUserId, active, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	@Override
	public List<HostProperty> findByUserId_Active(
		long createdByUserId, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByUserId_Active;
				finderArgs = new Object[] {createdByUserId, active};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByUserId_Active;
			finderArgs = new Object[] {
				createdByUserId, active, start, end, orderByComparator
			};
		}

		List<HostProperty> list = null;

		if (useFinderCache) {
			list = (List<HostProperty>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (HostProperty hostProperty : list) {
					if ((createdByUserId !=
							hostProperty.getCreatedByUserId()) ||
						(active != hostProperty.isActive())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(4);
			}

			sb.append(_SQL_SELECT_HOSTPROPERTY_WHERE);

			sb.append(_FINDER_COLUMN_USERID_ACTIVE_CREATEDBYUSERID_2);

			sb.append(_FINDER_COLUMN_USERID_ACTIVE_ACTIVE_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(HostPropertyModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(createdByUserId);

				queryPos.add(active);

				list = (List<HostProperty>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	@Override
	public HostProperty findByUserId_Active_First(
			long createdByUserId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchByUserId_Active_First(
			createdByUserId, active, orderByComparator);

		if (hostProperty != null) {
			return hostProperty;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("createdByUserId=");
		sb.append(createdByUserId);

		sb.append(", active=");
		sb.append(active);

		sb.append("}");

		throw new NoSuchHostPropertyException(sb.toString());
	}

	/**
	 * Returns the first host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchByUserId_Active_First(
		long createdByUserId, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		List<HostProperty> list = findByUserId_Active(
			createdByUserId, active, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	@Override
	public HostProperty findByUserId_Active_Last(
			long createdByUserId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchByUserId_Active_Last(
			createdByUserId, active, orderByComparator);

		if (hostProperty != null) {
			return hostProperty;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("createdByUserId=");
		sb.append(createdByUserId);

		sb.append(", active=");
		sb.append(active);

		sb.append("}");

		throw new NoSuchHostPropertyException(sb.toString());
	}

	/**
	 * Returns the last host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchByUserId_Active_Last(
		long createdByUserId, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		int count = countByUserId_Active(createdByUserId, active);

		if (count == 0) {
			return null;
		}

		List<HostProperty> list = findByUserId_Active(
			createdByUserId, active, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the host properties before and after the current host property in the ordered set where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty[] findByUserId_Active_PrevAndNext(
			long hostPropertyId, long createdByUserId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = findByPrimaryKey(hostPropertyId);

		Session session = null;

		try {
			session = openSession();

			HostProperty[] array = new HostPropertyImpl[3];

			array[0] = getByUserId_Active_PrevAndNext(
				session, hostProperty, createdByUserId, active,
				orderByComparator, true);

			array[1] = hostProperty;

			array[2] = getByUserId_Active_PrevAndNext(
				session, hostProperty, createdByUserId, active,
				orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected HostProperty getByUserId_Active_PrevAndNext(
		Session session, HostProperty hostProperty, long createdByUserId,
		boolean active, OrderByComparator<HostProperty> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(4);
		}

		sb.append(_SQL_SELECT_HOSTPROPERTY_WHERE);

		sb.append(_FINDER_COLUMN_USERID_ACTIVE_CREATEDBYUSERID_2);

		sb.append(_FINDER_COLUMN_USERID_ACTIVE_ACTIVE_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(HostPropertyModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(createdByUserId);

		queryPos.add(active);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(hostProperty)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<HostProperty> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the host properties where createdByUserId = &#63; and active = &#63; from the database.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 */
	@Override
	public void removeByUserId_Active(long createdByUserId, boolean active) {
		for (HostProperty hostProperty :
				findByUserId_Active(
					createdByUserId, active, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(hostProperty);
		}
	}

	/**
	 * Returns the number of host properties where createdByUserId = &#63; and active = &#63;.
	 *
	 * @param createdByUserId the created by user ID
	 * @param active the active
	 * @return the number of matching host properties
	 */
	@Override
	public int countByUserId_Active(long createdByUserId, boolean active) {
		FinderPath finderPath = _finderPathCountByUserId_Active;

		Object[] finderArgs = new Object[] {createdByUserId, active};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_COUNT_HOSTPROPERTY_WHERE);

			sb.append(_FINDER_COLUMN_USERID_ACTIVE_CREATEDBYUSERID_2);

			sb.append(_FINDER_COLUMN_USERID_ACTIVE_ACTIVE_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(createdByUserId);

				queryPos.add(active);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_USERID_ACTIVE_CREATEDBYUSERID_2 =
		"hostProperty.createdByUserId = ? AND ";

	private static final String _FINDER_COLUMN_USERID_ACTIVE_ACTIVE_2 =
		"hostProperty.active = ?";

	private FinderPath _finderPathWithPaginationFindByActive;
	private FinderPath _finderPathWithoutPaginationFindByActive;
	private FinderPath _finderPathCountByActive;

	/**
	 * Returns all the host properties where active = &#63;.
	 *
	 * @param active the active
	 * @return the matching host properties
	 */
	@Override
	public List<HostProperty> findByActive(boolean active) {
		return findByActive(active, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	@Override
	public List<HostProperty> findByActive(boolean active, int start, int end) {
		return findByActive(active, start, end, null);
	}

	/**
	 * Returns an ordered range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	@Override
	public List<HostProperty> findByActive(
		boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator) {

		return findByActive(active, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the host properties where active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	@Override
	public List<HostProperty> findByActive(
		boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByActive;
				finderArgs = new Object[] {active};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByActive;
			finderArgs = new Object[] {active, start, end, orderByComparator};
		}

		List<HostProperty> list = null;

		if (useFinderCache) {
			list = (List<HostProperty>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (HostProperty hostProperty : list) {
					if (active != hostProperty.isActive()) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_HOSTPROPERTY_WHERE);

			sb.append(_FINDER_COLUMN_ACTIVE_ACTIVE_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(HostPropertyModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(active);

				list = (List<HostProperty>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	@Override
	public HostProperty findByActive_First(
			boolean active, OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchByActive_First(
			active, orderByComparator);

		if (hostProperty != null) {
			return hostProperty;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("active=");
		sb.append(active);

		sb.append("}");

		throw new NoSuchHostPropertyException(sb.toString());
	}

	/**
	 * Returns the first host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchByActive_First(
		boolean active, OrderByComparator<HostProperty> orderByComparator) {

		List<HostProperty> list = findByActive(active, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	@Override
	public HostProperty findByActive_Last(
			boolean active, OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchByActive_Last(
			active, orderByComparator);

		if (hostProperty != null) {
			return hostProperty;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("active=");
		sb.append(active);

		sb.append("}");

		throw new NoSuchHostPropertyException(sb.toString());
	}

	/**
	 * Returns the last host property in the ordered set where active = &#63;.
	 *
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchByActive_Last(
		boolean active, OrderByComparator<HostProperty> orderByComparator) {

		int count = countByActive(active);

		if (count == 0) {
			return null;
		}

		List<HostProperty> list = findByActive(
			active, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the host properties before and after the current host property in the ordered set where active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty[] findByActive_PrevAndNext(
			long hostPropertyId, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = findByPrimaryKey(hostPropertyId);

		Session session = null;

		try {
			session = openSession();

			HostProperty[] array = new HostPropertyImpl[3];

			array[0] = getByActive_PrevAndNext(
				session, hostProperty, active, orderByComparator, true);

			array[1] = hostProperty;

			array[2] = getByActive_PrevAndNext(
				session, hostProperty, active, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected HostProperty getByActive_PrevAndNext(
		Session session, HostProperty hostProperty, boolean active,
		OrderByComparator<HostProperty> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_HOSTPROPERTY_WHERE);

		sb.append(_FINDER_COLUMN_ACTIVE_ACTIVE_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(HostPropertyModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(active);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(hostProperty)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<HostProperty> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the host properties where active = &#63; from the database.
	 *
	 * @param active the active
	 */
	@Override
	public void removeByActive(boolean active) {
		for (HostProperty hostProperty :
				findByActive(
					active, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(hostProperty);
		}
	}

	/**
	 * Returns the number of host properties where active = &#63;.
	 *
	 * @param active the active
	 * @return the number of matching host properties
	 */
	@Override
	public int countByActive(boolean active) {
		FinderPath finderPath = _finderPathCountByActive;

		Object[] finderArgs = new Object[] {active};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_HOSTPROPERTY_WHERE);

			sb.append(_FINDER_COLUMN_ACTIVE_ACTIVE_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(active);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ACTIVE_ACTIVE_2 =
		"hostProperty.active = ?";

	private FinderPath _finderPathWithPaginationFindBySharedProperty_Active;
	private FinderPath _finderPathWithoutPaginationFindBySharedProperty_Active;
	private FinderPath _finderPathCountBySharedProperty_Active;

	/**
	 * Returns all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @return the matching host properties
	 */
	@Override
	public List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active) {

		return findBySharedProperty_Active(
			sharedProperty, active, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of matching host properties
	 */
	@Override
	public List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end) {

		return findBySharedProperty_Active(
			sharedProperty, active, start, end, null);
	}

	/**
	 * Returns an ordered range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching host properties
	 */
	@Override
	public List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator) {

		return findBySharedProperty_Active(
			sharedProperty, active, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching host properties
	 */
	@Override
	public List<HostProperty> findBySharedProperty_Active(
		boolean sharedProperty, boolean active, int start, int end,
		OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath =
					_finderPathWithoutPaginationFindBySharedProperty_Active;
				finderArgs = new Object[] {sharedProperty, active};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindBySharedProperty_Active;
			finderArgs = new Object[] {
				sharedProperty, active, start, end, orderByComparator
			};
		}

		List<HostProperty> list = null;

		if (useFinderCache) {
			list = (List<HostProperty>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (HostProperty hostProperty : list) {
					if ((sharedProperty != hostProperty.isSharedProperty()) ||
						(active != hostProperty.isActive())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					4 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(4);
			}

			sb.append(_SQL_SELECT_HOSTPROPERTY_WHERE);

			sb.append(_FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_SHAREDPROPERTY_2);

			sb.append(_FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_ACTIVE_2);

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(HostPropertyModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(sharedProperty);

				queryPos.add(active);

				list = (List<HostProperty>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	@Override
	public HostProperty findBySharedProperty_Active_First(
			boolean sharedProperty, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchBySharedProperty_Active_First(
			sharedProperty, active, orderByComparator);

		if (hostProperty != null) {
			return hostProperty;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("sharedProperty=");
		sb.append(sharedProperty);

		sb.append(", active=");
		sb.append(active);

		sb.append("}");

		throw new NoSuchHostPropertyException(sb.toString());
	}

	/**
	 * Returns the first host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchBySharedProperty_Active_First(
		boolean sharedProperty, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		List<HostProperty> list = findBySharedProperty_Active(
			sharedProperty, active, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property
	 * @throws NoSuchHostPropertyException if a matching host property could not be found
	 */
	@Override
	public HostProperty findBySharedProperty_Active_Last(
			boolean sharedProperty, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchBySharedProperty_Active_Last(
			sharedProperty, active, orderByComparator);

		if (hostProperty != null) {
			return hostProperty;
		}

		StringBundler sb = new StringBundler(6);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("sharedProperty=");
		sb.append(sharedProperty);

		sb.append(", active=");
		sb.append(active);

		sb.append("}");

		throw new NoSuchHostPropertyException(sb.toString());
	}

	/**
	 * Returns the last host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching host property, or <code>null</code> if a matching host property could not be found
	 */
	@Override
	public HostProperty fetchBySharedProperty_Active_Last(
		boolean sharedProperty, boolean active,
		OrderByComparator<HostProperty> orderByComparator) {

		int count = countBySharedProperty_Active(sharedProperty, active);

		if (count == 0) {
			return null;
		}

		List<HostProperty> list = findBySharedProperty_Active(
			sharedProperty, active, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the host properties before and after the current host property in the ordered set where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param hostPropertyId the primary key of the current host property
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty[] findBySharedProperty_Active_PrevAndNext(
			long hostPropertyId, boolean sharedProperty, boolean active,
			OrderByComparator<HostProperty> orderByComparator)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = findByPrimaryKey(hostPropertyId);

		Session session = null;

		try {
			session = openSession();

			HostProperty[] array = new HostPropertyImpl[3];

			array[0] = getBySharedProperty_Active_PrevAndNext(
				session, hostProperty, sharedProperty, active,
				orderByComparator, true);

			array[1] = hostProperty;

			array[2] = getBySharedProperty_Active_PrevAndNext(
				session, hostProperty, sharedProperty, active,
				orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected HostProperty getBySharedProperty_Active_PrevAndNext(
		Session session, HostProperty hostProperty, boolean sharedProperty,
		boolean active, OrderByComparator<HostProperty> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				5 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(4);
		}

		sb.append(_SQL_SELECT_HOSTPROPERTY_WHERE);

		sb.append(_FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_SHAREDPROPERTY_2);

		sb.append(_FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_ACTIVE_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(HostPropertyModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		queryPos.add(sharedProperty);

		queryPos.add(active);

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(hostProperty)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<HostProperty> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the host properties where sharedProperty = &#63; and active = &#63; from the database.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 */
	@Override
	public void removeBySharedProperty_Active(
		boolean sharedProperty, boolean active) {

		for (HostProperty hostProperty :
				findBySharedProperty_Active(
					sharedProperty, active, QueryUtil.ALL_POS,
					QueryUtil.ALL_POS, null)) {

			remove(hostProperty);
		}
	}

	/**
	 * Returns the number of host properties where sharedProperty = &#63; and active = &#63;.
	 *
	 * @param sharedProperty the shared property
	 * @param active the active
	 * @return the number of matching host properties
	 */
	@Override
	public int countBySharedProperty_Active(
		boolean sharedProperty, boolean active) {

		FinderPath finderPath = _finderPathCountBySharedProperty_Active;

		Object[] finderArgs = new Object[] {sharedProperty, active};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_COUNT_HOSTPROPERTY_WHERE);

			sb.append(_FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_SHAREDPROPERTY_2);

			sb.append(_FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_ACTIVE_2);

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				queryPos.add(sharedProperty);

				queryPos.add(active);

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String
		_FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_SHAREDPROPERTY_2 =
			"hostProperty.sharedProperty = ? AND ";

	private static final String _FINDER_COLUMN_SHAREDPROPERTY_ACTIVE_ACTIVE_2 =
		"hostProperty.active = ?";

	public HostPropertyPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("active", "active_");

		setDBColumnNames(dbColumnNames);

		setModelClass(HostProperty.class);

		setModelImplClass(HostPropertyImpl.class);
		setModelPKClass(long.class);

		setTable(HostPropertyTable.INSTANCE);
	}

	/**
	 * Caches the host property in the entity cache if it is enabled.
	 *
	 * @param hostProperty the host property
	 */
	@Override
	public void cacheResult(HostProperty hostProperty) {
		entityCache.putResult(
			HostPropertyImpl.class, hostProperty.getPrimaryKey(), hostProperty);

		finderCache.putResult(
			_finderPathFetchByArticleId,
			new Object[] {hostProperty.getArticleId()}, hostProperty);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the host properties in the entity cache if it is enabled.
	 *
	 * @param hostProperties the host properties
	 */
	@Override
	public void cacheResult(List<HostProperty> hostProperties) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (hostProperties.size() > _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (HostProperty hostProperty : hostProperties) {
			if (entityCache.getResult(
					HostPropertyImpl.class, hostProperty.getPrimaryKey()) ==
						null) {

				cacheResult(hostProperty);
			}
		}
	}

	/**
	 * Clears the cache for all host properties.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(HostPropertyImpl.class);

		finderCache.clearCache(HostPropertyImpl.class);
	}

	/**
	 * Clears the cache for the host property.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(HostProperty hostProperty) {
		entityCache.removeResult(HostPropertyImpl.class, hostProperty);
	}

	@Override
	public void clearCache(List<HostProperty> hostProperties) {
		for (HostProperty hostProperty : hostProperties) {
			entityCache.removeResult(HostPropertyImpl.class, hostProperty);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(HostPropertyImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(HostPropertyImpl.class, primaryKey);
		}
	}

	protected void cacheUniqueFindersCache(
		HostPropertyModelImpl hostPropertyModelImpl) {

		Object[] args = new Object[] {hostPropertyModelImpl.getArticleId()};

		finderCache.putResult(
			_finderPathCountByArticleId, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchByArticleId, args, hostPropertyModelImpl);
	}

	/**
	 * Creates a new host property with the primary key. Does not add the host property to the database.
	 *
	 * @param hostPropertyId the primary key for the new host property
	 * @return the new host property
	 */
	@Override
	public HostProperty create(long hostPropertyId) {
		HostProperty hostProperty = new HostPropertyImpl();

		hostProperty.setNew(true);
		hostProperty.setPrimaryKey(hostPropertyId);

		return hostProperty;
	}

	/**
	 * Removes the host property with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property that was removed
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty remove(long hostPropertyId)
		throws NoSuchHostPropertyException {

		return remove((Serializable)hostPropertyId);
	}

	/**
	 * Removes the host property with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the host property
	 * @return the host property that was removed
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty remove(Serializable primaryKey)
		throws NoSuchHostPropertyException {

		Session session = null;

		try {
			session = openSession();

			HostProperty hostProperty = (HostProperty)session.get(
				HostPropertyImpl.class, primaryKey);

			if (hostProperty == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchHostPropertyException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(hostProperty);
		}
		catch (NoSuchHostPropertyException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected HostProperty removeImpl(HostProperty hostProperty) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(hostProperty)) {
				hostProperty = (HostProperty)session.get(
					HostPropertyImpl.class, hostProperty.getPrimaryKeyObj());
			}

			if (hostProperty != null) {
				session.delete(hostProperty);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (hostProperty != null) {
			clearCache(hostProperty);
		}

		return hostProperty;
	}

	@Override
	public HostProperty updateImpl(HostProperty hostProperty) {
		boolean isNew = hostProperty.isNew();

		if (!(hostProperty instanceof HostPropertyModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(hostProperty.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					hostProperty);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in hostProperty proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom HostProperty implementation " +
					hostProperty.getClass());
		}

		HostPropertyModelImpl hostPropertyModelImpl =
			(HostPropertyModelImpl)hostProperty;

		ServiceContext serviceContext =
			ServiceContextThreadLocal.getServiceContext();

		Date date = new Date();

		if (isNew && (hostProperty.getCreateDate() == null)) {
			if (serviceContext == null) {
				hostProperty.setCreateDate(date);
			}
			else {
				hostProperty.setCreateDate(serviceContext.getCreateDate(date));
			}
		}

		if (!hostPropertyModelImpl.hasSetModifiedDate()) {
			if (serviceContext == null) {
				hostProperty.setModifiedDate(date);
			}
			else {
				hostProperty.setModifiedDate(
					serviceContext.getModifiedDate(date));
			}
		}

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(hostProperty);
			}
			else {
				hostProperty = (HostProperty)session.merge(hostProperty);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			HostPropertyImpl.class, hostPropertyModelImpl, false, true);

		cacheUniqueFindersCache(hostPropertyModelImpl);

		if (isNew) {
			hostProperty.setNew(false);
		}

		hostProperty.resetOriginalValues();

		return hostProperty;
	}

	/**
	 * Returns the host property with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the host property
	 * @return the host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty findByPrimaryKey(Serializable primaryKey)
		throws NoSuchHostPropertyException {

		HostProperty hostProperty = fetchByPrimaryKey(primaryKey);

		if (hostProperty == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchHostPropertyException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return hostProperty;
	}

	/**
	 * Returns the host property with the primary key or throws a <code>NoSuchHostPropertyException</code> if it could not be found.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property
	 * @throws NoSuchHostPropertyException if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty findByPrimaryKey(long hostPropertyId)
		throws NoSuchHostPropertyException {

		return findByPrimaryKey((Serializable)hostPropertyId);
	}

	/**
	 * Returns the host property with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param hostPropertyId the primary key of the host property
	 * @return the host property, or <code>null</code> if a host property with the primary key could not be found
	 */
	@Override
	public HostProperty fetchByPrimaryKey(long hostPropertyId) {
		return fetchByPrimaryKey((Serializable)hostPropertyId);
	}

	/**
	 * Returns all the host properties.
	 *
	 * @return the host properties
	 */
	@Override
	public List<HostProperty> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @return the range of host properties
	 */
	@Override
	public List<HostProperty> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of host properties
	 */
	@Override
	public List<HostProperty> findAll(
		int start, int end, OrderByComparator<HostProperty> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the host properties.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>HostPropertyModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of host properties
	 * @param end the upper bound of the range of host properties (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of host properties
	 */
	@Override
	public List<HostProperty> findAll(
		int start, int end, OrderByComparator<HostProperty> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<HostProperty> list = null;

		if (useFinderCache) {
			list = (List<HostProperty>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_HOSTPROPERTY);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_HOSTPROPERTY;

				sql = sql.concat(HostPropertyModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<HostProperty>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the host properties from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (HostProperty hostProperty : findAll()) {
			remove(hostProperty);
		}
	}

	/**
	 * Returns the number of host properties.
	 *
	 * @return the number of host properties
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_HOSTPROPERTY);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "hostPropertyId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_HOSTPROPERTY;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return HostPropertyModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the host property persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathFetchByArticleId = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchByArticleId",
			new String[] {String.class.getName()}, new String[] {"articleId"},
			true);

		_finderPathCountByArticleId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByArticleId",
			new String[] {String.class.getName()}, new String[] {"articleId"},
			false);

		_finderPathWithPaginationFindByUserId_Active = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUserId_Active",
			new String[] {
				Long.class.getName(), Boolean.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			},
			new String[] {"createdByUserId", "active_"}, true);

		_finderPathWithoutPaginationFindByUserId_Active = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUserId_Active",
			new String[] {Long.class.getName(), Boolean.class.getName()},
			new String[] {"createdByUserId", "active_"}, true);

		_finderPathCountByUserId_Active = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUserId_Active",
			new String[] {Long.class.getName(), Boolean.class.getName()},
			new String[] {"createdByUserId", "active_"}, false);

		_finderPathWithPaginationFindByActive = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByActive",
			new String[] {
				Boolean.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"active_"}, true);

		_finderPathWithoutPaginationFindByActive = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByActive",
			new String[] {Boolean.class.getName()}, new String[] {"active_"},
			true);

		_finderPathCountByActive = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByActive",
			new String[] {Boolean.class.getName()}, new String[] {"active_"},
			false);

		_finderPathWithPaginationFindBySharedProperty_Active = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findBySharedProperty_Active",
			new String[] {
				Boolean.class.getName(), Boolean.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			},
			new String[] {"sharedProperty", "active_"}, true);

		_finderPathWithoutPaginationFindBySharedProperty_Active =
			new FinderPath(
				FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
				"findBySharedProperty_Active",
				new String[] {Boolean.class.getName(), Boolean.class.getName()},
				new String[] {"sharedProperty", "active_"}, true);

		_finderPathCountBySharedProperty_Active = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countBySharedProperty_Active",
			new String[] {Boolean.class.getName(), Boolean.class.getName()},
			new String[] {"sharedProperty", "active_"}, false);

		HostPropertyUtil.setPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		HostPropertyUtil.setPersistence(null);

		entityCache.removeCache(HostPropertyImpl.class.getName());
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = SIDPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_HOSTPROPERTY =
		"SELECT hostProperty FROM HostProperty hostProperty";

	private static final String _SQL_SELECT_HOSTPROPERTY_WHERE =
		"SELECT hostProperty FROM HostProperty hostProperty WHERE ";

	private static final String _SQL_COUNT_HOSTPROPERTY =
		"SELECT COUNT(hostProperty) FROM HostProperty hostProperty";

	private static final String _SQL_COUNT_HOSTPROPERTY_WHERE =
		"SELECT COUNT(hostProperty) FROM HostProperty hostProperty WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "hostProperty.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No HostProperty exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No HostProperty exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		HostPropertyPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"active"});

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

}