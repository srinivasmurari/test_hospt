package com.sidgs.luxury.homes.identity.headless.internal.jaxrs.application;

import javax.annotation.Generated;

import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;

/**
 * @author MuraliMohanSIDGlobal
 * @generated
 */
@Component(
	property = {
		"liferay.jackson=false", "osgi.jaxrs.application.base=/vZ",
		"osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
		"osgi.jaxrs.name=SidgsLuxuryHomesIdentityHeadless"
	},
	service = Application.class
)
@Generated("")
public class SidgsLuxuryHomesIdentityHeadlessApplication extends Application {
}