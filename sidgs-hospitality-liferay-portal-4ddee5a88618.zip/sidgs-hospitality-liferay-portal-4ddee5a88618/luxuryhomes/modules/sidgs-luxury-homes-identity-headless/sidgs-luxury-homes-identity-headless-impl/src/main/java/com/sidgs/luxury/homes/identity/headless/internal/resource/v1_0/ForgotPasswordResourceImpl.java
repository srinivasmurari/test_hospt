package com.sidgs.luxury.homes.identity.headless.internal.resource.v1_0;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.sidgs.luxury.homes.identity.headless.dto.v1_0.HospStatus;
import com.sidgs.luxury.homes.identity.headless.resource.v1_0.ForgotPasswordResource;
import com.sidgs.luxury.homes.identity.service.LuxuryHomesIdentityService;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author MuraliMohanSIDGlobal
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/forgot-password.properties",
	scope = ServiceScope.PROTOTYPE, service = ForgotPasswordResource.class
)
public class ForgotPasswordResourceImpl extends BaseForgotPasswordResourceImpl {
private final static Log log = LogFactoryUtil.getLog(ForgotPasswordResourceImpl.class.getName());
	
	@Override
	public Response postForgotPassword(String emailAddress) throws Exception {
		HospStatus hospStatus = luxuryHomesIdentityService.forgotPassword(emailAddress);
		log.info("Forgot password completed ::"+hospStatus.getStatus());
		if(hospStatus.getStatus().equals("success")) {
			return Response.status(Status.OK).entity(hospStatus).build();
		}
		log.info("Forgot password failed ::"+hospStatus.getStatus());
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(hospStatus).build();
	}
	
	@Reference
	LuxuryHomesIdentityService luxuryHomesIdentityService;
}