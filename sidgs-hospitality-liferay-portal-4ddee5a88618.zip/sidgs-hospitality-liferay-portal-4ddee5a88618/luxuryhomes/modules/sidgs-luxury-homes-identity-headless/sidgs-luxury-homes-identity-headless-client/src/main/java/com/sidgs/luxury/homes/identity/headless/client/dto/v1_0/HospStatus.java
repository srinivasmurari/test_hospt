package com.sidgs.luxury.homes.identity.headless.client.dto.v1_0;

import com.sidgs.luxury.homes.identity.headless.client.function.UnsafeSupplier;
import com.sidgs.luxury.homes.identity.headless.client.serdes.v1_0.HospStatusSerDes;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

/**
 * @author MuraliMohanSIDGlobal
 * @generated
 */
@Generated("")
public class HospStatus implements Cloneable, Serializable {

	public static HospStatus toDTO(String json) {
		return HospStatusSerDes.toDTO(json);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setMessage(
		UnsafeSupplier<String, Exception> messageUnsafeSupplier) {

		try {
			message = messageUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String message;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setStatus(
		UnsafeSupplier<String, Exception> statusUnsafeSupplier) {

		try {
			status = statusUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String status;

	@Override
	public HospStatus clone() throws CloneNotSupportedException {
		return (HospStatus)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof HospStatus)) {
			return false;
		}

		HospStatus hospStatus = (HospStatus)object;

		return Objects.equals(toString(), hospStatus.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return HospStatusSerDes.toJSON(this);
	}

}