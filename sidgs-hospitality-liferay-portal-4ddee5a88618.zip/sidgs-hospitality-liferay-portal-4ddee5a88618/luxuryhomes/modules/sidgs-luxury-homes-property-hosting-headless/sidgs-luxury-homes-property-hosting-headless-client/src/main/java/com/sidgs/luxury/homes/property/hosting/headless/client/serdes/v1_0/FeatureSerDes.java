package com.sidgs.luxury.homes.property.hosting.headless.client.serdes.v1_0;

import com.sidgs.luxury.homes.property.hosting.headless.client.dto.v1_0.Feature;
import com.sidgs.luxury.homes.property.hosting.headless.client.json.BaseJSONParser;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Generated;

/**
 * @author MuraliMohan
 * @generated
 */
@Generated("")
public class FeatureSerDes {

	public static Feature toDTO(String json) {
		FeatureJSONParser featureJSONParser = new FeatureJSONParser();

		return featureJSONParser.parseToDTO(json);
	}

	public static Feature[] toDTOs(String json) {
		FeatureJSONParser featureJSONParser = new FeatureJSONParser();

		return featureJSONParser.parseToDTOs(json);
	}

	public static String toJSON(Feature feature) {
		if (feature == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (feature.getCategoryId() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"categoryId\": ");

			sb.append(feature.getCategoryId());
		}

		if (feature.getDescription() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"description\": ");

			sb.append("\"");

			sb.append(_escape(feature.getDescription()));

			sb.append("\"");
		}

		if (feature.getGroupId() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"groupId\": ");

			sb.append(feature.getGroupId());
		}

		if (feature.getId() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"id\": ");

			sb.append("\"");

			sb.append(_escape(feature.getId()));

			sb.append("\"");
		}

		if (feature.getImageIcon() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"imageIcon\": ");

			sb.append("\"");

			sb.append(_escape(feature.getImageIcon()));

			sb.append("\"");
		}

		if (feature.getName() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"name\": ");

			sb.append("\"");

			sb.append(_escape(feature.getName()));

			sb.append("\"");
		}

		if (feature.getPrimaryType() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"primaryType\": ");

			sb.append("\"");

			sb.append(_escape(feature.getPrimaryType()));

			sb.append("\"");
		}

		if (feature.getSubType() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"subType\": ");

			sb.append("\"");

			sb.append(_escape(feature.getSubType()));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		FeatureJSONParser featureJSONParser = new FeatureJSONParser();

		return featureJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(Feature feature) {
		if (feature == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (feature.getCategoryId() == null) {
			map.put("categoryId", null);
		}
		else {
			map.put("categoryId", String.valueOf(feature.getCategoryId()));
		}

		if (feature.getDescription() == null) {
			map.put("description", null);
		}
		else {
			map.put("description", String.valueOf(feature.getDescription()));
		}

		if (feature.getGroupId() == null) {
			map.put("groupId", null);
		}
		else {
			map.put("groupId", String.valueOf(feature.getGroupId()));
		}

		if (feature.getId() == null) {
			map.put("id", null);
		}
		else {
			map.put("id", String.valueOf(feature.getId()));
		}

		if (feature.getImageIcon() == null) {
			map.put("imageIcon", null);
		}
		else {
			map.put("imageIcon", String.valueOf(feature.getImageIcon()));
		}

		if (feature.getName() == null) {
			map.put("name", null);
		}
		else {
			map.put("name", String.valueOf(feature.getName()));
		}

		if (feature.getPrimaryType() == null) {
			map.put("primaryType", null);
		}
		else {
			map.put("primaryType", String.valueOf(feature.getPrimaryType()));
		}

		if (feature.getSubType() == null) {
			map.put("subType", null);
		}
		else {
			map.put("subType", String.valueOf(feature.getSubType()));
		}

		return map;
	}

	public static class FeatureJSONParser extends BaseJSONParser<Feature> {

		@Override
		protected Feature createDTO() {
			return new Feature();
		}

		@Override
		protected Feature[] createDTOArray(int size) {
			return new Feature[size];
		}

		@Override
		protected void setField(
			Feature feature, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "categoryId")) {
				if (jsonParserFieldValue != null) {
					feature.setCategoryId(
						Long.valueOf((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "description")) {
				if (jsonParserFieldValue != null) {
					feature.setDescription((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "groupId")) {
				if (jsonParserFieldValue != null) {
					feature.setGroupId(
						Long.valueOf((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "id")) {
				if (jsonParserFieldValue != null) {
					feature.setId((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "imageIcon")) {
				if (jsonParserFieldValue != null) {
					feature.setImageIcon((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "name")) {
				if (jsonParserFieldValue != null) {
					feature.setName((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "primaryType")) {
				if (jsonParserFieldValue != null) {
					feature.setPrimaryType((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "subType")) {
				if (jsonParserFieldValue != null) {
					feature.setSubType((String)jsonParserFieldValue);
				}
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\": ");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}