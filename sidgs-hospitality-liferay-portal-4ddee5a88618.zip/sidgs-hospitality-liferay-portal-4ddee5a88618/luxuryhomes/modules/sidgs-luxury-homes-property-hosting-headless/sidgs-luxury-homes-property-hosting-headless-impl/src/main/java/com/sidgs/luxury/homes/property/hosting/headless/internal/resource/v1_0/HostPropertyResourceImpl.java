package com.sidgs.luxury.homes.property.hosting.headless.internal.resource.v1_0;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.security.auth.PrincipalThreadLocal;
import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.sidgs.luxury.homes.property.hosting.headless.dto.v1_0.PropertyStatus;
import com.sidgs.luxury.homes.property.hosting.headless.resource.v1_0.HostPropertyResource;
import com.sidgs.luxury.homes.property.hosting.service.LuxuryHomesPropertyHostingService;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

/**
 * @author MuraliMohan
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/host-property.properties",
	scope = ServiceScope.PROTOTYPE, service = HostPropertyResource.class
)
public class HostPropertyResourceImpl extends BaseHostPropertyResourceImpl {
	private final static Log _log = LogFactoryUtil.getLog(HostPropertyResourceImpl.class.getName());
	@Override
	public Response postProperty(MultipartBody multipartBody) throws Exception {
		long userId = PrincipalThreadLocal.getUserId();
		if(!luxuryHomesPropertyHostingService.isHost(userId)) {
			return Response.status(Status.UNAUTHORIZED).entity("Not Authorized").build();
		}
		PropertyStatus status = luxuryHomesPropertyHostingService.propertyHosting(multipartBody);
		_log.info("Property Status ::"+status.getStatus());
		if(status.getStatus().equals("success")) {
			return Response.status(Status.OK).entity(status).build();
		}
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(status).build();
	}
	@Reference
	LuxuryHomesPropertyHostingService luxuryHomesPropertyHostingService;
}