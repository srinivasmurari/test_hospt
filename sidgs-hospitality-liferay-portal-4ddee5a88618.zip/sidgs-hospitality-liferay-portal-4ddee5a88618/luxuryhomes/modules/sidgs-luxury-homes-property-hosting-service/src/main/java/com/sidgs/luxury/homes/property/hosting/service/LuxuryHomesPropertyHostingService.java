package com.sidgs.luxury.homes.property.hosting.service;

import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.sidgs.luxury.homes.property.hosting.headless.dto.v1_0.PropertyStatus;

/**
 * @author MuraliMohan
 */

public interface LuxuryHomesPropertyHostingService {
	public String getPropertyTypes();
	public String getAmenities();
	public PropertyStatus propertyHosting(MultipartBody multipartBody);
	public boolean isHost(long userId);
}