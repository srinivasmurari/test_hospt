package com.sidgs.luxury.homes.property.hosting.service.impl;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetVocabulary;
import com.liferay.asset.kernel.service.AssetCategoryLocalService;
import com.liferay.asset.kernel.service.AssetVocabularyLocalService;
import com.liferay.document.library.kernel.service.DLAppLocalService;
import com.liferay.dynamic.data.mapping.model.DDMForm;
import com.liferay.dynamic.data.mapping.model.DDMFormField;
import com.liferay.dynamic.data.mapping.model.DDMFormFieldOptions;
import com.liferay.dynamic.data.mapping.model.DDMStructure;
import com.liferay.dynamic.data.mapping.model.LocalizedValue;
import com.liferay.dynamic.data.mapping.service.DDMFieldLocalService;
import com.liferay.dynamic.data.mapping.storage.DDMFormFieldValue;
import com.liferay.dynamic.data.mapping.storage.DDMFormValues;
import com.liferay.journal.constants.JournalFolderConstants;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.model.JournalFolder;
import com.liferay.journal.service.JournalArticleLocalService;
import com.liferay.journal.service.JournalFolderLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Group;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.security.auth.CompanyThreadLocal;
import com.liferay.portal.kernel.security.auth.PrincipalThreadLocal;
import com.liferay.portal.kernel.service.GroupLocalService;
import com.liferay.portal.kernel.service.RoleLocalService;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextThreadLocal;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.kernel.xml.Document;
import com.liferay.portal.kernel.xml.Element;
import com.liferay.portal.kernel.xml.SAXReaderUtil;
import com.liferay.portal.kernel.xml.XMLUtil;
import com.liferay.portal.vulcan.multipart.MultipartBody;
import com.sidgs.luxury.homes.notification.service.NotificationService;
import com.sidgs.luxury.homes.property.hosting.headless.dto.v1_0.Feature;
import com.sidgs.luxury.homes.property.hosting.headless.dto.v1_0.PropertyStatus;
import com.sidgs.luxury.homes.property.hosting.lookup.model.HostProperty;
import com.sidgs.luxury.homes.property.hosting.lookup.service.HostPropertyLocalService;
import com.sidgs.luxury.homes.property.hosting.lookup.service.PropertyFloorLocalService;
import com.sidgs.luxury.homes.property.hosting.lookup.service.PropertyLocationLocalService;
import com.sidgs.luxury.homes.property.hosting.lookup.service.PropertyPricingLocalService;
import com.sidgs.luxury.homes.property.hosting.service.LuxuryHomesPropertyHostingService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
@Component(immediate = true, property = {}, service = LuxuryHomesPropertyHostingService.class)
public class LuxuryHomesPropertyHostingServiceImpl implements LuxuryHomesPropertyHostingService{
	
	private final static Log log = LogFactoryUtil.getLog(LuxuryHomesPropertyHostingServiceImpl.class.getName());
	@Override
	public String getPropertyTypes() {
		long companyId = CompanyThreadLocal.getCompanyId();
		Group group = getDefaultGroup(companyId);
		JournalFolder propertyTypeFolder = journalFolderLocalService.fetchFolder(group.getGroupId(), JournalFolderConstants.DEFAULT_PARENT_FOLDER_ID, "Property Type");
		List<JournalArticle> folderArticles = journalArticleLocalService.getArticles(group.getGroupId(), propertyTypeFolder.getFolderId(), WorkflowConstants.STATUS_APPROVED, -1, -1); 
		Set<String> propertyTypeArticleIds = new HashSet<String>();
		for(JournalArticle folderArticle:folderArticles) {
			propertyTypeArticleIds.add(folderArticle.getArticleId());
		}
		List<Feature> propertyTypes = getFeaturesByArticleIds(group.getGroupId(), companyId, propertyTypeArticleIds);
		JSONArray propertyTypesArr = JSONFactoryUtil.createJSONArray(propertyTypes);
		
		return propertyTypesArr.toJSONString();
	}
	
	@Override
	public String getAmenities() {
		long companyId = CompanyThreadLocal.getCompanyId();
		Group group = getDefaultGroup(companyId);
		JournalFolder amenitiesFolder = journalFolderLocalService.fetchFolder(group.getGroupId(), JournalFolderConstants.DEFAULT_PARENT_FOLDER_ID, "Amenities");
		List<JournalFolder> subFolders = journalFolderLocalService.getFolders(group.getGroupId(), amenitiesFolder.getFolderId());
		JSONObject amenitiesTypes = JSONFactoryUtil.createJSONObject(); 
		for(JournalFolder subFolder:subFolders) {
			List<JournalArticle> folderArticles = journalArticleLocalService.getArticles(group.getGroupId(), subFolder.getFolderId(), WorkflowConstants.STATUS_APPROVED, -1, -1); 
			Set<String> subFolderArticleIds = new HashSet<String>();
			for(JournalArticle folderArticle:folderArticles) {
				subFolderArticleIds.add(folderArticle.getArticleId());
			}
			List<Feature> propertyTypes = getFeaturesByArticleIds(group.getGroupId(), companyId, subFolderArticleIds);
			JSONArray amenitySubTypeArr = JSONFactoryUtil.createJSONArray(propertyTypes);
			amenitiesTypes.put(subFolder.getName(), amenitySubTypeArr);
		}
		return amenitiesTypes.toJSONString();
	}
	
	private List<Feature> getFeaturesByArticleIds(long groupId, long companyId, Set<String> propertyTypeArticleIds) {
		List<Feature> propertyTypes = new ArrayList<Feature>();
		for(String propertyTypeArticleId: propertyTypeArticleIds) {
			JournalArticle propertyTypeArticle = journalArticleLocalService.fetchLatestArticle(groupId, propertyTypeArticleId, WorkflowConstants.STATUS_APPROVED);
			Feature feature = new Feature();
			log.info(propertyTypeArticle.getVersion()+" ::  Title :: "+propertyTypeArticle.getTitle(Locale.US));
			try {
				String title  = propertyTypeArticle.getTitle(Locale.US);
				String primaryType = getFieldFromArticle(propertyTypeArticle, "PrimaryType");
				String subType = getFieldFromArticle(propertyTypeArticle, "AmenityType");
				feature.setName(getFieldFromArticle(propertyTypeArticle, "Name"));
				feature.setDescription(getFieldFromArticle(propertyTypeArticle, "Description"));
				feature.setPrimaryType(primaryType);
				feature.setSubType(subType);
				feature.setImageIcon(getImageURLJSON(getFieldFromArticle(propertyTypeArticle, "ImageIcon")));
				feature.setId(propertyTypeArticle.getArticleId());
				log.info("Title :: "+propertyTypeArticle.getTitle(Locale.US)+"   primaryType::"+primaryType+"  subType:: "+subType);
				List<AssetCategory> categories = getcategoriesByTypeAndSubType(companyId, primaryType, subType);
				for(AssetCategory category:categories) {
					log.info("Category Title ::"+category.getTitle(Locale.US));
					if(category.getTitle(Locale.US).equals(title)) {
						feature.setCategoryId(category.getCategoryId());
						break;
					}
				}
				propertyTypes.add(feature);
			} catch (Exception e) {
				log.error("Error while Parsing content into JSON Object");
			}
		}
		return propertyTypes;
	}
	
	private List<AssetCategory> getcategoriesByTypeAndSubType(long companyId, String primaryType, String subType) {
		List<AssetCategory> categories = new ArrayList<AssetCategory>();
		List<AssetVocabulary> vocabularies = assetVocabularyLocalService.getCompanyVocabularies(companyId);
		for(AssetVocabulary vocabulary:vocabularies) {
			if(vocabulary.getTitle(Locale.US).equals(primaryType)) {
				log.info(subType+"  Vocab title "+vocabulary.getTitle(Locale.US));
				if(subType.equals("None")) {
					categories.addAll(vocabulary.getCategories());
					break;
				}
				if(!subType.equals("None")) {
					List<AssetCategory> vocabCategories = assetCategoryLocalService.getVocabularyCategories(vocabulary.getVocabularyId(), -1, -1, null);
					for(AssetCategory vocabCategory:vocabCategories) {
						if(vocabCategory.getTitle(Locale.US).equals(subType)) {
							categories.addAll(assetCategoryLocalService.getChildCategories(vocabCategory.getCategoryId()));
							break;
						}
					}
					break;
				}
			}
		}
		return categories;
	}
	
	private Group getDefaultGroup(long companyId) {
		Group defaultGroup = null;
		try {
			defaultGroup = groupLocalService.getFriendlyURLGroup(companyId, "/guest");
		} catch (PortalException e) {
			log.error("Error while fetching default Group");
		}
		return defaultGroup;
	}
	
	private String getImageURLJSON(String imageIconJSON) {
		try {
			JSONObject fileEntryJson = JSONFactoryUtil.createJSONObject(imageIconJSON);
			String res = "/documents/"+fileEntryJson.getString("groupId")+"/"+fileEntryJson.getString("uuid");
			return res;
		} catch (Exception e) {
			log.error("Exception while parsing URL for Image JSON");
		}
		return StringPool.BLANK;
	}
	
	@Override
	public boolean isHost(long userId) {
		User user = userLocalService.fetchUser(userId);
		if(user!=null) {
			return userHasRole(user);
		}
		return false;
	}
	
	private boolean userHasRole(User user) {
		String roleName = "Property Host";
		try {
			List<Role> userRoles = _roleLocalService.getUserRoles(user.getUserId());
			for(Role userRole:userRoles) {
				if(userRole.getName().equals(roleName)) {
					return true;
				}
			}
			return _roleLocalService.hasUserRole(user.getUserId(), user.getCompanyId(), roleName, true);
		}catch (Exception e) {
			log.error("Error checking role: ", e);
		}
		return false;
	}
	
	@Override
	public PropertyStatus propertyHosting(MultipartBody multipartBody) {
		PropertyStatus propertyStatus = new PropertyStatus();
		JSONObject propertyObj = null;
		try {
			propertyObj = JSONFactoryUtil.createJSONObject(multipartBody.getValueAsString("propertyDetails"));
		} catch (JSONException e1) {
			log.error("JSON Exception while parsing property details");
		}
		if(propertyObj==null) {
			propertyStatus.setStatus("error");
			propertyStatus.setMessage("Property Details are empty or not in Proper format");
			return propertyStatus;
		}
		String fileArray = multipartBody.getValueAsString("filesArray");
		propertyStatus = LuxuryHomesPropertyHostingUtil.validatePropertyDetails(propertyObj, fileArray, multipartBody);
		if(!propertyStatus.getStatus().equals("success")) {
			return propertyStatus;
		}
        long userId = PrincipalThreadLocal.getUserId();
        long companyId = CompanyThreadLocal.getCompanyId();
        Group group = getDefaultGroup(companyId);
        String propertyTitle = propertyObj.getString("Title");
        try {
			JSONArray filesArray = JSONFactoryUtil.createJSONArray(fileArray);
			ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
			long timeStampFolderId = LuxuryHomesPropertyHostingUtil.getTimeStampFolderId(group.getGroupId(), userId, propertyTitle, serviceContext);
			JSONArray imagesArray = JSONFactoryUtil.createJSONArray();
			for (int i = 0; i < filesArray.length(); i++) {
				JSONObject fileObject = filesArray.getJSONObject(i);
				String key = fileObject.getString("key");
				String fileName = fileObject.getString("fileName");
				log.info("key :: "+key+"  fileName :: "+fileName);
				try {
					byte[] imageBytes = multipartBody.getBinaryFileAsBytes(key);
					log.info("Image Bytes  ::"+imageBytes);
					JSONObject imageObj = uploadImage(userId, group.getGroupId(), timeStampFolderId, fileName, imageBytes, serviceContext);
					if(imageObj!=null) {
						log.info("Image Bytes  ::"+imageObj.toJSONString());
						imagesArray.put(imageObj);
					}else {
						propertyStatus.setStatus("error");
						propertyStatus.setMessage("Unable to upload the images");
						return propertyStatus;
					}
				} catch (IOException e) {
					log.error("Error while fetching file as bytes", e);
				}
			}
			propertyObj.put("Images", imagesArray);
			JournalArticle propertyArticle = createWebContent(group.getGroupId(), userId, propertyTitle, propertyObj);
			if(propertyArticle!=null) {
				boolean hostPropertyStatus = addProperty(userId, propertyArticle.getArticleId(), propertyObj);
				if(hostPropertyStatus) {
					try {
						User hostUser = userLocalService.getUser(userId);
						String phone = (String)hostUser.getExpandoBridge().getAttribute("Phone Number");
						String address = propertyObj.getString("Address");
						notificationService.sendEmailAfterHosting(group.getGroupId(), hostUser.getEmailAddress(), hostUser.getFullName(), propertyTitle, address, phone);
					}catch(PortalException pe) {
						log.error("Error while triggering email", pe);
					}
					propertyStatus.setStatus("success");
					propertyStatus.setMessage("property hosted successfully");
				}else {
					propertyStatus.setStatus("error");
					propertyStatus.setMessage("Unable to create the property");
				}
			}else {
				propertyStatus.setStatus("error");
				propertyStatus.setMessage("Unable to create the content");
			}
		} catch (JSONException e) {
			log.error("Error while parsing JSON Array");
			propertyStatus.setStatus("error");
			propertyStatus.setMessage("Error while creating property");
		}
        return propertyStatus;
	}
	
	private boolean addProperty(long userId, String articleId, JSONObject propertyObj) {
		Date availableFrom = new Date();
		try {
			availableFrom = new SimpleDateFormat("yyyy-MM-dd").parse(propertyObj.getString("AvailableFrom"));
		} catch (ParseException e) {
			log.error("Error while parsing the date format");
		} 
		HostProperty hostProperty = hostPropertyLocalService.addHostProperty(userId, articleId, propertyObj.getInt("Guests"), propertyObj.getInt("Bedrooms"), availableFrom);
		propertyFloorLocalService.addPropertyFloorPlan(hostProperty.getHostPropertyId(), propertyObj.getInt("Guests"), propertyObj.getInt("Bedrooms"), propertyObj.getInt("Beds"), propertyObj.getInt("Bathrooms"));
		propertyLocationLocalService.addPropertyLocation(hostProperty.getHostPropertyId(), propertyObj.getJSONObject("Address"), propertyObj.getString("Coordinates"));
		return true;
	}
	
	private JSONObject uploadImage(long userId, long groupId, long folderId, String fileName, byte[] imageBytes, ServiceContext serviceContext) {
		Path path = new File(fileName).toPath();
		JSONObject imageObj = null;
		try {
			String mimeType = Files.probeContentType(path);
			FileEntry fileEntry = dlAppLocalService.addFileEntry(null, userId, groupId, folderId, fileName, mimeType, imageBytes, null, null, serviceContext);
			fileEntry.getGroupId();fileEntry.getDescription();fileEntry.getTitle();fileEntry.getUuid();
			fileEntry.getFileName();
			imageObj = JSONFactoryUtil.createJSONObject();
			imageObj.put("groupId", groupId);imageObj.put("alt", "");imageObj.put("name", fileEntry.getFileName());
			imageObj.put("width", "360");imageObj.put("description", fileEntry.getDescription());imageObj.put("title", fileEntry.getTitle());
			imageObj.put("type", "document");imageObj.put("uuid", fileEntry.getUuid());imageObj.put("fileEntryId", fileEntry.getFileEntryId());
			imageObj.put("url", "/documents/d/guest/"+fileEntry.getTitle());imageObj.put("height", "360");
		} catch (IOException e) {
			log.error("Error while fetching file as bytes", e);
		} catch (PortalException e) {
			log.error("Error while fetching file as bytes", e);
		}
		return imageObj;
	}
	
	private JournalArticle createWebContent(long groupId, long userId, String title, JSONObject propertyObj) {
		JournalFolder propertiesFolder = journalFolderLocalService.fetchFolder(groupId, JournalFolderConstants.DEFAULT_PARENT_FOLDER_ID, "Properties");
		Map<Locale, String> titleMap = new HashMap<Locale, String>();
		titleMap.put(Locale.US, title);
		Map<Locale, String> descriptionMap = new HashMap<Locale, String>();
		titleMap.put(Locale.US, title);
		DDMStructure structure = LuxuryHomesPropertyHostingUtil.getStructureId(groupId, "Property");
		long userId2 = PrincipalThreadLocal.getUserId();
		ServiceContext serviceContext = ServiceContextThreadLocal.getServiceContext();
		String content = createXMLContent(structure, propertyObj);
		JournalArticle journalArticle = null;
		try {
			JSONArray amentyIds = propertyObj.getJSONArray("amentyIds");
			long[] amentyLongIds = new long[amentyIds.length()+1];
			for (int i = 0; i < amentyIds.length(); i++) {
				long value = amentyIds.getLong(i);
				amentyLongIds[i] = value;
			}
			long propertyTypeId  = propertyObj.getLong("propertyTypeId");
			amentyLongIds[amentyIds.length()] = propertyTypeId;
			serviceContext.setAssetCategoryIds(amentyLongIds);
			journalArticle = journalArticleLocalService.addArticle(null, userId2, groupId, propertiesFolder.getFolderId(), titleMap, descriptionMap, content, structure.getStructureId(), null, serviceContext);
		} catch (PortalException e) {
			log.error("Error while creating "+e);
			e.printStackTrace();
			return null;
		}
		return journalArticle;
	}
	
	private String createXMLContent(DDMStructure structure, JSONObject obj) {
		Document document = SAXReaderUtil.createDocument();
		Element rootElement = document.addElement("root");
		rootElement.addAttribute("available-locales", Locale.US.toString());
		rootElement.addAttribute("default-locale", Locale.US.toString());
		rootElement.addAttribute("version", "1.0");
		DDMForm form = structure.getDDMForm();
    	List<DDMFormField> formFields = form.getDDMFormFields();
    	for(DDMFormField formField:formFields) {
    		if(formField.isRepeatable() && formField.getFieldReference().equals("Image")) {
    			JSONArray arry = obj.getJSONArray("Images");
    			for (int i = 0; i < arry.length(); i++) {
    				addDynamicElement(rootElement, formField.getFieldReference(), formField.getIndexType(), formField.getName(), formField.getType(), arry.getJSONObject(i).toJSONString());
    			}
    		}else {
    			addDynamicElement(rootElement, formField.getFieldReference(), formField.getIndexType(), formField.getName(), formField.getType(), obj.getString(formField.getFieldReference()));
    		}
    	}
		return XMLUtil.stripInvalidChars(document.asXML());
	}
	
	private Element addDynamicElement(Element rootElement, String fieldReference, String indexType, String name, String type,  String value) {
		Element dynamicElementElement = rootElement.addElement("dynamic-element");
		if(value == null) {
			value="";
		}
		dynamicElementElement.addAttribute("name", name);
		dynamicElementElement.addAttribute("type", type);
		dynamicElementElement.addAttribute("index-type", indexType);
		dynamicElementElement.addAttribute("field-reference", fieldReference);
		Element dynamicContentElement = dynamicElementElement.addElement("dynamic-content");
		dynamicContentElement.addAttribute("language-id", Locale.US.toString());
		dynamicContentElement.addCDATA(value);
		return dynamicElementElement;
	}
	
	private final String getFieldFromArticle(JournalArticle article, String fieldName) {
		DDMStructure ddmStructure = article.getDDMStructure();
		DDMFormValues formValues = ddmFieldLocalService.getDDMFormValues(ddmStructure.getDDMForm(), article.getId());
		List<DDMFormFieldValue>  formFieldValues = formValues.getDDMFormFieldValues();
		for(DDMFormFieldValue formFieldValue:formFieldValues) {
			if(formFieldValue.getFieldReference().equals(fieldName)) {
				String val = formFieldValue.getValue().getString(Locale.US);
				if(fieldName.equals("PrimaryType") || fieldName.equals("AmenityType")) {
					try {
						DDMFormField ddmFormField = ddmStructure.getDDMFormFieldByFieldReference(fieldName);
						DDMFormFieldOptions options = ddmFormField.getDDMFormFieldOptions();
						LocalizedValue lvalue = options.getOptionLabels(val);
						val = lvalue.getString(Locale.US);
						log.info("Label  :::"+lvalue.getString(Locale.US));
					} catch (PortalException e) {
						log.error("Error while fetching the Label of the key");
					}
				}
				return val;
			}
		}
		return StringPool.BLANK;
	}
	
	@Reference
	RoleLocalService _roleLocalService;
	@Reference
	GroupLocalService groupLocalService;
	@Reference
	UserLocalService userLocalService;
	@Reference
	JournalArticleLocalService journalArticleLocalService;
	@Reference
	JournalFolderLocalService journalFolderLocalService;
	@Reference
	AssetVocabularyLocalService assetVocabularyLocalService;
	@Reference
	AssetCategoryLocalService assetCategoryLocalService;
	@Reference
	DDMFieldLocalService ddmFieldLocalService;
	@Reference
	DLAppLocalService dlAppLocalService;
	@Reference
	NotificationService notificationService;
	@Reference
	HostPropertyLocalService hostPropertyLocalService;
	@Reference
	PropertyFloorLocalService propertyFloorLocalService;
	@Reference
	PropertyLocationLocalService propertyLocationLocalService;
	@Reference
	PropertyPricingLocalService propertyPricingLocalService;
}
